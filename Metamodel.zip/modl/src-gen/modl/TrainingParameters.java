/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Training Parameters</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.TrainingParameters#getEpochs <em>Epochs</em>}</li>
 *   <li>{@link modl.TrainingParameters#getObjective_function <em>Objective function</em>}</li>
 *   <li>{@link modl.TrainingParameters#getOptimizer <em>Optimizer</em>}</li>
 *   <li>{@link modl.TrainingParameters#getMetric <em>Metric</em>}</li>
 *   <li>{@link modl.TrainingParameters#getLearning_rate <em>Learning rate</em>}</li>
 *   <li>{@link modl.TrainingParameters#getDecay_rate <em>Decay rate</em>}</li>
 *   <li>{@link modl.TrainingParameters#getMomentum <em>Momentum</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getTrainingParameters()
 * @model
 * @generated
 */
public interface TrainingParameters extends Parameters {
	/**
	 * Returns the value of the '<em><b>Epochs</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Epochs</em>' attribute.
	 * @see #setEpochs(int)
	 * @see modl.ModlPackage#getTrainingParameters_Epochs()
	 * @model
	 * @generated
	 */
	int getEpochs();

	/**
	 * Sets the value of the '{@link modl.TrainingParameters#getEpochs <em>Epochs</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Epochs</em>' attribute.
	 * @see #getEpochs()
	 * @generated
	 */
	void setEpochs(int value);

	/**
	 * Returns the value of the '<em><b>Objective function</b></em>' attribute.
	 * The literals are from the enumeration {@link modl.ObjectiveType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Objective function</em>' attribute.
	 * @see modl.ObjectiveType
	 * @see #setObjective_function(ObjectiveType)
	 * @see modl.ModlPackage#getTrainingParameters_Objective_function()
	 * @model
	 * @generated
	 */
	ObjectiveType getObjective_function();

	/**
	 * Sets the value of the '{@link modl.TrainingParameters#getObjective_function <em>Objective function</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Objective function</em>' attribute.
	 * @see modl.ObjectiveType
	 * @see #getObjective_function()
	 * @generated
	 */
	void setObjective_function(ObjectiveType value);

	/**
	 * Returns the value of the '<em><b>Optimizer</b></em>' attribute.
	 * The literals are from the enumeration {@link modl.OptimizerType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Optimizer</em>' attribute.
	 * @see modl.OptimizerType
	 * @see #setOptimizer(OptimizerType)
	 * @see modl.ModlPackage#getTrainingParameters_Optimizer()
	 * @model
	 * @generated
	 */
	OptimizerType getOptimizer();

	/**
	 * Sets the value of the '{@link modl.TrainingParameters#getOptimizer <em>Optimizer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Optimizer</em>' attribute.
	 * @see modl.OptimizerType
	 * @see #getOptimizer()
	 * @generated
	 */
	void setOptimizer(OptimizerType value);

	/**
	 * Returns the value of the '<em><b>Metric</b></em>' attribute.
	 * The literals are from the enumeration {@link modl.MetricType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Metric</em>' attribute.
	 * @see modl.MetricType
	 * @see #setMetric(MetricType)
	 * @see modl.ModlPackage#getTrainingParameters_Metric()
	 * @model
	 * @generated
	 */
	MetricType getMetric();

	/**
	 * Sets the value of the '{@link modl.TrainingParameters#getMetric <em>Metric</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Metric</em>' attribute.
	 * @see modl.MetricType
	 * @see #getMetric()
	 * @generated
	 */
	void setMetric(MetricType value);

	/**
	 * Returns the value of the '<em><b>Learning rate</b></em>' attribute.
	 * The default value is <code>"0.01"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Learning rate</em>' attribute.
	 * @see #setLearning_rate(double)
	 * @see modl.ModlPackage#getTrainingParameters_Learning_rate()
	 * @model default="0.01"
	 * @generated
	 */
	double getLearning_rate();

	/**
	 * Sets the value of the '{@link modl.TrainingParameters#getLearning_rate <em>Learning rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Learning rate</em>' attribute.
	 * @see #getLearning_rate()
	 * @generated
	 */
	void setLearning_rate(double value);

	/**
	 * Returns the value of the '<em><b>Decay rate</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Decay rate</em>' attribute.
	 * @see #setDecay_rate(float)
	 * @see modl.ModlPackage#getTrainingParameters_Decay_rate()
	 * @model default="0"
	 * @generated
	 */
	float getDecay_rate();

	/**
	 * Sets the value of the '{@link modl.TrainingParameters#getDecay_rate <em>Decay rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Decay rate</em>' attribute.
	 * @see #getDecay_rate()
	 * @generated
	 */
	void setDecay_rate(float value);

	/**
	 * Returns the value of the '<em><b>Momentum</b></em>' attribute.
	 * The default value is <code>"0"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Momentum</em>' attribute.
	 * @see #setMomentum(float)
	 * @see modl.ModlPackage#getTrainingParameters_Momentum()
	 * @model default="0"
	 * @generated
	 */
	float getMomentum();

	/**
	 * Sets the value of the '{@link modl.TrainingParameters#getMomentum <em>Momentum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Momentum</em>' attribute.
	 * @see #getMomentum()
	 * @generated
	 */
	void setMomentum(float value);

} // TrainingParameters
