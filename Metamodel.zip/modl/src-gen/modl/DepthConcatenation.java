/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Depth Concatenation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getDepthConcatenation()
 * @model
 * @generated
 */
public interface DepthConcatenation extends LayerOperations {
} // DepthConcatenation
