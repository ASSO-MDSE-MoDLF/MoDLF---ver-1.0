/**
 */
package modl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>DLF</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.DLF#getDataset <em>Dataset</em>}</li>
 *   <li>{@link modl.DLF#getCnnmodel <em>Cnnmodel</em>}</li>
 *   <li>{@link modl.DLF#getBasicmodel <em>Basicmodel</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getDLF()
 * @model
 * @generated
 */
public interface DLF extends EObject {
	/**
	 * Returns the value of the '<em><b>Dataset</b></em>' containment reference list.
	 * The list contents are of type {@link modl.Dataset}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dataset</em>' containment reference list.
	 * @see modl.ModlPackage#getDLF_Dataset()
	 * @model containment="true"
	 * @generated
	 */
	EList<Dataset> getDataset();

	/**
	 * Returns the value of the '<em><b>Cnnmodel</b></em>' containment reference list.
	 * The list contents are of type {@link modl.CNNModel}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cnnmodel</em>' containment reference list.
	 * @see modl.ModlPackage#getDLF_Cnnmodel()
	 * @model containment="true"
	 * @generated
	 */
	EList<CNNModel> getCnnmodel();

	/**
	 * Returns the value of the '<em><b>Basicmodel</b></em>' containment reference list.
	 * The list contents are of type {@link modl.BasicModel}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Basicmodel</em>' containment reference list.
	 * @see modl.ModlPackage#getDLF_Basicmodel()
	 * @model containment="true"
	 * @generated
	 */
	EList<BasicModel> getBasicmodel();

} // DLF
