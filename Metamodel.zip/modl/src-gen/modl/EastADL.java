/**
 */
package modl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>East ADL</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.EastADL#getDlf <em>Dlf</em>}</li>
 *   <li>{@link modl.EastADL#getAutosar <em>Autosar</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getEastADL()
 * @model
 * @generated
 */
public interface EastADL extends EObject {
	/**
	 * Returns the value of the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dlf</em>' containment reference.
	 * @see #setDlf(DLF)
	 * @see modl.ModlPackage#getEastADL_Dlf()
	 * @model containment="true"
	 * @generated
	 */
	DLF getDlf();

	/**
	 * Sets the value of the '{@link modl.EastADL#getDlf <em>Dlf</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dlf</em>' containment reference.
	 * @see #getDlf()
	 * @generated
	 */
	void setDlf(DLF value);

	/**
	 * Returns the value of the '<em><b>Autosar</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Autosar</em>' containment reference.
	 * @see #setAutosar(AUTOSAR)
	 * @see modl.ModlPackage#getEastADL_Autosar()
	 * @model containment="true" required="true"
	 * @generated
	 */
	AUTOSAR getAutosar();

	/**
	 * Sets the value of the '{@link modl.EastADL#getAutosar <em>Autosar</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Autosar</em>' containment reference.
	 * @see #getAutosar()
	 * @generated
	 */
	void setAutosar(AUTOSAR value);

} // EastADL
