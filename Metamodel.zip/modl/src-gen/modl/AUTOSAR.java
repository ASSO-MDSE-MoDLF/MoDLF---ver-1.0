/**
 */
package modl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AUTOSAR</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.AUTOSAR#getDlf <em>Dlf</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getAUTOSAR()
 * @model
 * @generated
 */
public interface AUTOSAR extends EObject {
	/**
	 * Returns the value of the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dlf</em>' containment reference.
	 * @see #setDlf(DLF)
	 * @see modl.ModlPackage#getAUTOSAR_Dlf()
	 * @model containment="true"
	 * @generated
	 */
	DLF getDlf();

	/**
	 * Sets the value of the '{@link modl.AUTOSAR#getDlf <em>Dlf</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dlf</em>' containment reference.
	 * @see #getDlf()
	 * @generated
	 */
	void setDlf(DLF value);

} // AUTOSAR
