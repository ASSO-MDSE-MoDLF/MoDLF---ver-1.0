/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Linear Layer</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getLinearLayer()
 * @model abstract="true"
 * @generated
 */
public interface LinearLayer extends Layer {

} // LinearLayer
