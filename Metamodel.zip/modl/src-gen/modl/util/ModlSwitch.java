/**
 */
package modl.util;

import modl.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see modl.ModlPackage
 * @generated
 */
public class ModlSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ModlPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModlSwitch() {
		if (modelPackage == null) {
			modelPackage = ModlPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case ModlPackage.DLF: {
			DLF dlf = (DLF) theEObject;
			T result = caseDLF(dlf);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.DATASET: {
			Dataset dataset = (Dataset) theEObject;
			T result = caseDataset(dataset);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.TRAINING_DS: {
			TrainingDS trainingDS = (TrainingDS) theEObject;
			T result = caseTrainingDS(trainingDS);
			if (result == null)
				result = caseDataset(trainingDS);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.TESTING_DS: {
			TestingDS testingDS = (TestingDS) theEObject;
			T result = caseTestingDS(testingDS);
			if (result == null)
				result = caseDataset(testingDS);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.IMAGE: {
			Image image = (Image) theEObject;
			T result = caseImage(image);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.LABEL: {
			Label label = (Label) theEObject;
			T result = caseLabel(label);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.CNN_MODEL: {
			CNNModel cnnModel = (CNNModel) theEObject;
			T result = caseCNNModel(cnnModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.TRAINING_PARAMETERS: {
			TrainingParameters trainingParameters = (TrainingParameters) theEObject;
			T result = caseTrainingParameters(trainingParameters);
			if (result == null)
				result = caseParameters(trainingParameters);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.TESTING_PARAMETERS: {
			TestingParameters testingParameters = (TestingParameters) theEObject;
			T result = caseTestingParameters(testingParameters);
			if (result == null)
				result = caseParameters(testingParameters);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.LAYER: {
			Layer layer = (Layer) theEObject;
			T result = caseLayer(layer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.INPUT_LAYER: {
			InputLayer inputLayer = (InputLayer) theEObject;
			T result = caseInputLayer(inputLayer);
			if (result == null)
				result = caseLayer(inputLayer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.CONV_LAYER: {
			ConvLayer convLayer = (ConvLayer) theEObject;
			T result = caseConvLayer(convLayer);
			if (result == null)
				result = caseLayer(convLayer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.LINEAR_LAYER: {
			LinearLayer linearLayer = (LinearLayer) theEObject;
			T result = caseLinearLayer(linearLayer);
			if (result == null)
				result = caseLayer(linearLayer);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.CONV2_D: {
			Conv2D conv2D = (Conv2D) theEObject;
			T result = caseConv2D(conv2D);
			if (result == null)
				result = caseConvLayer(conv2D);
			if (result == null)
				result = caseLayer(conv2D);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.POOLING2_D: {
			Pooling2D pooling2D = (Pooling2D) theEObject;
			T result = casePooling2D(pooling2D);
			if (result == null)
				result = caseConvLayer(pooling2D);
			if (result == null)
				result = caseLayer(pooling2D);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.UPSAMPLING2_D: {
			Upsampling2D upsampling2D = (Upsampling2D) theEObject;
			T result = caseUpsampling2D(upsampling2D);
			if (result == null)
				result = caseConvLayer(upsampling2D);
			if (result == null)
				result = caseLayer(upsampling2D);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.CONV2_DTRANSPOSE: {
			Conv2DTranspose conv2DTranspose = (Conv2DTranspose) theEObject;
			T result = caseConv2DTranspose(conv2DTranspose);
			if (result == null)
				result = caseConvLayer(conv2DTranspose);
			if (result == null)
				result = caseLayer(conv2DTranspose);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.DENSE: {
			Dense dense = (Dense) theEObject;
			T result = caseDense(dense);
			if (result == null)
				result = caseLinearLayer(dense);
			if (result == null)
				result = caseLayer(dense);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.OUTPUT: {
			Output output = (Output) theEObject;
			T result = caseOutput(output);
			if (result == null)
				result = caseLinearLayer(output);
			if (result == null)
				result = caseLayer(output);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.PARAMETERS: {
			Parameters parameters = (Parameters) theEObject;
			T result = caseParameters(parameters);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.AUTOMOTIVE_SYSTEM: {
			AutomotiveSystem automotiveSystem = (AutomotiveSystem) theEObject;
			T result = caseAutomotiveSystem(automotiveSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.EAST_ADL: {
			EastADL eastADL = (EastADL) theEObject;
			T result = caseEastADL(eastADL);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.AUTOSAR: {
			AUTOSAR autosar = (AUTOSAR) theEObject;
			T result = caseAUTOSAR(autosar);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.MEDICAL_IMAGING_SYSTEM: {
			MedicalImagingSystem medicalImagingSystem = (MedicalImagingSystem) theEObject;
			T result = caseMedicalImagingSystem(medicalImagingSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.SATELLITE_IMAGING_SYSTEM: {
			SatelliteImagingSystem satelliteImagingSystem = (SatelliteImagingSystem) theEObject;
			T result = caseSatelliteImagingSystem(satelliteImagingSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.DEFENCE_AND_SURVELLIANCE_SYSTEM: {
			DefenceAndSurvellianceSystem defenceAndSurvellianceSystem = (DefenceAndSurvellianceSystem) theEObject;
			T result = caseDefenceAndSurvellianceSystem(defenceAndSurvellianceSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.MIEROF: {
			MIEROF mierof = (MIEROF) theEObject;
			T result = caseMIEROF(mierof);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.INDUSTRIAL_AUTOMATION_SYSTEM: {
			IndustrialAutomationSystem industrialAutomationSystem = (IndustrialAutomationSystem) theEObject;
			T result = caseIndustrialAutomationSystem(industrialAutomationSystem);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.LAYER_OPERATIONS: {
			LayerOperations layerOperations = (LayerOperations) theEObject;
			T result = caseLayerOperations(layerOperations);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.MULTIPLICATION: {
			Multiplication multiplication = (Multiplication) theEObject;
			T result = caseMultiplication(multiplication);
			if (result == null)
				result = caseLayerOperations(multiplication);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.ADDITION: {
			Addition addition = (Addition) theEObject;
			T result = caseAddition(addition);
			if (result == null)
				result = caseLayerOperations(addition);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.CONCATENATION: {
			Concatenation concatenation = (Concatenation) theEObject;
			T result = caseConcatenation(concatenation);
			if (result == null)
				result = caseLayerOperations(concatenation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.DEPTH_CONCATENATION: {
			DepthConcatenation depthConcatenation = (DepthConcatenation) theEObject;
			T result = caseDepthConcatenation(depthConcatenation);
			if (result == null)
				result = caseLayerOperations(depthConcatenation);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.VGG16: {
			VGG16 vgg16 = (VGG16) theEObject;
			T result = caseVGG16(vgg16);
			if (result == null)
				result = caseBasicModel(vgg16);
			if (result == null)
				result = caseCNNModel(vgg16);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.ALEX_NET: {
			AlexNet alexNet = (AlexNet) theEObject;
			T result = caseAlexNet(alexNet);
			if (result == null)
				result = caseBasicModel(alexNet);
			if (result == null)
				result = caseCNNModel(alexNet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.INCEPTION: {
			Inception inception = (Inception) theEObject;
			T result = caseInception(inception);
			if (result == null)
				result = caseBasicModel(inception);
			if (result == null)
				result = caseCNNModel(inception);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.RES_NET50: {
			ResNet50 resNet50 = (ResNet50) theEObject;
			T result = caseResNet50(resNet50);
			if (result == null)
				result = caseBasicModel(resNet50);
			if (result == null)
				result = caseCNNModel(resNet50);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.BASIC_MODEL: {
			BasicModel basicModel = (BasicModel) theEObject;
			T result = caseBasicModel(basicModel);
			if (result == null)
				result = caseCNNModel(basicModel);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.EFFICIENT_NET: {
			EfficientNet efficientNet = (EfficientNet) theEObject;
			T result = caseEfficientNet(efficientNet);
			if (result == null)
				result = caseBasicModel(efficientNet);
			if (result == null)
				result = caseCNNModel(efficientNet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.MOBILE_NET: {
			MobileNet mobileNet = (MobileNet) theEObject;
			T result = caseMobileNet(mobileNet);
			if (result == null)
				result = caseBasicModel(mobileNet);
			if (result == null)
				result = caseCNNModel(mobileNet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.REG_NET: {
			RegNet regNet = (RegNet) theEObject;
			T result = caseRegNet(regNet);
			if (result == null)
				result = caseBasicModel(regNet);
			if (result == null)
				result = caseCNNModel(regNet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ModlPackage.DENSE_NET: {
			DenseNet denseNet = (DenseNet) theEObject;
			T result = caseDenseNet(denseNet);
			if (result == null)
				result = caseBasicModel(denseNet);
			if (result == null)
				result = caseCNNModel(denseNet);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>DLF</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>DLF</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDLF(DLF object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dataset</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dataset</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDataset(Dataset object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Training DS</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Training DS</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTrainingDS(TrainingDS object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Testing DS</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Testing DS</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTestingDS(TestingDS object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Image</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Image</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseImage(Image object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Label</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Label</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLabel(Label object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>CNN Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>CNN Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseCNNModel(CNNModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Training Parameters</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Training Parameters</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTrainingParameters(TrainingParameters object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Testing Parameters</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Testing Parameters</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTestingParameters(TestingParameters object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Layer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Layer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLayer(Layer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Input Layer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Input Layer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInputLayer(InputLayer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Conv Layer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Conv Layer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConvLayer(ConvLayer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Linear Layer</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Linear Layer</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLinearLayer(LinearLayer object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Conv2 D</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Conv2 D</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConv2D(Conv2D object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Pooling2 D</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Pooling2 D</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T casePooling2D(Pooling2D object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Upsampling2 D</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Upsampling2 D</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseUpsampling2D(Upsampling2D object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Conv2 DTranspose</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Conv2 DTranspose</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConv2DTranspose(Conv2DTranspose object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dense</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dense</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDense(Dense object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Output</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Output</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseOutput(Output object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Parameters</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Parameters</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseParameters(Parameters object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Automotive System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Automotive System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAutomotiveSystem(AutomotiveSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>East ADL</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>East ADL</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEastADL(EastADL object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>AUTOSAR</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>AUTOSAR</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAUTOSAR(AUTOSAR object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Medical Imaging System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Medical Imaging System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMedicalImagingSystem(MedicalImagingSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Satellite Imaging System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Satellite Imaging System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseSatelliteImagingSystem(SatelliteImagingSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Defence And Survelliance System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Defence And Survelliance System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDefenceAndSurvellianceSystem(DefenceAndSurvellianceSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>MIEROF</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>MIEROF</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMIEROF(MIEROF object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Industrial Automation System</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Industrial Automation System</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseIndustrialAutomationSystem(IndustrialAutomationSystem object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Layer Operations</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Layer Operations</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseLayerOperations(LayerOperations object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Multiplication</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Multiplication</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMultiplication(Multiplication object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Addition</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Addition</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAddition(Addition object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Concatenation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Concatenation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseConcatenation(Concatenation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Depth Concatenation</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Depth Concatenation</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDepthConcatenation(DepthConcatenation object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>VGG16</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>VGG16</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseVGG16(VGG16 object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Alex Net</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Alex Net</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseAlexNet(AlexNet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Inception</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Inception</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseInception(Inception object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Res Net50</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Res Net50</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseResNet50(ResNet50 object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Basic Model</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Basic Model</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseBasicModel(BasicModel object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Efficient Net</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Efficient Net</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseEfficientNet(EfficientNet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Mobile Net</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Mobile Net</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseMobileNet(MobileNet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Reg Net</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Reg Net</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseRegNet(RegNet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Dense Net</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Dense Net</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseDenseNet(DenseNet object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //ModlSwitch
