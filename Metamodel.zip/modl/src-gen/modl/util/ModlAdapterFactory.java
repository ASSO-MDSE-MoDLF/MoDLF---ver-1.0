/**
 */
package modl.util;

import modl.*;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;

import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see modl.ModlPackage
 * @generated
 */
public class ModlAdapterFactory extends AdapterFactoryImpl {
	/**
	 * The cached model package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ModlPackage modelPackage;

	/**
	 * Creates an instance of the adapter factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModlAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = ModlPackage.eINSTANCE;
		}
	}

	/**
	 * Returns whether this factory is applicable for the type of the object.
	 * <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	 * @return whether this factory is applicable for the type of the object.
	 * @generated
	 */
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	 * The switch that delegates to the <code>createXXX</code> methods.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ModlSwitch<Adapter> modelSwitch = new ModlSwitch<Adapter>() {
		@Override
		public Adapter caseDLF(DLF object) {
			return createDLFAdapter();
		}

		@Override
		public Adapter caseDataset(Dataset object) {
			return createDatasetAdapter();
		}

		@Override
		public Adapter caseTrainingDS(TrainingDS object) {
			return createTrainingDSAdapter();
		}

		@Override
		public Adapter caseTestingDS(TestingDS object) {
			return createTestingDSAdapter();
		}

		@Override
		public Adapter caseImage(Image object) {
			return createImageAdapter();
		}

		@Override
		public Adapter caseLabel(Label object) {
			return createLabelAdapter();
		}

		@Override
		public Adapter caseCNNModel(CNNModel object) {
			return createCNNModelAdapter();
		}

		@Override
		public Adapter caseTrainingParameters(TrainingParameters object) {
			return createTrainingParametersAdapter();
		}

		@Override
		public Adapter caseTestingParameters(TestingParameters object) {
			return createTestingParametersAdapter();
		}

		@Override
		public Adapter caseLayer(Layer object) {
			return createLayerAdapter();
		}

		@Override
		public Adapter caseInputLayer(InputLayer object) {
			return createInputLayerAdapter();
		}

		@Override
		public Adapter caseConvLayer(ConvLayer object) {
			return createConvLayerAdapter();
		}

		@Override
		public Adapter caseLinearLayer(LinearLayer object) {
			return createLinearLayerAdapter();
		}

		@Override
		public Adapter caseConv2D(Conv2D object) {
			return createConv2DAdapter();
		}

		@Override
		public Adapter casePooling2D(Pooling2D object) {
			return createPooling2DAdapter();
		}

		@Override
		public Adapter caseUpsampling2D(Upsampling2D object) {
			return createUpsampling2DAdapter();
		}

		@Override
		public Adapter caseConv2DTranspose(Conv2DTranspose object) {
			return createConv2DTransposeAdapter();
		}

		@Override
		public Adapter caseDense(Dense object) {
			return createDenseAdapter();
		}

		@Override
		public Adapter caseOutput(Output object) {
			return createOutputAdapter();
		}

		@Override
		public Adapter caseParameters(Parameters object) {
			return createParametersAdapter();
		}

		@Override
		public Adapter caseAutomotiveSystem(AutomotiveSystem object) {
			return createAutomotiveSystemAdapter();
		}

		@Override
		public Adapter caseEastADL(EastADL object) {
			return createEastADLAdapter();
		}

		@Override
		public Adapter caseAUTOSAR(AUTOSAR object) {
			return createAUTOSARAdapter();
		}

		@Override
		public Adapter caseMedicalImagingSystem(MedicalImagingSystem object) {
			return createMedicalImagingSystemAdapter();
		}

		@Override
		public Adapter caseSatelliteImagingSystem(SatelliteImagingSystem object) {
			return createSatelliteImagingSystemAdapter();
		}

		@Override
		public Adapter caseDefenceAndSurvellianceSystem(DefenceAndSurvellianceSystem object) {
			return createDefenceAndSurvellianceSystemAdapter();
		}

		@Override
		public Adapter caseMIEROF(MIEROF object) {
			return createMIEROFAdapter();
		}

		@Override
		public Adapter caseIndustrialAutomationSystem(IndustrialAutomationSystem object) {
			return createIndustrialAutomationSystemAdapter();
		}

		@Override
		public Adapter caseLayerOperations(LayerOperations object) {
			return createLayerOperationsAdapter();
		}

		@Override
		public Adapter caseMultiplication(Multiplication object) {
			return createMultiplicationAdapter();
		}

		@Override
		public Adapter caseAddition(Addition object) {
			return createAdditionAdapter();
		}

		@Override
		public Adapter caseConcatenation(Concatenation object) {
			return createConcatenationAdapter();
		}

		@Override
		public Adapter caseDepthConcatenation(DepthConcatenation object) {
			return createDepthConcatenationAdapter();
		}

		@Override
		public Adapter caseVGG16(VGG16 object) {
			return createVGG16Adapter();
		}

		@Override
		public Adapter caseAlexNet(AlexNet object) {
			return createAlexNetAdapter();
		}

		@Override
		public Adapter caseInception(Inception object) {
			return createInceptionAdapter();
		}

		@Override
		public Adapter caseResNet50(ResNet50 object) {
			return createResNet50Adapter();
		}

		@Override
		public Adapter caseBasicModel(BasicModel object) {
			return createBasicModelAdapter();
		}

		@Override
		public Adapter caseEfficientNet(EfficientNet object) {
			return createEfficientNetAdapter();
		}

		@Override
		public Adapter caseMobileNet(MobileNet object) {
			return createMobileNetAdapter();
		}

		@Override
		public Adapter caseRegNet(RegNet object) {
			return createRegNetAdapter();
		}

		@Override
		public Adapter caseDenseNet(DenseNet object) {
			return createDenseNetAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	 * Creates an adapter for the <code>target</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param target the object to adapt.
	 * @return the adapter for the <code>target</code>.
	 * @generated
	 */
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.DLF <em>DLF</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.DLF
	 * @generated
	 */
	public Adapter createDLFAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Dataset <em>Dataset</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Dataset
	 * @generated
	 */
	public Adapter createDatasetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.TrainingDS <em>Training DS</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.TrainingDS
	 * @generated
	 */
	public Adapter createTrainingDSAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.TestingDS <em>Testing DS</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.TestingDS
	 * @generated
	 */
	public Adapter createTestingDSAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Image <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Image
	 * @generated
	 */
	public Adapter createImageAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Label <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Label
	 * @generated
	 */
	public Adapter createLabelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.CNNModel <em>CNN Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.CNNModel
	 * @generated
	 */
	public Adapter createCNNModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.TrainingParameters <em>Training Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.TrainingParameters
	 * @generated
	 */
	public Adapter createTrainingParametersAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.TestingParameters <em>Testing Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.TestingParameters
	 * @generated
	 */
	public Adapter createTestingParametersAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Layer <em>Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Layer
	 * @generated
	 */
	public Adapter createLayerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.InputLayer <em>Input Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.InputLayer
	 * @generated
	 */
	public Adapter createInputLayerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.ConvLayer <em>Conv Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.ConvLayer
	 * @generated
	 */
	public Adapter createConvLayerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.LinearLayer <em>Linear Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.LinearLayer
	 * @generated
	 */
	public Adapter createLinearLayerAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Conv2D <em>Conv2 D</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Conv2D
	 * @generated
	 */
	public Adapter createConv2DAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Pooling2D <em>Pooling2 D</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Pooling2D
	 * @generated
	 */
	public Adapter createPooling2DAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Upsampling2D <em>Upsampling2 D</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Upsampling2D
	 * @generated
	 */
	public Adapter createUpsampling2DAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Conv2DTranspose <em>Conv2 DTranspose</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Conv2DTranspose
	 * @generated
	 */
	public Adapter createConv2DTransposeAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Dense <em>Dense</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Dense
	 * @generated
	 */
	public Adapter createDenseAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Output <em>Output</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Output
	 * @generated
	 */
	public Adapter createOutputAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Parameters <em>Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Parameters
	 * @generated
	 */
	public Adapter createParametersAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.AutomotiveSystem <em>Automotive System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.AutomotiveSystem
	 * @generated
	 */
	public Adapter createAutomotiveSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.EastADL <em>East ADL</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.EastADL
	 * @generated
	 */
	public Adapter createEastADLAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.AUTOSAR <em>AUTOSAR</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.AUTOSAR
	 * @generated
	 */
	public Adapter createAUTOSARAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.MedicalImagingSystem <em>Medical Imaging System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.MedicalImagingSystem
	 * @generated
	 */
	public Adapter createMedicalImagingSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.SatelliteImagingSystem <em>Satellite Imaging System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.SatelliteImagingSystem
	 * @generated
	 */
	public Adapter createSatelliteImagingSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.DefenceAndSurvellianceSystem <em>Defence And Survelliance System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.DefenceAndSurvellianceSystem
	 * @generated
	 */
	public Adapter createDefenceAndSurvellianceSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.MIEROF <em>MIEROF</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.MIEROF
	 * @generated
	 */
	public Adapter createMIEROFAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.IndustrialAutomationSystem <em>Industrial Automation System</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.IndustrialAutomationSystem
	 * @generated
	 */
	public Adapter createIndustrialAutomationSystemAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.LayerOperations <em>Layer Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.LayerOperations
	 * @generated
	 */
	public Adapter createLayerOperationsAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Multiplication <em>Multiplication</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Multiplication
	 * @generated
	 */
	public Adapter createMultiplicationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Addition <em>Addition</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Addition
	 * @generated
	 */
	public Adapter createAdditionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Concatenation <em>Concatenation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Concatenation
	 * @generated
	 */
	public Adapter createConcatenationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.DepthConcatenation <em>Depth Concatenation</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.DepthConcatenation
	 * @generated
	 */
	public Adapter createDepthConcatenationAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.VGG16 <em>VGG16</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.VGG16
	 * @generated
	 */
	public Adapter createVGG16Adapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.AlexNet <em>Alex Net</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.AlexNet
	 * @generated
	 */
	public Adapter createAlexNetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.Inception <em>Inception</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.Inception
	 * @generated
	 */
	public Adapter createInceptionAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.ResNet50 <em>Res Net50</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.ResNet50
	 * @generated
	 */
	public Adapter createResNet50Adapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.BasicModel <em>Basic Model</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.BasicModel
	 * @generated
	 */
	public Adapter createBasicModelAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.EfficientNet <em>Efficient Net</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.EfficientNet
	 * @generated
	 */
	public Adapter createEfficientNetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.MobileNet <em>Mobile Net</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.MobileNet
	 * @generated
	 */
	public Adapter createMobileNetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.RegNet <em>Reg Net</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.RegNet
	 * @generated
	 */
	public Adapter createRegNetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for an object of class '{@link modl.DenseNet <em>Dense Net</em>}'.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @see modl.DenseNet
	 * @generated
	 */
	public Adapter createDenseNetAdapter() {
		return null;
	}

	/**
	 * Creates a new adapter for the default case.
	 * <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	 * @return the new adapter.
	 * @generated
	 */
	public Adapter createEObjectAdapter() {
		return null;
	}

} //ModlAdapterFactory
