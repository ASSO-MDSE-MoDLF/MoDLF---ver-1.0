/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Efficient Net</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getEfficientNet()
 * @model
 * @generated
 */
public interface EfficientNet extends BasicModel {
} // EfficientNet
