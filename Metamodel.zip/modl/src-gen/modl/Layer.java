/**
 */
package modl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Layer#getName <em>Name</em>}</li>
 *   <li>{@link modl.Layer#getActivation <em>Activation</em>}</li>
 *   <li>{@link modl.Layer#isBatch_normalization <em>Batch normalization</em>}</li>
 *   <li>{@link modl.Layer#getLayer <em>Layer</em>}</li>
 *   <li>{@link modl.Layer#getLayereOpposite <em>Layere Opposite</em>}</li>
 *   <li>{@link modl.Layer#getRegularizer <em>Regularizer</em>}</li>
 *   <li>{@link modl.Layer#getReg_rate <em>Reg rate</em>}</li>
 *   <li>{@link modl.Layer#isDo_dropout <em>Do dropout</em>}</li>
 *   <li>{@link modl.Layer#getDropout_rate <em>Dropout rate</em>}</li>
 *   <li>{@link modl.Layer#getLayeroperations <em>Layeroperations</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getLayer()
 * @model abstract="true"
 * @generated
 */
public interface Layer extends EObject {
	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see modl.ModlPackage#getLayer_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link modl.Layer#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Activation</b></em>' attribute.
	 * The literals are from the enumeration {@link modl.ActivationType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activation</em>' attribute.
	 * @see modl.ActivationType
	 * @see #setActivation(ActivationType)
	 * @see modl.ModlPackage#getLayer_Activation()
	 * @model
	 * @generated
	 */
	ActivationType getActivation();

	/**
	 * Sets the value of the '{@link modl.Layer#getActivation <em>Activation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activation</em>' attribute.
	 * @see modl.ActivationType
	 * @see #getActivation()
	 * @generated
	 */
	void setActivation(ActivationType value);

	/**
	 * Returns the value of the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Batch normalization</em>' attribute.
	 * @see #setBatch_normalization(boolean)
	 * @see modl.ModlPackage#getLayer_Batch_normalization()
	 * @model
	 * @generated
	 */
	boolean isBatch_normalization();

	/**
	 * Sets the value of the '{@link modl.Layer#isBatch_normalization <em>Batch normalization</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Batch normalization</em>' attribute.
	 * @see #isBatch_normalization()
	 * @generated
	 */
	void setBatch_normalization(boolean value);

	/**
	 * Returns the value of the '<em><b>Layer</b></em>' reference list.
	 * The list contents are of type {@link modl.Layer}.
	 * It is bidirectional and its opposite is '{@link modl.Layer#getLayereOpposite <em>Layere Opposite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layer</em>' reference list.
	 * @see modl.ModlPackage#getLayer_Layer()
	 * @see modl.Layer#getLayereOpposite
	 * @model opposite="layereOpposite"
	 * @generated
	 */
	EList<Layer> getLayer();

	/**
	 * Returns the value of the '<em><b>Layere Opposite</b></em>' reference list.
	 * The list contents are of type {@link modl.Layer}.
	 * It is bidirectional and its opposite is '{@link modl.Layer#getLayer <em>Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layere Opposite</em>' reference list.
	 * @see modl.ModlPackage#getLayer_LayereOpposite()
	 * @see modl.Layer#getLayer
	 * @model opposite="layer"
	 * @generated
	 */
	EList<Layer> getLayereOpposite();

	/**
	 * Returns the value of the '<em><b>Layeroperations</b></em>' reference list.
	 * The list contents are of type {@link modl.LayerOperations}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layeroperations</em>' reference list.
	 * @see modl.ModlPackage#getLayer_Layeroperations()
	 * @model
	 * @generated
	 */
	EList<LayerOperations> getLayeroperations();

	/**
	 * Returns the value of the '<em><b>Regularizer</b></em>' attribute.
	 * The default value is <code>"null"</code>.
	 * The literals are from the enumeration {@link modl.RegulizerType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Regularizer</em>' attribute.
	 * @see modl.RegulizerType
	 * @see #setRegularizer(RegulizerType)
	 * @see modl.ModlPackage#getLayer_Regularizer()
	 * @model default="null"
	 * @generated
	 */
	RegulizerType getRegularizer();

	/**
	 * Sets the value of the '{@link modl.Layer#getRegularizer <em>Regularizer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Regularizer</em>' attribute.
	 * @see modl.RegulizerType
	 * @see #getRegularizer()
	 * @generated
	 */
	void setRegularizer(RegulizerType value);

	/**
	 * Returns the value of the '<em><b>Reg rate</b></em>' attribute.
	 * The default value is <code>"0.001"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Reg rate</em>' attribute.
	 * @see #setReg_rate(float)
	 * @see modl.ModlPackage#getLayer_Reg_rate()
	 * @model default="0.001"
	 * @generated
	 */
	float getReg_rate();

	/**
	 * Sets the value of the '{@link modl.Layer#getReg_rate <em>Reg rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Reg rate</em>' attribute.
	 * @see #getReg_rate()
	 * @generated
	 */
	void setReg_rate(float value);

	/**
	 * Returns the value of the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Do dropout</em>' attribute.
	 * @see #setDo_dropout(boolean)
	 * @see modl.ModlPackage#getLayer_Do_dropout()
	 * @model
	 * @generated
	 */
	boolean isDo_dropout();

	/**
	 * Sets the value of the '{@link modl.Layer#isDo_dropout <em>Do dropout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Do dropout</em>' attribute.
	 * @see #isDo_dropout()
	 * @generated
	 */
	void setDo_dropout(boolean value);

	/**
	 * Returns the value of the '<em><b>Dropout rate</b></em>' attribute.
	 * The default value is <code>"0.01"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dropout rate</em>' attribute.
	 * @see #setDropout_rate(float)
	 * @see modl.ModlPackage#getLayer_Dropout_rate()
	 * @model default="0.01"
	 * @generated
	 */
	float getDropout_rate();

	/**
	 * Sets the value of the '{@link modl.Layer#getDropout_rate <em>Dropout rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dropout rate</em>' attribute.
	 * @see #getDropout_rate()
	 * @generated
	 */
	void setDropout_rate(float value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void activation_function();

} // Layer
