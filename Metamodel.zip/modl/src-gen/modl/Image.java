/**
 */
package modl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Image#getLabel <em>Label</em>}</li>
 *   <li>{@link modl.Image#getName <em>Name</em>}</li>
 *   <li>{@link modl.Image#getFile_type <em>File type</em>}</li>
 *   <li>{@link modl.Image#getImage_width <em>Image width</em>}</li>
 *   <li>{@link modl.Image#getImage_height <em>Image height</em>}</li>
 *   <li>{@link modl.Image#getImage_channels <em>Image channels</em>}</li>
 *   <li>{@link modl.Image#getInputlayer <em>Inputlayer</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getImage()
 * @model
 * @generated
 */
public interface Image extends EObject {
	/**
	 * Returns the value of the '<em><b>Label</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link modl.Label#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' reference.
	 * @see #setLabel(Label)
	 * @see modl.ModlPackage#getImage_Label()
	 * @see modl.Label#getImage
	 * @model opposite="image" required="true"
	 * @generated
	 */
	Label getLabel();

	/**
	 * Sets the value of the '{@link modl.Image#getLabel <em>Label</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Label</em>' reference.
	 * @see #getLabel()
	 * @generated
	 */
	void setLabel(Label value);

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see modl.ModlPackage#getImage_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link modl.Image#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>File type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>File type</em>' attribute.
	 * @see #setFile_type(String)
	 * @see modl.ModlPackage#getImage_File_type()
	 * @model
	 * @generated
	 */
	String getFile_type();

	/**
	 * Sets the value of the '{@link modl.Image#getFile_type <em>File type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>File type</em>' attribute.
	 * @see #getFile_type()
	 * @generated
	 */
	void setFile_type(String value);

	/**
	 * Returns the value of the '<em><b>Image width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image width</em>' attribute.
	 * @see #setImage_width(int)
	 * @see modl.ModlPackage#getImage_Image_width()
	 * @model
	 * @generated
	 */
	int getImage_width();

	/**
	 * Sets the value of the '{@link modl.Image#getImage_width <em>Image width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Image width</em>' attribute.
	 * @see #getImage_width()
	 * @generated
	 */
	void setImage_width(int value);

	/**
	 * Returns the value of the '<em><b>Image height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image height</em>' attribute.
	 * @see #setImage_height(int)
	 * @see modl.ModlPackage#getImage_Image_height()
	 * @model
	 * @generated
	 */
	int getImage_height();

	/**
	 * Sets the value of the '{@link modl.Image#getImage_height <em>Image height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Image height</em>' attribute.
	 * @see #getImage_height()
	 * @generated
	 */
	void setImage_height(int value);

	/**
	 * Returns the value of the '<em><b>Image channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image channels</em>' attribute.
	 * @see #setImage_channels(int)
	 * @see modl.ModlPackage#getImage_Image_channels()
	 * @model
	 * @generated
	 */
	int getImage_channels();

	/**
	 * Sets the value of the '{@link modl.Image#getImage_channels <em>Image channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Image channels</em>' attribute.
	 * @see #getImage_channels()
	 * @generated
	 */
	void setImage_channels(int value);

	/**
	 * Returns the value of the '<em><b>Inputlayer</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link modl.InputLayer#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Inputlayer</em>' reference.
	 * @see #setInputlayer(InputLayer)
	 * @see modl.ModlPackage#getImage_Inputlayer()
	 * @see modl.InputLayer#getImage
	 * @model opposite="image"
	 * @generated
	 */
	InputLayer getInputlayer();

	/**
	 * Sets the value of the '{@link modl.Image#getInputlayer <em>Inputlayer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Inputlayer</em>' reference.
	 * @see #getInputlayer()
	 * @generated
	 */
	void setInputlayer(InputLayer value);

} // Image
