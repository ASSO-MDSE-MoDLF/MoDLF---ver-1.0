/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Concatenation</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getConcatenation()
 * @model
 * @generated
 */
public interface Concatenation extends LayerOperations {
} // Concatenation
