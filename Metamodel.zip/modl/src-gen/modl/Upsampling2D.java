/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Upsampling2 D</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getUpsampling2D()
 * @model
 * @generated
 */
public interface Upsampling2D extends ConvLayer {
} // Upsampling2D
