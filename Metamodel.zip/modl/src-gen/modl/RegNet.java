/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reg Net</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getRegNet()
 * @model
 * @generated
 */
public interface RegNet extends BasicModel {
} // RegNet
