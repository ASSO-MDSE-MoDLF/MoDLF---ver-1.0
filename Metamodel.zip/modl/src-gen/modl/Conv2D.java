/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conv2 D</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getConv2D()
 * @model
 * @generated
 */
public interface Conv2D extends ConvLayer {
} // Conv2D
