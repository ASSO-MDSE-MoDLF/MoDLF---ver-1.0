/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Training DS</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.TrainingDS#getX_train <em>Xtrain</em>}</li>
 *   <li>{@link modl.TrainingDS#getY_train <em>Ytrain</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getTrainingDS()
 * @model
 * @generated
 */
public interface TrainingDS extends Dataset {
	/**
	 * Returns the value of the '<em><b>Xtrain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Xtrain</em>' attribute.
	 * @see #setX_train(Object)
	 * @see modl.ModlPackage#getTrainingDS_X_train()
	 * @model dataType="modl.ImageArray"
	 * @generated
	 */
	Object getX_train();

	/**
	 * Sets the value of the '{@link modl.TrainingDS#getX_train <em>Xtrain</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Xtrain</em>' attribute.
	 * @see #getX_train()
	 * @generated
	 */
	void setX_train(Object value);

	/**
	 * Returns the value of the '<em><b>Ytrain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ytrain</em>' attribute.
	 * @see #setY_train(Object)
	 * @see modl.ModlPackage#getTrainingDS_Y_train()
	 * @model dataType="modl.LabelArray"
	 * @generated
	 */
	Object getY_train();

	/**
	 * Sets the value of the '{@link modl.TrainingDS#getY_train <em>Ytrain</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ytrain</em>' attribute.
	 * @see #getY_train()
	 * @generated
	 */
	void setY_train(Object value);

} // TrainingDS
