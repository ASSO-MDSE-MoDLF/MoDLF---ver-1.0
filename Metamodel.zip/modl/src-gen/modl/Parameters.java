/**
 */
package modl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parameters</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Parameters#getBatch_size <em>Batch size</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getParameters()
 * @model abstract="true"
 * @generated
 */
public interface Parameters extends EObject {
	/**
	 * Returns the value of the '<em><b>Batch size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Batch size</em>' attribute.
	 * @see #setBatch_size(int)
	 * @see modl.ModlPackage#getParameters_Batch_size()
	 * @model
	 * @generated
	 */
	int getBatch_size();

	/**
	 * Sets the value of the '{@link modl.Parameters#getBatch_size <em>Batch size</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Batch size</em>' attribute.
	 * @see #getBatch_size()
	 * @generated
	 */
	void setBatch_size(int value);

} // Parameters
