/**
 */
package modl;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Input Layer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.InputLayer#getInput_width <em>Input width</em>}</li>
 *   <li>{@link modl.InputLayer#getInput_height <em>Input height</em>}</li>
 *   <li>{@link modl.InputLayer#getInput_channels <em>Input channels</em>}</li>
 *   <li>{@link modl.InputLayer#getArray_of_classes <em>Array of classes</em>}</li>
 *   <li>{@link modl.InputLayer#getImage <em>Image</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getInputLayer()
 * @model
 * @generated
 */
public interface InputLayer extends Layer {
	/**
	 * Returns the value of the '<em><b>Input width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input width</em>' attribute.
	 * @see #setInput_width(int)
	 * @see modl.ModlPackage#getInputLayer_Input_width()
	 * @model
	 * @generated
	 */
	int getInput_width();

	/**
	 * Sets the value of the '{@link modl.InputLayer#getInput_width <em>Input width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input width</em>' attribute.
	 * @see #getInput_width()
	 * @generated
	 */
	void setInput_width(int value);

	/**
	 * Returns the value of the '<em><b>Input height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input height</em>' attribute.
	 * @see #setInput_height(int)
	 * @see modl.ModlPackage#getInputLayer_Input_height()
	 * @model
	 * @generated
	 */
	int getInput_height();

	/**
	 * Sets the value of the '{@link modl.InputLayer#getInput_height <em>Input height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input height</em>' attribute.
	 * @see #getInput_height()
	 * @generated
	 */
	void setInput_height(int value);

	/**
	 * Returns the value of the '<em><b>Input channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Input channels</em>' attribute.
	 * @see #setInput_channels(int)
	 * @see modl.ModlPackage#getInputLayer_Input_channels()
	 * @model
	 * @generated
	 */
	int getInput_channels();

	/**
	 * Sets the value of the '{@link modl.InputLayer#getInput_channels <em>Input channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Input channels</em>' attribute.
	 * @see #getInput_channels()
	 * @generated
	 */
	void setInput_channels(int value);

	/**
	 * Returns the value of the '<em><b>Array of classes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Array of classes</em>' attribute.
	 * @see #setArray_of_classes(String)
	 * @see modl.ModlPackage#getInputLayer_Array_of_classes()
	 * @model
	 * @generated
	 */
	String getArray_of_classes();

	/**
	 * Sets the value of the '{@link modl.InputLayer#getArray_of_classes <em>Array of classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Array of classes</em>' attribute.
	 * @see #getArray_of_classes()
	 * @generated
	 */
	void setArray_of_classes(String value);

	/**
	 * Returns the value of the '<em><b>Image</b></em>' reference list.
	 * The list contents are of type {@link modl.Image}.
	 * It is bidirectional and its opposite is '{@link modl.Image#getInputlayer <em>Inputlayer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image</em>' reference list.
	 * @see modl.ModlPackage#getInputLayer_Image()
	 * @see modl.Image#getInputlayer
	 * @model opposite="inputlayer"
	 * @generated
	 */
	EList<Image> getImage();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void reshape(double scale_factor);

} // InputLayer
