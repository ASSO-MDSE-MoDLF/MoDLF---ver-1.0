/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Output</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Output#getOutput_classes <em>Output classes</em>}</li>
 *   <li>{@link modl.Output#getArray_of_classes <em>Array of classes</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getOutput()
 * @model
 * @generated
 */
public interface Output extends LinearLayer {
	/**
	 * Returns the value of the '<em><b>Output classes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Output classes</em>' attribute.
	 * @see #setOutput_classes(int)
	 * @see modl.ModlPackage#getOutput_Output_classes()
	 * @model
	 * @generated
	 */
	int getOutput_classes();

	/**
	 * Sets the value of the '{@link modl.Output#getOutput_classes <em>Output classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Output classes</em>' attribute.
	 * @see #getOutput_classes()
	 * @generated
	 */
	void setOutput_classes(int value);

	/**
	 * Returns the value of the '<em><b>Array of classes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Array of classes</em>' attribute.
	 * @see #setArray_of_classes(int)
	 * @see modl.ModlPackage#getOutput_Array_of_classes()
	 * @model
	 * @generated
	 */
	int getArray_of_classes();

	/**
	 * Sets the value of the '{@link modl.Output#getArray_of_classes <em>Array of classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Array of classes</em>' attribute.
	 * @see #getArray_of_classes()
	 * @generated
	 */
	void setArray_of_classes(int value);

} // Output
