/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Multiplication</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getMultiplication()
 * @model
 * @generated
 */
public interface Multiplication extends LayerOperations {
} // Multiplication
