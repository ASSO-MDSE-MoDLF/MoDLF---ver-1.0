/**
 */
package modl;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each operation of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see modl.ModlFactory
 * @model kind="package"
 * @generated
 */
public interface ModlPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "modl";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://www.example.org/modl";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "modl";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ModlPackage eINSTANCE = modl.impl.ModlPackageImpl.init();

	/**
	 * The meta object id for the '{@link modl.impl.DLFImpl <em>DLF</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.DLFImpl
	 * @see modl.impl.ModlPackageImpl#getDLF()
	 * @generated
	 */
	int DLF = 0;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DLF__DATASET = 0;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DLF__CNNMODEL = 1;

	/**
	 * The feature id for the '<em><b>Basicmodel</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DLF__BASICMODEL = 2;

	/**
	 * The number of structural features of the '<em>DLF</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DLF_FEATURE_COUNT = 3;

	/**
	 * The number of operations of the '<em>DLF</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DLF_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.DatasetImpl <em>Dataset</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.DatasetImpl
	 * @see modl.impl.ModlPackageImpl#getDataset()
	 * @generated
	 */
	int DATASET = 1;

	/**
	 * The feature id for the '<em><b>Qual path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATASET__QUAL_PATH = 0;

	/**
	 * The feature id for the '<em><b>Image</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATASET__IMAGE = 1;

	/**
	 * The feature id for the '<em><b>Label</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATASET__LABEL = 2;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATASET__CNNMODEL = 3;

	/**
	 * The number of structural features of the '<em>Dataset</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATASET_FEATURE_COUNT = 4;

	/**
	 * The number of operations of the '<em>Dataset</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DATASET_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.TrainingDSImpl <em>Training DS</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.TrainingDSImpl
	 * @see modl.impl.ModlPackageImpl#getTrainingDS()
	 * @generated
	 */
	int TRAINING_DS = 2;

	/**
	 * The feature id for the '<em><b>Qual path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS__QUAL_PATH = DATASET__QUAL_PATH;

	/**
	 * The feature id for the '<em><b>Image</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS__IMAGE = DATASET__IMAGE;

	/**
	 * The feature id for the '<em><b>Label</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS__LABEL = DATASET__LABEL;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS__CNNMODEL = DATASET__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Xtrain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS__XTRAIN = DATASET_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ytrain</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS__YTRAIN = DATASET_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Training DS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS_FEATURE_COUNT = DATASET_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Training DS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_DS_OPERATION_COUNT = DATASET_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.TestingDSImpl <em>Testing DS</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.TestingDSImpl
	 * @see modl.impl.ModlPackageImpl#getTestingDS()
	 * @generated
	 */
	int TESTING_DS = 3;

	/**
	 * The feature id for the '<em><b>Qual path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS__QUAL_PATH = DATASET__QUAL_PATH;

	/**
	 * The feature id for the '<em><b>Image</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS__IMAGE = DATASET__IMAGE;

	/**
	 * The feature id for the '<em><b>Label</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS__LABEL = DATASET__LABEL;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS__CNNMODEL = DATASET__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Xtest</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS__XTEST = DATASET_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Ytest</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS__YTEST = DATASET_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Testing DS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS_FEATURE_COUNT = DATASET_FEATURE_COUNT + 2;

	/**
	 * The number of operations of the '<em>Testing DS</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_DS_OPERATION_COUNT = DATASET_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.ImageImpl <em>Image</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.ImageImpl
	 * @see modl.impl.ModlPackageImpl#getImage()
	 * @generated
	 */
	int IMAGE = 4;

	/**
	 * The feature id for the '<em><b>Label</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__LABEL = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__NAME = 1;

	/**
	 * The feature id for the '<em><b>File type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__FILE_TYPE = 2;

	/**
	 * The feature id for the '<em><b>Image width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__IMAGE_WIDTH = 3;

	/**
	 * The feature id for the '<em><b>Image height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__IMAGE_HEIGHT = 4;

	/**
	 * The feature id for the '<em><b>Image channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__IMAGE_CHANNELS = 5;

	/**
	 * The feature id for the '<em><b>Inputlayer</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE__INPUTLAYER = 6;

	/**
	 * The number of structural features of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_FEATURE_COUNT = 7;

	/**
	 * The number of operations of the '<em>Image</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int IMAGE_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.LabelImpl <em>Label</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.LabelImpl
	 * @see modl.impl.ModlPackageImpl#getLabel()
	 * @generated
	 */
	int LABEL = 5;

	/**
	 * The feature id for the '<em><b>Image</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LABEL__IMAGE = 0;

	/**
	 * The number of structural features of the '<em>Label</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LABEL_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Label</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LABEL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.CNNModelImpl <em>CNN Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.CNNModelImpl
	 * @see modl.impl.ModlPackageImpl#getCNNModel()
	 * @generated
	 */
	int CNN_MODEL = 6;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL__DATASET = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL__NAME = 1;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL__LAYER = 2;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL__CNNMODEL = 3;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL__CNNMODELE_OPPOSITE = 4;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL__PARAMETERS = 5;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL__LAYEROPERATIONS = 6;

	/**
	 * The number of structural features of the '<em>CNN Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL_FEATURE_COUNT = 7;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL___COMPILE_MODEL = 0;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL___LAYERS = 1;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL___PARAMS = 2;

	/**
	 * The number of operations of the '<em>CNN Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CNN_MODEL_OPERATION_COUNT = 3;

	/**
	 * The meta object id for the '{@link modl.impl.ParametersImpl <em>Parameters</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.ParametersImpl
	 * @see modl.impl.ModlPackageImpl#getParameters()
	 * @generated
	 */
	int PARAMETERS = 19;

	/**
	 * The feature id for the '<em><b>Batch size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETERS__BATCH_SIZE = 0;

	/**
	 * The number of structural features of the '<em>Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETERS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int PARAMETERS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.TrainingParametersImpl <em>Training Parameters</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.TrainingParametersImpl
	 * @see modl.impl.ModlPackageImpl#getTrainingParameters()
	 * @generated
	 */
	int TRAINING_PARAMETERS = 7;

	/**
	 * The feature id for the '<em><b>Batch size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__BATCH_SIZE = PARAMETERS__BATCH_SIZE;

	/**
	 * The feature id for the '<em><b>Epochs</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__EPOCHS = PARAMETERS_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Objective function</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__OBJECTIVE_FUNCTION = PARAMETERS_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Optimizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__OPTIMIZER = PARAMETERS_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Metric</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__METRIC = PARAMETERS_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Learning rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__LEARNING_RATE = PARAMETERS_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Decay rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__DECAY_RATE = PARAMETERS_FEATURE_COUNT + 5;

	/**
	 * The feature id for the '<em><b>Momentum</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS__MOMENTUM = PARAMETERS_FEATURE_COUNT + 6;

	/**
	 * The number of structural features of the '<em>Training Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS_FEATURE_COUNT = PARAMETERS_FEATURE_COUNT + 7;

	/**
	 * The number of operations of the '<em>Training Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TRAINING_PARAMETERS_OPERATION_COUNT = PARAMETERS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.TestingParametersImpl <em>Testing Parameters</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.TestingParametersImpl
	 * @see modl.impl.ModlPackageImpl#getTestingParameters()
	 * @generated
	 */
	int TESTING_PARAMETERS = 8;

	/**
	 * The feature id for the '<em><b>Batch size</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_PARAMETERS__BATCH_SIZE = PARAMETERS__BATCH_SIZE;

	/**
	 * The feature id for the '<em><b>Confidence</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_PARAMETERS__CONFIDENCE = PARAMETERS_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Testing Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_PARAMETERS_FEATURE_COUNT = PARAMETERS_FEATURE_COUNT + 1;

	/**
	 * The number of operations of the '<em>Testing Parameters</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int TESTING_PARAMETERS_OPERATION_COUNT = PARAMETERS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.LayerImpl <em>Layer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.LayerImpl
	 * @see modl.impl.ModlPackageImpl#getLayer()
	 * @generated
	 */
	int LAYER = 9;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__NAME = 0;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__ACTIVATION = 1;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__BATCH_NORMALIZATION = 2;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__LAYER = 3;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__LAYERE_OPPOSITE = 4;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__REGULARIZER = 5;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__REG_RATE = 6;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__DO_DROPOUT = 7;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__DROPOUT_RATE = 8;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER__LAYEROPERATIONS = 9;

	/**
	 * The number of structural features of the '<em>Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER_FEATURE_COUNT = 10;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER___ACTIVATION_FUNCTION = 0;

	/**
	 * The number of operations of the '<em>Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER_OPERATION_COUNT = 1;

	/**
	 * The meta object id for the '{@link modl.impl.InputLayerImpl <em>Input Layer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.InputLayerImpl
	 * @see modl.impl.ModlPackageImpl#getInputLayer()
	 * @generated
	 */
	int INPUT_LAYER = 10;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__NAME = LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__ACTIVATION = LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__BATCH_NORMALIZATION = LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__LAYER = LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__LAYERE_OPPOSITE = LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__REGULARIZER = LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__REG_RATE = LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__DO_DROPOUT = LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__DROPOUT_RATE = LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__LAYEROPERATIONS = LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Input width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__INPUT_WIDTH = LAYER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Input height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__INPUT_HEIGHT = LAYER_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Input channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__INPUT_CHANNELS = LAYER_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Array of classes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__ARRAY_OF_CLASSES = LAYER_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Image</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER__IMAGE = LAYER_FEATURE_COUNT + 4;

	/**
	 * The number of structural features of the '<em>Input Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER_FEATURE_COUNT = LAYER_FEATURE_COUNT + 5;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER___ACTIVATION_FUNCTION = LAYER___ACTIVATION_FUNCTION;

	/**
	 * The operation id for the '<em>Reshape</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER___RESHAPE__DOUBLE = LAYER_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Input Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INPUT_LAYER_OPERATION_COUNT = LAYER_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link modl.impl.ConvLayerImpl <em>Conv Layer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.ConvLayerImpl
	 * @see modl.impl.ModlPackageImpl#getConvLayer()
	 * @generated
	 */
	int CONV_LAYER = 11;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__NAME = LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__ACTIVATION = LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__BATCH_NORMALIZATION = LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__LAYER = LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__LAYERE_OPPOSITE = LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__REGULARIZER = LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__REG_RATE = LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__DO_DROPOUT = LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__DROPOUT_RATE = LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__LAYEROPERATIONS = LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Kernel width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__KERNEL_WIDTH = LAYER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Kernel height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__KERNEL_HEIGHT = LAYER_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Stride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__STRIDE = LAYER_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Padding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__PADDING = LAYER_FEATURE_COUNT + 3;

	/**
	 * The feature id for the '<em><b>Output channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__OUTPUT_CHANNELS = LAYER_FEATURE_COUNT + 4;

	/**
	 * The feature id for the '<em><b>Flatten</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER__FLATTEN = LAYER_FEATURE_COUNT + 5;

	/**
	 * The number of structural features of the '<em>Conv Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER_FEATURE_COUNT = LAYER_FEATURE_COUNT + 6;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER___ACTIVATION_FUNCTION = LAYER___ACTIVATION_FUNCTION;

	/**
	 * The operation id for the '<em>Output feature map</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT = LAYER_OPERATION_COUNT + 0;

	/**
	 * The number of operations of the '<em>Conv Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV_LAYER_OPERATION_COUNT = LAYER_OPERATION_COUNT + 1;

	/**
	 * The meta object id for the '{@link modl.impl.LinearLayerImpl <em>Linear Layer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.LinearLayerImpl
	 * @see modl.impl.ModlPackageImpl#getLinearLayer()
	 * @generated
	 */
	int LINEAR_LAYER = 12;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__NAME = LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__ACTIVATION = LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__BATCH_NORMALIZATION = LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__LAYER = LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__LAYERE_OPPOSITE = LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__REGULARIZER = LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__REG_RATE = LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__DO_DROPOUT = LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__DROPOUT_RATE = LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER__LAYEROPERATIONS = LAYER__LAYEROPERATIONS;

	/**
	 * The number of structural features of the '<em>Linear Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER_FEATURE_COUNT = LAYER_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER___ACTIVATION_FUNCTION = LAYER___ACTIVATION_FUNCTION;

	/**
	 * The number of operations of the '<em>Linear Layer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LINEAR_LAYER_OPERATION_COUNT = LAYER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.Conv2DImpl <em>Conv2 D</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.Conv2DImpl
	 * @see modl.impl.ModlPackageImpl#getConv2D()
	 * @generated
	 */
	int CONV2_D = 13;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__NAME = CONV_LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__ACTIVATION = CONV_LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__BATCH_NORMALIZATION = CONV_LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__LAYER = CONV_LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__LAYERE_OPPOSITE = CONV_LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__REGULARIZER = CONV_LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__REG_RATE = CONV_LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__DO_DROPOUT = CONV_LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__DROPOUT_RATE = CONV_LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__LAYEROPERATIONS = CONV_LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Kernel width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__KERNEL_WIDTH = CONV_LAYER__KERNEL_WIDTH;

	/**
	 * The feature id for the '<em><b>Kernel height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__KERNEL_HEIGHT = CONV_LAYER__KERNEL_HEIGHT;

	/**
	 * The feature id for the '<em><b>Stride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__STRIDE = CONV_LAYER__STRIDE;

	/**
	 * The feature id for the '<em><b>Padding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__PADDING = CONV_LAYER__PADDING;

	/**
	 * The feature id for the '<em><b>Output channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__OUTPUT_CHANNELS = CONV_LAYER__OUTPUT_CHANNELS;

	/**
	 * The feature id for the '<em><b>Flatten</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D__FLATTEN = CONV_LAYER__FLATTEN;

	/**
	 * The number of structural features of the '<em>Conv2 D</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D_FEATURE_COUNT = CONV_LAYER_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D___ACTIVATION_FUNCTION = CONV_LAYER___ACTIVATION_FUNCTION;

	/**
	 * The operation id for the '<em>Output feature map</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D___OUTPUT_FEATURE_MAP__INT_INT_INT = CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT;

	/**
	 * The number of operations of the '<em>Conv2 D</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_D_OPERATION_COUNT = CONV_LAYER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.Pooling2DImpl <em>Pooling2 D</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.Pooling2DImpl
	 * @see modl.impl.ModlPackageImpl#getPooling2D()
	 * @generated
	 */
	int POOLING2_D = 14;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__NAME = CONV_LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__ACTIVATION = CONV_LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__BATCH_NORMALIZATION = CONV_LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__LAYER = CONV_LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__LAYERE_OPPOSITE = CONV_LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__REGULARIZER = CONV_LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__REG_RATE = CONV_LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__DO_DROPOUT = CONV_LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__DROPOUT_RATE = CONV_LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__LAYEROPERATIONS = CONV_LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Kernel width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__KERNEL_WIDTH = CONV_LAYER__KERNEL_WIDTH;

	/**
	 * The feature id for the '<em><b>Kernel height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__KERNEL_HEIGHT = CONV_LAYER__KERNEL_HEIGHT;

	/**
	 * The feature id for the '<em><b>Stride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__STRIDE = CONV_LAYER__STRIDE;

	/**
	 * The feature id for the '<em><b>Padding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__PADDING = CONV_LAYER__PADDING;

	/**
	 * The feature id for the '<em><b>Output channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__OUTPUT_CHANNELS = CONV_LAYER__OUTPUT_CHANNELS;

	/**
	 * The feature id for the '<em><b>Flatten</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__FLATTEN = CONV_LAYER__FLATTEN;

	/**
	 * The feature id for the '<em><b>Type</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D__TYPE = CONV_LAYER_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Pooling2 D</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D_FEATURE_COUNT = CONV_LAYER_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D___ACTIVATION_FUNCTION = CONV_LAYER___ACTIVATION_FUNCTION;

	/**
	 * The operation id for the '<em>Output feature map</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D___OUTPUT_FEATURE_MAP__INT_INT_INT = CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT;

	/**
	 * The number of operations of the '<em>Pooling2 D</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int POOLING2_D_OPERATION_COUNT = CONV_LAYER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.Upsampling2DImpl <em>Upsampling2 D</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.Upsampling2DImpl
	 * @see modl.impl.ModlPackageImpl#getUpsampling2D()
	 * @generated
	 */
	int UPSAMPLING2_D = 15;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__NAME = CONV_LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__ACTIVATION = CONV_LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__BATCH_NORMALIZATION = CONV_LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__LAYER = CONV_LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__LAYERE_OPPOSITE = CONV_LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__REGULARIZER = CONV_LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__REG_RATE = CONV_LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__DO_DROPOUT = CONV_LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__DROPOUT_RATE = CONV_LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__LAYEROPERATIONS = CONV_LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Kernel width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__KERNEL_WIDTH = CONV_LAYER__KERNEL_WIDTH;

	/**
	 * The feature id for the '<em><b>Kernel height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__KERNEL_HEIGHT = CONV_LAYER__KERNEL_HEIGHT;

	/**
	 * The feature id for the '<em><b>Stride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__STRIDE = CONV_LAYER__STRIDE;

	/**
	 * The feature id for the '<em><b>Padding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__PADDING = CONV_LAYER__PADDING;

	/**
	 * The feature id for the '<em><b>Output channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__OUTPUT_CHANNELS = CONV_LAYER__OUTPUT_CHANNELS;

	/**
	 * The feature id for the '<em><b>Flatten</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D__FLATTEN = CONV_LAYER__FLATTEN;

	/**
	 * The number of structural features of the '<em>Upsampling2 D</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D_FEATURE_COUNT = CONV_LAYER_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D___ACTIVATION_FUNCTION = CONV_LAYER___ACTIVATION_FUNCTION;

	/**
	 * The operation id for the '<em>Output feature map</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D___OUTPUT_FEATURE_MAP__INT_INT_INT = CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT;

	/**
	 * The number of operations of the '<em>Upsampling2 D</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int UPSAMPLING2_D_OPERATION_COUNT = CONV_LAYER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.Conv2DTransposeImpl <em>Conv2 DTranspose</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.Conv2DTransposeImpl
	 * @see modl.impl.ModlPackageImpl#getConv2DTranspose()
	 * @generated
	 */
	int CONV2_DTRANSPOSE = 16;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__NAME = CONV_LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__ACTIVATION = CONV_LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__BATCH_NORMALIZATION = CONV_LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__LAYER = CONV_LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__LAYERE_OPPOSITE = CONV_LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__REGULARIZER = CONV_LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__REG_RATE = CONV_LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__DO_DROPOUT = CONV_LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__DROPOUT_RATE = CONV_LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__LAYEROPERATIONS = CONV_LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Kernel width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__KERNEL_WIDTH = CONV_LAYER__KERNEL_WIDTH;

	/**
	 * The feature id for the '<em><b>Kernel height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__KERNEL_HEIGHT = CONV_LAYER__KERNEL_HEIGHT;

	/**
	 * The feature id for the '<em><b>Stride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__STRIDE = CONV_LAYER__STRIDE;

	/**
	 * The feature id for the '<em><b>Padding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__PADDING = CONV_LAYER__PADDING;

	/**
	 * The feature id for the '<em><b>Output channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__OUTPUT_CHANNELS = CONV_LAYER__OUTPUT_CHANNELS;

	/**
	 * The feature id for the '<em><b>Flatten</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE__FLATTEN = CONV_LAYER__FLATTEN;

	/**
	 * The number of structural features of the '<em>Conv2 DTranspose</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE_FEATURE_COUNT = CONV_LAYER_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE___ACTIVATION_FUNCTION = CONV_LAYER___ACTIVATION_FUNCTION;

	/**
	 * The operation id for the '<em>Output feature map</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE___OUTPUT_FEATURE_MAP__INT_INT_INT = CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT;

	/**
	 * The number of operations of the '<em>Conv2 DTranspose</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONV2_DTRANSPOSE_OPERATION_COUNT = CONV_LAYER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.DenseImpl <em>Dense</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.DenseImpl
	 * @see modl.impl.ModlPackageImpl#getDense()
	 * @generated
	 */
	int DENSE = 17;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__NAME = LINEAR_LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__ACTIVATION = LINEAR_LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__BATCH_NORMALIZATION = LINEAR_LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__LAYER = LINEAR_LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__LAYERE_OPPOSITE = LINEAR_LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__REGULARIZER = LINEAR_LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__REG_RATE = LINEAR_LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__DO_DROPOUT = LINEAR_LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__DROPOUT_RATE = LINEAR_LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__LAYEROPERATIONS = LINEAR_LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Output features</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE__OUTPUT_FEATURES = LINEAR_LAYER_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Dense</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_FEATURE_COUNT = LINEAR_LAYER_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE___ACTIVATION_FUNCTION = LINEAR_LAYER___ACTIVATION_FUNCTION;

	/**
	 * The number of operations of the '<em>Dense</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_OPERATION_COUNT = LINEAR_LAYER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.OutputImpl <em>Output</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.OutputImpl
	 * @see modl.impl.ModlPackageImpl#getOutput()
	 * @generated
	 */
	int OUTPUT = 18;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__NAME = LINEAR_LAYER__NAME;

	/**
	 * The feature id for the '<em><b>Activation</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__ACTIVATION = LINEAR_LAYER__ACTIVATION;

	/**
	 * The feature id for the '<em><b>Batch normalization</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__BATCH_NORMALIZATION = LINEAR_LAYER__BATCH_NORMALIZATION;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__LAYER = LINEAR_LAYER__LAYER;

	/**
	 * The feature id for the '<em><b>Layere Opposite</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__LAYERE_OPPOSITE = LINEAR_LAYER__LAYERE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Regularizer</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__REGULARIZER = LINEAR_LAYER__REGULARIZER;

	/**
	 * The feature id for the '<em><b>Reg rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__REG_RATE = LINEAR_LAYER__REG_RATE;

	/**
	 * The feature id for the '<em><b>Do dropout</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__DO_DROPOUT = LINEAR_LAYER__DO_DROPOUT;

	/**
	 * The feature id for the '<em><b>Dropout rate</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__DROPOUT_RATE = LINEAR_LAYER__DROPOUT_RATE;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__LAYEROPERATIONS = LINEAR_LAYER__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Output classes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__OUTPUT_CLASSES = LINEAR_LAYER_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Array of classes</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT__ARRAY_OF_CLASSES = LINEAR_LAYER_FEATURE_COUNT + 1;

	/**
	 * The number of structural features of the '<em>Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_FEATURE_COUNT = LINEAR_LAYER_FEATURE_COUNT + 2;

	/**
	 * The operation id for the '<em>Activation function</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT___ACTIVATION_FUNCTION = LINEAR_LAYER___ACTIVATION_FUNCTION;

	/**
	 * The number of operations of the '<em>Output</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int OUTPUT_OPERATION_COUNT = LINEAR_LAYER_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.AutomotiveSystemImpl <em>Automotive System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.AutomotiveSystemImpl
	 * @see modl.impl.ModlPackageImpl#getAutomotiveSystem()
	 * @generated
	 */
	int AUTOMOTIVE_SYSTEM = 20;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOMOTIVE_SYSTEM__DLF = 0;

	/**
	 * The feature id for the '<em><b>Eastadl</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOMOTIVE_SYSTEM__EASTADL = 1;

	/**
	 * The number of structural features of the '<em>Automotive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOMOTIVE_SYSTEM_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>Automotive System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOMOTIVE_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.EastADLImpl <em>East ADL</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.EastADLImpl
	 * @see modl.impl.ModlPackageImpl#getEastADL()
	 * @generated
	 */
	int EAST_ADL = 21;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EAST_ADL__DLF = 0;

	/**
	 * The feature id for the '<em><b>Autosar</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EAST_ADL__AUTOSAR = 1;

	/**
	 * The number of structural features of the '<em>East ADL</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EAST_ADL_FEATURE_COUNT = 2;

	/**
	 * The number of operations of the '<em>East ADL</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EAST_ADL_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.AUTOSARImpl <em>AUTOSAR</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.AUTOSARImpl
	 * @see modl.impl.ModlPackageImpl#getAUTOSAR()
	 * @generated
	 */
	int AUTOSAR = 22;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOSAR__DLF = 0;

	/**
	 * The number of structural features of the '<em>AUTOSAR</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOSAR_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>AUTOSAR</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int AUTOSAR_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.MedicalImagingSystemImpl <em>Medical Imaging System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.MedicalImagingSystemImpl
	 * @see modl.impl.ModlPackageImpl#getMedicalImagingSystem()
	 * @generated
	 */
	int MEDICAL_IMAGING_SYSTEM = 23;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDICAL_IMAGING_SYSTEM__DLF = 0;

	/**
	 * The number of structural features of the '<em>Medical Imaging System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDICAL_IMAGING_SYSTEM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Medical Imaging System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MEDICAL_IMAGING_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.SatelliteImagingSystemImpl <em>Satellite Imaging System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.SatelliteImagingSystemImpl
	 * @see modl.impl.ModlPackageImpl#getSatelliteImagingSystem()
	 * @generated
	 */
	int SATELLITE_IMAGING_SYSTEM = 24;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SATELLITE_IMAGING_SYSTEM__DLF = 0;

	/**
	 * The number of structural features of the '<em>Satellite Imaging System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SATELLITE_IMAGING_SYSTEM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Satellite Imaging System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int SATELLITE_IMAGING_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.DefenceAndSurvellianceSystemImpl <em>Defence And Survelliance System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.DefenceAndSurvellianceSystemImpl
	 * @see modl.impl.ModlPackageImpl#getDefenceAndSurvellianceSystem()
	 * @generated
	 */
	int DEFENCE_AND_SURVELLIANCE_SYSTEM = 25;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFENCE_AND_SURVELLIANCE_SYSTEM__DLF = 0;

	/**
	 * The number of structural features of the '<em>Defence And Survelliance System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFENCE_AND_SURVELLIANCE_SYSTEM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Defence And Survelliance System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEFENCE_AND_SURVELLIANCE_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.MIEROFImpl <em>MIEROF</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.MIEROFImpl
	 * @see modl.impl.ModlPackageImpl#getMIEROF()
	 * @generated
	 */
	int MIEROF = 26;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIEROF__DLF = 0;

	/**
	 * The number of structural features of the '<em>MIEROF</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIEROF_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>MIEROF</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MIEROF_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.IndustrialAutomationSystemImpl <em>Industrial Automation System</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.IndustrialAutomationSystemImpl
	 * @see modl.impl.ModlPackageImpl#getIndustrialAutomationSystem()
	 * @generated
	 */
	int INDUSTRIAL_AUTOMATION_SYSTEM = 27;

	/**
	 * The feature id for the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDUSTRIAL_AUTOMATION_SYSTEM__DLF = 0;

	/**
	 * The number of structural features of the '<em>Industrial Automation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDUSTRIAL_AUTOMATION_SYSTEM_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Industrial Automation System</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INDUSTRIAL_AUTOMATION_SYSTEM_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.LayerOperationsImpl <em>Layer Operations</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.LayerOperationsImpl
	 * @see modl.impl.ModlPackageImpl#getLayerOperations()
	 * @generated
	 */
	int LAYER_OPERATIONS = 28;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER_OPERATIONS__LAYER = 0;

	/**
	 * The number of structural features of the '<em>Layer Operations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER_OPERATIONS_FEATURE_COUNT = 1;

	/**
	 * The number of operations of the '<em>Layer Operations</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int LAYER_OPERATIONS_OPERATION_COUNT = 0;

	/**
	 * The meta object id for the '{@link modl.impl.MultiplicationImpl <em>Multiplication</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.MultiplicationImpl
	 * @see modl.impl.ModlPackageImpl#getMultiplication()
	 * @generated
	 */
	int MULTIPLICATION = 29;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLICATION__LAYER = LAYER_OPERATIONS__LAYER;

	/**
	 * The number of structural features of the '<em>Multiplication</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLICATION_FEATURE_COUNT = LAYER_OPERATIONS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Multiplication</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MULTIPLICATION_OPERATION_COUNT = LAYER_OPERATIONS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.AdditionImpl <em>Addition</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.AdditionImpl
	 * @see modl.impl.ModlPackageImpl#getAddition()
	 * @generated
	 */
	int ADDITION = 30;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDITION__LAYER = LAYER_OPERATIONS__LAYER;

	/**
	 * The number of structural features of the '<em>Addition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDITION_FEATURE_COUNT = LAYER_OPERATIONS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Addition</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ADDITION_OPERATION_COUNT = LAYER_OPERATIONS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.ConcatenationImpl <em>Concatenation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.ConcatenationImpl
	 * @see modl.impl.ModlPackageImpl#getConcatenation()
	 * @generated
	 */
	int CONCATENATION = 31;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCATENATION__LAYER = LAYER_OPERATIONS__LAYER;

	/**
	 * The number of structural features of the '<em>Concatenation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCATENATION_FEATURE_COUNT = LAYER_OPERATIONS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Concatenation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CONCATENATION_OPERATION_COUNT = LAYER_OPERATIONS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.DepthConcatenationImpl <em>Depth Concatenation</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.DepthConcatenationImpl
	 * @see modl.impl.ModlPackageImpl#getDepthConcatenation()
	 * @generated
	 */
	int DEPTH_CONCATENATION = 32;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTH_CONCATENATION__LAYER = LAYER_OPERATIONS__LAYER;

	/**
	 * The number of structural features of the '<em>Depth Concatenation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTH_CONCATENATION_FEATURE_COUNT = LAYER_OPERATIONS_FEATURE_COUNT + 0;

	/**
	 * The number of operations of the '<em>Depth Concatenation</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DEPTH_CONCATENATION_OPERATION_COUNT = LAYER_OPERATIONS_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.BasicModelImpl <em>Basic Model</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.BasicModelImpl
	 * @see modl.impl.ModlPackageImpl#getBasicModel()
	 * @generated
	 */
	int BASIC_MODEL = 37;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__DATASET = CNN_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__NAME = CNN_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__LAYER = CNN_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__CNNMODEL = CNN_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__CNNMODELE_OPPOSITE = CNN_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__PARAMETERS = CNN_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__LAYEROPERATIONS = CNN_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__TRAINABLE = CNN_MODEL_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__INCLUDE_TOP = CNN_MODEL_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL__WEIGHTS_TRAINED_ON = CNN_MODEL_FEATURE_COUNT + 2;

	/**
	 * The number of structural features of the '<em>Basic Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL_FEATURE_COUNT = CNN_MODEL_FEATURE_COUNT + 3;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL___COMPILE_MODEL = CNN_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL___LAYERS = CNN_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL___PARAMS = CNN_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Basic Model</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_MODEL_OPERATION_COUNT = CNN_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.VGG16Impl <em>VGG16</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.VGG16Impl
	 * @see modl.impl.ModlPackageImpl#getVGG16()
	 * @generated
	 */
	int VGG16 = 33;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The number of structural features of the '<em>VGG16</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>VGG16</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int VGG16_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.AlexNetImpl <em>Alex Net</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.AlexNetImpl
	 * @see modl.impl.ModlPackageImpl#getAlexNet()
	 * @generated
	 */
	int ALEX_NET = 34;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The number of structural features of the '<em>Alex Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Alex Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int ALEX_NET_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.InceptionImpl <em>Inception</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.InceptionImpl
	 * @see modl.impl.ModlPackageImpl#getInception()
	 * @generated
	 */
	int INCEPTION = 35;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION__VERSION = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Inception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Inception</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int INCEPTION_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.ResNet50Impl <em>Res Net50</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.ResNet50Impl
	 * @see modl.impl.ModlPackageImpl#getResNet50()
	 * @generated
	 */
	int RES_NET50 = 36;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The number of structural features of the '<em>Res Net50</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Res Net50</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int RES_NET50_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.EfficientNetImpl <em>Efficient Net</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.EfficientNetImpl
	 * @see modl.impl.ModlPackageImpl#getEfficientNet()
	 * @generated
	 */
	int EFFICIENT_NET = 38;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The number of structural features of the '<em>Efficient Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Efficient Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int EFFICIENT_NET_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.MobileNetImpl <em>Mobile Net</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.MobileNetImpl
	 * @see modl.impl.ModlPackageImpl#getMobileNet()
	 * @generated
	 */
	int MOBILE_NET = 39;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The feature id for the '<em><b>Version</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET__VERSION = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The number of structural features of the '<em>Mobile Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 1;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Mobile Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int MOBILE_NET_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.RegNetImpl <em>Reg Net</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.RegNetImpl
	 * @see modl.impl.ModlPackageImpl#getRegNet()
	 * @generated
	 */
	int REG_NET = 40;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The number of structural features of the '<em>Reg Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Reg Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int REG_NET_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.impl.DenseNetImpl <em>Dense Net</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.impl.DenseNetImpl
	 * @see modl.impl.ModlPackageImpl#getDenseNet()
	 * @generated
	 */
	int DENSE_NET = 41;

	/**
	 * The feature id for the '<em><b>Dataset</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__DATASET = BASIC_MODEL__DATASET;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__NAME = BASIC_MODEL__NAME;

	/**
	 * The feature id for the '<em><b>Layer</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__LAYER = BASIC_MODEL__LAYER;

	/**
	 * The feature id for the '<em><b>Cnnmodel</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__CNNMODEL = BASIC_MODEL__CNNMODEL;

	/**
	 * The feature id for the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__CNNMODELE_OPPOSITE = BASIC_MODEL__CNNMODELE_OPPOSITE;

	/**
	 * The feature id for the '<em><b>Parameters</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__PARAMETERS = BASIC_MODEL__PARAMETERS;

	/**
	 * The feature id for the '<em><b>Layeroperations</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__LAYEROPERATIONS = BASIC_MODEL__LAYEROPERATIONS;

	/**
	 * The feature id for the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__TRAINABLE = BASIC_MODEL__TRAINABLE;

	/**
	 * The feature id for the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__INCLUDE_TOP = BASIC_MODEL__INCLUDE_TOP;

	/**
	 * The feature id for the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET__WEIGHTS_TRAINED_ON = BASIC_MODEL__WEIGHTS_TRAINED_ON;

	/**
	 * The number of structural features of the '<em>Dense Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET_FEATURE_COUNT = BASIC_MODEL_FEATURE_COUNT + 0;

	/**
	 * The operation id for the '<em>Compile model</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET___COMPILE_MODEL = BASIC_MODEL___COMPILE_MODEL;

	/**
	 * The operation id for the '<em>Layers</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET___LAYERS = BASIC_MODEL___LAYERS;

	/**
	 * The operation id for the '<em>Params</em>' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET___PARAMS = BASIC_MODEL___PARAMS;

	/**
	 * The number of operations of the '<em>Dense Net</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int DENSE_NET_OPERATION_COUNT = BASIC_MODEL_OPERATION_COUNT + 0;

	/**
	 * The meta object id for the '{@link modl.PoolingType <em>Pooling Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.PoolingType
	 * @see modl.impl.ModlPackageImpl#getPoolingType()
	 * @generated
	 */
	int POOLING_TYPE = 42;

	/**
	 * The meta object id for the '{@link modl.ActivationType <em>Activation Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.ActivationType
	 * @see modl.impl.ModlPackageImpl#getActivationType()
	 * @generated
	 */
	int ACTIVATION_TYPE = 43;

	/**
	 * The meta object id for the '{@link modl.ObjectiveType <em>Objective Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.ObjectiveType
	 * @see modl.impl.ModlPackageImpl#getObjectiveType()
	 * @generated
	 */
	int OBJECTIVE_TYPE = 44;

	/**
	 * The meta object id for the '{@link modl.MetricType <em>Metric Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.MetricType
	 * @see modl.impl.ModlPackageImpl#getMetricType()
	 * @generated
	 */
	int METRIC_TYPE = 45;

	/**
	 * The meta object id for the '{@link modl.OptimizerType <em>Optimizer Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.OptimizerType
	 * @see modl.impl.ModlPackageImpl#getOptimizerType()
	 * @generated
	 */
	int OPTIMIZER_TYPE = 46;

	/**
	 * The meta object id for the '{@link modl.RegulizerType <em>Regulizer Type</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see modl.RegulizerType
	 * @see modl.impl.ModlPackageImpl#getRegulizerType()
	 * @generated
	 */
	int REGULIZER_TYPE = 47;

	/**
	 * The meta object id for the '<em>Image Array</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.Object
	 * @see modl.impl.ModlPackageImpl#getImageArray()
	 * @generated
	 */
	int IMAGE_ARRAY = 48;

	/**
	 * The meta object id for the '<em>Label Array</em>' data type.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see java.lang.Object
	 * @see modl.impl.ModlPackageImpl#getLabelArray()
	 * @generated
	 */
	int LABEL_ARRAY = 49;

	/**
	 * Returns the meta object for class '{@link modl.DLF <em>DLF</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>DLF</em>'.
	 * @see modl.DLF
	 * @generated
	 */
	EClass getDLF();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.DLF#getDataset <em>Dataset</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Dataset</em>'.
	 * @see modl.DLF#getDataset()
	 * @see #getDLF()
	 * @generated
	 */
	EReference getDLF_Dataset();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.DLF#getCnnmodel <em>Cnnmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Cnnmodel</em>'.
	 * @see modl.DLF#getCnnmodel()
	 * @see #getDLF()
	 * @generated
	 */
	EReference getDLF_Cnnmodel();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.DLF#getBasicmodel <em>Basicmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Basicmodel</em>'.
	 * @see modl.DLF#getBasicmodel()
	 * @see #getDLF()
	 * @generated
	 */
	EReference getDLF_Basicmodel();

	/**
	 * Returns the meta object for class '{@link modl.Dataset <em>Dataset</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dataset</em>'.
	 * @see modl.Dataset
	 * @generated
	 */
	EClass getDataset();

	/**
	 * Returns the meta object for the attribute '{@link modl.Dataset#getQual_path <em>Qual path</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Qual path</em>'.
	 * @see modl.Dataset#getQual_path()
	 * @see #getDataset()
	 * @generated
	 */
	EAttribute getDataset_Qual_path();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.Dataset#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Image</em>'.
	 * @see modl.Dataset#getImage()
	 * @see #getDataset()
	 * @generated
	 */
	EReference getDataset_Image();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.Dataset#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Label</em>'.
	 * @see modl.Dataset#getLabel()
	 * @see #getDataset()
	 * @generated
	 */
	EReference getDataset_Label();

	/**
	 * Returns the meta object for the reference list '{@link modl.Dataset#getCnnmodel <em>Cnnmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Cnnmodel</em>'.
	 * @see modl.Dataset#getCnnmodel()
	 * @see #getDataset()
	 * @generated
	 */
	EReference getDataset_Cnnmodel();

	/**
	 * Returns the meta object for class '{@link modl.TrainingDS <em>Training DS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Training DS</em>'.
	 * @see modl.TrainingDS
	 * @generated
	 */
	EClass getTrainingDS();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingDS#getX_train <em>Xtrain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Xtrain</em>'.
	 * @see modl.TrainingDS#getX_train()
	 * @see #getTrainingDS()
	 * @generated
	 */
	EAttribute getTrainingDS_X_train();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingDS#getY_train <em>Ytrain</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ytrain</em>'.
	 * @see modl.TrainingDS#getY_train()
	 * @see #getTrainingDS()
	 * @generated
	 */
	EAttribute getTrainingDS_Y_train();

	/**
	 * Returns the meta object for class '{@link modl.TestingDS <em>Testing DS</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Testing DS</em>'.
	 * @see modl.TestingDS
	 * @generated
	 */
	EClass getTestingDS();

	/**
	 * Returns the meta object for the attribute '{@link modl.TestingDS#getX_test <em>Xtest</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Xtest</em>'.
	 * @see modl.TestingDS#getX_test()
	 * @see #getTestingDS()
	 * @generated
	 */
	EAttribute getTestingDS_X_test();

	/**
	 * Returns the meta object for the attribute '{@link modl.TestingDS#getY_test <em>Ytest</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Ytest</em>'.
	 * @see modl.TestingDS#getY_test()
	 * @see #getTestingDS()
	 * @generated
	 */
	EAttribute getTestingDS_Y_test();

	/**
	 * Returns the meta object for class '{@link modl.Image <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Image</em>'.
	 * @see modl.Image
	 * @generated
	 */
	EClass getImage();

	/**
	 * Returns the meta object for the reference '{@link modl.Image#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Label</em>'.
	 * @see modl.Image#getLabel()
	 * @see #getImage()
	 * @generated
	 */
	EReference getImage_Label();

	/**
	 * Returns the meta object for the attribute '{@link modl.Image#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see modl.Image#getName()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_Name();

	/**
	 * Returns the meta object for the attribute '{@link modl.Image#getFile_type <em>File type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>File type</em>'.
	 * @see modl.Image#getFile_type()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_File_type();

	/**
	 * Returns the meta object for the attribute '{@link modl.Image#getImage_width <em>Image width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Image width</em>'.
	 * @see modl.Image#getImage_width()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_Image_width();

	/**
	 * Returns the meta object for the attribute '{@link modl.Image#getImage_height <em>Image height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Image height</em>'.
	 * @see modl.Image#getImage_height()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_Image_height();

	/**
	 * Returns the meta object for the attribute '{@link modl.Image#getImage_channels <em>Image channels</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Image channels</em>'.
	 * @see modl.Image#getImage_channels()
	 * @see #getImage()
	 * @generated
	 */
	EAttribute getImage_Image_channels();

	/**
	 * Returns the meta object for the reference '{@link modl.Image#getInputlayer <em>Inputlayer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Inputlayer</em>'.
	 * @see modl.Image#getInputlayer()
	 * @see #getImage()
	 * @generated
	 */
	EReference getImage_Inputlayer();

	/**
	 * Returns the meta object for class '{@link modl.Label <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Label</em>'.
	 * @see modl.Label
	 * @generated
	 */
	EClass getLabel();

	/**
	 * Returns the meta object for the reference list '{@link modl.Label#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Image</em>'.
	 * @see modl.Label#getImage()
	 * @see #getLabel()
	 * @generated
	 */
	EReference getLabel_Image();

	/**
	 * Returns the meta object for class '{@link modl.CNNModel <em>CNN Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>CNN Model</em>'.
	 * @see modl.CNNModel
	 * @generated
	 */
	EClass getCNNModel();

	/**
	 * Returns the meta object for the reference list '{@link modl.CNNModel#getDataset <em>Dataset</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Dataset</em>'.
	 * @see modl.CNNModel#getDataset()
	 * @see #getCNNModel()
	 * @generated
	 */
	EReference getCNNModel_Dataset();

	/**
	 * Returns the meta object for the attribute '{@link modl.CNNModel#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see modl.CNNModel#getName()
	 * @see #getCNNModel()
	 * @generated
	 */
	EAttribute getCNNModel_Name();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.CNNModel#getLayer <em>Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Layer</em>'.
	 * @see modl.CNNModel#getLayer()
	 * @see #getCNNModel()
	 * @generated
	 */
	EReference getCNNModel_Layer();

	/**
	 * Returns the meta object for the reference '{@link modl.CNNModel#getCnnmodel <em>Cnnmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cnnmodel</em>'.
	 * @see modl.CNNModel#getCnnmodel()
	 * @see #getCNNModel()
	 * @generated
	 */
	EReference getCNNModel_Cnnmodel();

	/**
	 * Returns the meta object for the reference '{@link modl.CNNModel#getCnnmodeleOpposite <em>Cnnmodele Opposite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference '<em>Cnnmodele Opposite</em>'.
	 * @see modl.CNNModel#getCnnmodeleOpposite()
	 * @see #getCNNModel()
	 * @generated
	 */
	EReference getCNNModel_CnnmodeleOpposite();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.CNNModel#getParameters <em>Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Parameters</em>'.
	 * @see modl.CNNModel#getParameters()
	 * @see #getCNNModel()
	 * @generated
	 */
	EReference getCNNModel_Parameters();

	/**
	 * Returns the meta object for the containment reference list '{@link modl.CNNModel#getLayeroperations <em>Layeroperations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference list '<em>Layeroperations</em>'.
	 * @see modl.CNNModel#getLayeroperations()
	 * @see #getCNNModel()
	 * @generated
	 */
	EReference getCNNModel_Layeroperations();

	/**
	 * Returns the meta object for the '{@link modl.CNNModel#compile_model() <em>Compile model</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Compile model</em>' operation.
	 * @see modl.CNNModel#compile_model()
	 * @generated
	 */
	EOperation getCNNModel__Compile_model();

	/**
	 * Returns the meta object for the '{@link modl.CNNModel#layers() <em>Layers</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Layers</em>' operation.
	 * @see modl.CNNModel#layers()
	 * @generated
	 */
	EOperation getCNNModel__Layers();

	/**
	 * Returns the meta object for the '{@link modl.CNNModel#params() <em>Params</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Params</em>' operation.
	 * @see modl.CNNModel#params()
	 * @generated
	 */
	EOperation getCNNModel__Params();

	/**
	 * Returns the meta object for class '{@link modl.TrainingParameters <em>Training Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Training Parameters</em>'.
	 * @see modl.TrainingParameters
	 * @generated
	 */
	EClass getTrainingParameters();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingParameters#getEpochs <em>Epochs</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Epochs</em>'.
	 * @see modl.TrainingParameters#getEpochs()
	 * @see #getTrainingParameters()
	 * @generated
	 */
	EAttribute getTrainingParameters_Epochs();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingParameters#getObjective_function <em>Objective function</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Objective function</em>'.
	 * @see modl.TrainingParameters#getObjective_function()
	 * @see #getTrainingParameters()
	 * @generated
	 */
	EAttribute getTrainingParameters_Objective_function();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingParameters#getOptimizer <em>Optimizer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Optimizer</em>'.
	 * @see modl.TrainingParameters#getOptimizer()
	 * @see #getTrainingParameters()
	 * @generated
	 */
	EAttribute getTrainingParameters_Optimizer();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingParameters#getMetric <em>Metric</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Metric</em>'.
	 * @see modl.TrainingParameters#getMetric()
	 * @see #getTrainingParameters()
	 * @generated
	 */
	EAttribute getTrainingParameters_Metric();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingParameters#getLearning_rate <em>Learning rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Learning rate</em>'.
	 * @see modl.TrainingParameters#getLearning_rate()
	 * @see #getTrainingParameters()
	 * @generated
	 */
	EAttribute getTrainingParameters_Learning_rate();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingParameters#getDecay_rate <em>Decay rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Decay rate</em>'.
	 * @see modl.TrainingParameters#getDecay_rate()
	 * @see #getTrainingParameters()
	 * @generated
	 */
	EAttribute getTrainingParameters_Decay_rate();

	/**
	 * Returns the meta object for the attribute '{@link modl.TrainingParameters#getMomentum <em>Momentum</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Momentum</em>'.
	 * @see modl.TrainingParameters#getMomentum()
	 * @see #getTrainingParameters()
	 * @generated
	 */
	EAttribute getTrainingParameters_Momentum();

	/**
	 * Returns the meta object for class '{@link modl.TestingParameters <em>Testing Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Testing Parameters</em>'.
	 * @see modl.TestingParameters
	 * @generated
	 */
	EClass getTestingParameters();

	/**
	 * Returns the meta object for the attribute '{@link modl.TestingParameters#getConfidence <em>Confidence</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Confidence</em>'.
	 * @see modl.TestingParameters#getConfidence()
	 * @see #getTestingParameters()
	 * @generated
	 */
	EAttribute getTestingParameters_Confidence();

	/**
	 * Returns the meta object for class '{@link modl.Layer <em>Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Layer</em>'.
	 * @see modl.Layer
	 * @generated
	 */
	EClass getLayer();

	/**
	 * Returns the meta object for the attribute '{@link modl.Layer#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see modl.Layer#getName()
	 * @see #getLayer()
	 * @generated
	 */
	EAttribute getLayer_Name();

	/**
	 * Returns the meta object for the attribute '{@link modl.Layer#getActivation <em>Activation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Activation</em>'.
	 * @see modl.Layer#getActivation()
	 * @see #getLayer()
	 * @generated
	 */
	EAttribute getLayer_Activation();

	/**
	 * Returns the meta object for the attribute '{@link modl.Layer#isBatch_normalization <em>Batch normalization</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Batch normalization</em>'.
	 * @see modl.Layer#isBatch_normalization()
	 * @see #getLayer()
	 * @generated
	 */
	EAttribute getLayer_Batch_normalization();

	/**
	 * Returns the meta object for the reference list '{@link modl.Layer#getLayer <em>Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Layer</em>'.
	 * @see modl.Layer#getLayer()
	 * @see #getLayer()
	 * @generated
	 */
	EReference getLayer_Layer();

	/**
	 * Returns the meta object for the reference list '{@link modl.Layer#getLayereOpposite <em>Layere Opposite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Layere Opposite</em>'.
	 * @see modl.Layer#getLayereOpposite()
	 * @see #getLayer()
	 * @generated
	 */
	EReference getLayer_LayereOpposite();

	/**
	 * Returns the meta object for the reference list '{@link modl.Layer#getLayeroperations <em>Layeroperations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Layeroperations</em>'.
	 * @see modl.Layer#getLayeroperations()
	 * @see #getLayer()
	 * @generated
	 */
	EReference getLayer_Layeroperations();

	/**
	 * Returns the meta object for the attribute '{@link modl.Layer#getRegularizer <em>Regularizer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Regularizer</em>'.
	 * @see modl.Layer#getRegularizer()
	 * @see #getLayer()
	 * @generated
	 */
	EAttribute getLayer_Regularizer();

	/**
	 * Returns the meta object for the attribute '{@link modl.Layer#getReg_rate <em>Reg rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Reg rate</em>'.
	 * @see modl.Layer#getReg_rate()
	 * @see #getLayer()
	 * @generated
	 */
	EAttribute getLayer_Reg_rate();

	/**
	 * Returns the meta object for the attribute '{@link modl.Layer#isDo_dropout <em>Do dropout</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Do dropout</em>'.
	 * @see modl.Layer#isDo_dropout()
	 * @see #getLayer()
	 * @generated
	 */
	EAttribute getLayer_Do_dropout();

	/**
	 * Returns the meta object for the attribute '{@link modl.Layer#getDropout_rate <em>Dropout rate</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Dropout rate</em>'.
	 * @see modl.Layer#getDropout_rate()
	 * @see #getLayer()
	 * @generated
	 */
	EAttribute getLayer_Dropout_rate();

	/**
	 * Returns the meta object for the '{@link modl.Layer#activation_function() <em>Activation function</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Activation function</em>' operation.
	 * @see modl.Layer#activation_function()
	 * @generated
	 */
	EOperation getLayer__Activation_function();

	/**
	 * Returns the meta object for class '{@link modl.InputLayer <em>Input Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Input Layer</em>'.
	 * @see modl.InputLayer
	 * @generated
	 */
	EClass getInputLayer();

	/**
	 * Returns the meta object for the attribute '{@link modl.InputLayer#getInput_width <em>Input width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input width</em>'.
	 * @see modl.InputLayer#getInput_width()
	 * @see #getInputLayer()
	 * @generated
	 */
	EAttribute getInputLayer_Input_width();

	/**
	 * Returns the meta object for the attribute '{@link modl.InputLayer#getInput_height <em>Input height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input height</em>'.
	 * @see modl.InputLayer#getInput_height()
	 * @see #getInputLayer()
	 * @generated
	 */
	EAttribute getInputLayer_Input_height();

	/**
	 * Returns the meta object for the attribute '{@link modl.InputLayer#getInput_channels <em>Input channels</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Input channels</em>'.
	 * @see modl.InputLayer#getInput_channels()
	 * @see #getInputLayer()
	 * @generated
	 */
	EAttribute getInputLayer_Input_channels();

	/**
	 * Returns the meta object for the attribute '{@link modl.InputLayer#getArray_of_classes <em>Array of classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Array of classes</em>'.
	 * @see modl.InputLayer#getArray_of_classes()
	 * @see #getInputLayer()
	 * @generated
	 */
	EAttribute getInputLayer_Array_of_classes();

	/**
	 * Returns the meta object for the reference list '{@link modl.InputLayer#getImage <em>Image</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Image</em>'.
	 * @see modl.InputLayer#getImage()
	 * @see #getInputLayer()
	 * @generated
	 */
	EReference getInputLayer_Image();

	/**
	 * Returns the meta object for the '{@link modl.InputLayer#reshape(double) <em>Reshape</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Reshape</em>' operation.
	 * @see modl.InputLayer#reshape(double)
	 * @generated
	 */
	EOperation getInputLayer__Reshape__double();

	/**
	 * Returns the meta object for class '{@link modl.ConvLayer <em>Conv Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conv Layer</em>'.
	 * @see modl.ConvLayer
	 * @generated
	 */
	EClass getConvLayer();

	/**
	 * Returns the meta object for the attribute '{@link modl.ConvLayer#getKernel_width <em>Kernel width</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Kernel width</em>'.
	 * @see modl.ConvLayer#getKernel_width()
	 * @see #getConvLayer()
	 * @generated
	 */
	EAttribute getConvLayer_Kernel_width();

	/**
	 * Returns the meta object for the attribute '{@link modl.ConvLayer#getKernel_height <em>Kernel height</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Kernel height</em>'.
	 * @see modl.ConvLayer#getKernel_height()
	 * @see #getConvLayer()
	 * @generated
	 */
	EAttribute getConvLayer_Kernel_height();

	/**
	 * Returns the meta object for the attribute '{@link modl.ConvLayer#getStride <em>Stride</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Stride</em>'.
	 * @see modl.ConvLayer#getStride()
	 * @see #getConvLayer()
	 * @generated
	 */
	EAttribute getConvLayer_Stride();

	/**
	 * Returns the meta object for the attribute '{@link modl.ConvLayer#getPadding <em>Padding</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Padding</em>'.
	 * @see modl.ConvLayer#getPadding()
	 * @see #getConvLayer()
	 * @generated
	 */
	EAttribute getConvLayer_Padding();

	/**
	 * Returns the meta object for the attribute '{@link modl.ConvLayer#getOutput_channels <em>Output channels</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output channels</em>'.
	 * @see modl.ConvLayer#getOutput_channels()
	 * @see #getConvLayer()
	 * @generated
	 */
	EAttribute getConvLayer_Output_channels();

	/**
	 * Returns the meta object for the attribute '{@link modl.ConvLayer#isFlatten <em>Flatten</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Flatten</em>'.
	 * @see modl.ConvLayer#isFlatten()
	 * @see #getConvLayer()
	 * @generated
	 */
	EAttribute getConvLayer_Flatten();

	/**
	 * Returns the meta object for the '{@link modl.ConvLayer#output_feature_map(int, int, int) <em>Output feature map</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the '<em>Output feature map</em>' operation.
	 * @see modl.ConvLayer#output_feature_map(int, int, int)
	 * @generated
	 */
	EOperation getConvLayer__Output_feature_map__int_int_int();

	/**
	 * Returns the meta object for class '{@link modl.LinearLayer <em>Linear Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Linear Layer</em>'.
	 * @see modl.LinearLayer
	 * @generated
	 */
	EClass getLinearLayer();

	/**
	 * Returns the meta object for class '{@link modl.Conv2D <em>Conv2 D</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conv2 D</em>'.
	 * @see modl.Conv2D
	 * @generated
	 */
	EClass getConv2D();

	/**
	 * Returns the meta object for class '{@link modl.Pooling2D <em>Pooling2 D</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Pooling2 D</em>'.
	 * @see modl.Pooling2D
	 * @generated
	 */
	EClass getPooling2D();

	/**
	 * Returns the meta object for the attribute '{@link modl.Pooling2D#getType <em>Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Type</em>'.
	 * @see modl.Pooling2D#getType()
	 * @see #getPooling2D()
	 * @generated
	 */
	EAttribute getPooling2D_Type();

	/**
	 * Returns the meta object for class '{@link modl.Upsampling2D <em>Upsampling2 D</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Upsampling2 D</em>'.
	 * @see modl.Upsampling2D
	 * @generated
	 */
	EClass getUpsampling2D();

	/**
	 * Returns the meta object for class '{@link modl.Conv2DTranspose <em>Conv2 DTranspose</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Conv2 DTranspose</em>'.
	 * @see modl.Conv2DTranspose
	 * @generated
	 */
	EClass getConv2DTranspose();

	/**
	 * Returns the meta object for class '{@link modl.Dense <em>Dense</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dense</em>'.
	 * @see modl.Dense
	 * @generated
	 */
	EClass getDense();

	/**
	 * Returns the meta object for the attribute '{@link modl.Dense#getOutput_features <em>Output features</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output features</em>'.
	 * @see modl.Dense#getOutput_features()
	 * @see #getDense()
	 * @generated
	 */
	EAttribute getDense_Output_features();

	/**
	 * Returns the meta object for class '{@link modl.Output <em>Output</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Output</em>'.
	 * @see modl.Output
	 * @generated
	 */
	EClass getOutput();

	/**
	 * Returns the meta object for the attribute '{@link modl.Output#getOutput_classes <em>Output classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Output classes</em>'.
	 * @see modl.Output#getOutput_classes()
	 * @see #getOutput()
	 * @generated
	 */
	EAttribute getOutput_Output_classes();

	/**
	 * Returns the meta object for the attribute '{@link modl.Output#getArray_of_classes <em>Array of classes</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Array of classes</em>'.
	 * @see modl.Output#getArray_of_classes()
	 * @see #getOutput()
	 * @generated
	 */
	EAttribute getOutput_Array_of_classes();

	/**
	 * Returns the meta object for class '{@link modl.Parameters <em>Parameters</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Parameters</em>'.
	 * @see modl.Parameters
	 * @generated
	 */
	EClass getParameters();

	/**
	 * Returns the meta object for the attribute '{@link modl.Parameters#getBatch_size <em>Batch size</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Batch size</em>'.
	 * @see modl.Parameters#getBatch_size()
	 * @see #getParameters()
	 * @generated
	 */
	EAttribute getParameters_Batch_size();

	/**
	 * Returns the meta object for class '{@link modl.AutomotiveSystem <em>Automotive System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Automotive System</em>'.
	 * @see modl.AutomotiveSystem
	 * @generated
	 */
	EClass getAutomotiveSystem();

	/**
	 * Returns the meta object for the containment reference '{@link modl.AutomotiveSystem#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.AutomotiveSystem#getDlf()
	 * @see #getAutomotiveSystem()
	 * @generated
	 */
	EReference getAutomotiveSystem_Dlf();

	/**
	 * Returns the meta object for the containment reference '{@link modl.AutomotiveSystem#getEastadl <em>Eastadl</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Eastadl</em>'.
	 * @see modl.AutomotiveSystem#getEastadl()
	 * @see #getAutomotiveSystem()
	 * @generated
	 */
	EReference getAutomotiveSystem_Eastadl();

	/**
	 * Returns the meta object for class '{@link modl.EastADL <em>East ADL</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>East ADL</em>'.
	 * @see modl.EastADL
	 * @generated
	 */
	EClass getEastADL();

	/**
	 * Returns the meta object for the containment reference '{@link modl.EastADL#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.EastADL#getDlf()
	 * @see #getEastADL()
	 * @generated
	 */
	EReference getEastADL_Dlf();

	/**
	 * Returns the meta object for the containment reference '{@link modl.EastADL#getAutosar <em>Autosar</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Autosar</em>'.
	 * @see modl.EastADL#getAutosar()
	 * @see #getEastADL()
	 * @generated
	 */
	EReference getEastADL_Autosar();

	/**
	 * Returns the meta object for class '{@link modl.AUTOSAR <em>AUTOSAR</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>AUTOSAR</em>'.
	 * @see modl.AUTOSAR
	 * @generated
	 */
	EClass getAUTOSAR();

	/**
	 * Returns the meta object for the containment reference '{@link modl.AUTOSAR#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.AUTOSAR#getDlf()
	 * @see #getAUTOSAR()
	 * @generated
	 */
	EReference getAUTOSAR_Dlf();

	/**
	 * Returns the meta object for class '{@link modl.MedicalImagingSystem <em>Medical Imaging System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Medical Imaging System</em>'.
	 * @see modl.MedicalImagingSystem
	 * @generated
	 */
	EClass getMedicalImagingSystem();

	/**
	 * Returns the meta object for the containment reference '{@link modl.MedicalImagingSystem#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.MedicalImagingSystem#getDlf()
	 * @see #getMedicalImagingSystem()
	 * @generated
	 */
	EReference getMedicalImagingSystem_Dlf();

	/**
	 * Returns the meta object for class '{@link modl.SatelliteImagingSystem <em>Satellite Imaging System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Satellite Imaging System</em>'.
	 * @see modl.SatelliteImagingSystem
	 * @generated
	 */
	EClass getSatelliteImagingSystem();

	/**
	 * Returns the meta object for the containment reference '{@link modl.SatelliteImagingSystem#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.SatelliteImagingSystem#getDlf()
	 * @see #getSatelliteImagingSystem()
	 * @generated
	 */
	EReference getSatelliteImagingSystem_Dlf();

	/**
	 * Returns the meta object for class '{@link modl.DefenceAndSurvellianceSystem <em>Defence And Survelliance System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Defence And Survelliance System</em>'.
	 * @see modl.DefenceAndSurvellianceSystem
	 * @generated
	 */
	EClass getDefenceAndSurvellianceSystem();

	/**
	 * Returns the meta object for the containment reference '{@link modl.DefenceAndSurvellianceSystem#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.DefenceAndSurvellianceSystem#getDlf()
	 * @see #getDefenceAndSurvellianceSystem()
	 * @generated
	 */
	EReference getDefenceAndSurvellianceSystem_Dlf();

	/**
	 * Returns the meta object for class '{@link modl.MIEROF <em>MIEROF</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>MIEROF</em>'.
	 * @see modl.MIEROF
	 * @generated
	 */
	EClass getMIEROF();

	/**
	 * Returns the meta object for the containment reference '{@link modl.MIEROF#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.MIEROF#getDlf()
	 * @see #getMIEROF()
	 * @generated
	 */
	EReference getMIEROF_Dlf();

	/**
	 * Returns the meta object for class '{@link modl.IndustrialAutomationSystem <em>Industrial Automation System</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Industrial Automation System</em>'.
	 * @see modl.IndustrialAutomationSystem
	 * @generated
	 */
	EClass getIndustrialAutomationSystem();

	/**
	 * Returns the meta object for the containment reference '{@link modl.IndustrialAutomationSystem#getDlf <em>Dlf</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the containment reference '<em>Dlf</em>'.
	 * @see modl.IndustrialAutomationSystem#getDlf()
	 * @see #getIndustrialAutomationSystem()
	 * @generated
	 */
	EReference getIndustrialAutomationSystem_Dlf();

	/**
	 * Returns the meta object for class '{@link modl.LayerOperations <em>Layer Operations</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Layer Operations</em>'.
	 * @see modl.LayerOperations
	 * @generated
	 */
	EClass getLayerOperations();

	/**
	 * Returns the meta object for the reference list '{@link modl.LayerOperations#getLayer <em>Layer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Layer</em>'.
	 * @see modl.LayerOperations#getLayer()
	 * @see #getLayerOperations()
	 * @generated
	 */
	EReference getLayerOperations_Layer();

	/**
	 * Returns the meta object for class '{@link modl.Multiplication <em>Multiplication</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Multiplication</em>'.
	 * @see modl.Multiplication
	 * @generated
	 */
	EClass getMultiplication();

	/**
	 * Returns the meta object for class '{@link modl.Addition <em>Addition</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Addition</em>'.
	 * @see modl.Addition
	 * @generated
	 */
	EClass getAddition();

	/**
	 * Returns the meta object for class '{@link modl.Concatenation <em>Concatenation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Concatenation</em>'.
	 * @see modl.Concatenation
	 * @generated
	 */
	EClass getConcatenation();

	/**
	 * Returns the meta object for class '{@link modl.DepthConcatenation <em>Depth Concatenation</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Depth Concatenation</em>'.
	 * @see modl.DepthConcatenation
	 * @generated
	 */
	EClass getDepthConcatenation();

	/**
	 * Returns the meta object for class '{@link modl.VGG16 <em>VGG16</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>VGG16</em>'.
	 * @see modl.VGG16
	 * @generated
	 */
	EClass getVGG16();

	/**
	 * Returns the meta object for class '{@link modl.AlexNet <em>Alex Net</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Alex Net</em>'.
	 * @see modl.AlexNet
	 * @generated
	 */
	EClass getAlexNet();

	/**
	 * Returns the meta object for class '{@link modl.Inception <em>Inception</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Inception</em>'.
	 * @see modl.Inception
	 * @generated
	 */
	EClass getInception();

	/**
	 * Returns the meta object for the attribute '{@link modl.Inception#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version</em>'.
	 * @see modl.Inception#getVersion()
	 * @see #getInception()
	 * @generated
	 */
	EAttribute getInception_Version();

	/**
	 * Returns the meta object for class '{@link modl.ResNet50 <em>Res Net50</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Res Net50</em>'.
	 * @see modl.ResNet50
	 * @generated
	 */
	EClass getResNet50();

	/**
	 * Returns the meta object for class '{@link modl.BasicModel <em>Basic Model</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Basic Model</em>'.
	 * @see modl.BasicModel
	 * @generated
	 */
	EClass getBasicModel();

	/**
	 * Returns the meta object for the attribute '{@link modl.BasicModel#isTrainable <em>Trainable</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Trainable</em>'.
	 * @see modl.BasicModel#isTrainable()
	 * @see #getBasicModel()
	 * @generated
	 */
	EAttribute getBasicModel_Trainable();

	/**
	 * Returns the meta object for the attribute '{@link modl.BasicModel#isInclude_top <em>Include top</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Include top</em>'.
	 * @see modl.BasicModel#isInclude_top()
	 * @see #getBasicModel()
	 * @generated
	 */
	EAttribute getBasicModel_Include_top();

	/**
	 * Returns the meta object for the attribute '{@link modl.BasicModel#getWeights_trained_on <em>Weights trained on</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Weights trained on</em>'.
	 * @see modl.BasicModel#getWeights_trained_on()
	 * @see #getBasicModel()
	 * @generated
	 */
	EAttribute getBasicModel_Weights_trained_on();

	/**
	 * Returns the meta object for class '{@link modl.EfficientNet <em>Efficient Net</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Efficient Net</em>'.
	 * @see modl.EfficientNet
	 * @generated
	 */
	EClass getEfficientNet();

	/**
	 * Returns the meta object for class '{@link modl.MobileNet <em>Mobile Net</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Mobile Net</em>'.
	 * @see modl.MobileNet
	 * @generated
	 */
	EClass getMobileNet();

	/**
	 * Returns the meta object for the attribute '{@link modl.MobileNet#getVersion <em>Version</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Version</em>'.
	 * @see modl.MobileNet#getVersion()
	 * @see #getMobileNet()
	 * @generated
	 */
	EAttribute getMobileNet_Version();

	/**
	 * Returns the meta object for class '{@link modl.RegNet <em>Reg Net</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Reg Net</em>'.
	 * @see modl.RegNet
	 * @generated
	 */
	EClass getRegNet();

	/**
	 * Returns the meta object for class '{@link modl.DenseNet <em>Dense Net</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Dense Net</em>'.
	 * @see modl.DenseNet
	 * @generated
	 */
	EClass getDenseNet();

	/**
	 * Returns the meta object for enum '{@link modl.PoolingType <em>Pooling Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Pooling Type</em>'.
	 * @see modl.PoolingType
	 * @generated
	 */
	EEnum getPoolingType();

	/**
	 * Returns the meta object for enum '{@link modl.ActivationType <em>Activation Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Activation Type</em>'.
	 * @see modl.ActivationType
	 * @generated
	 */
	EEnum getActivationType();

	/**
	 * Returns the meta object for enum '{@link modl.ObjectiveType <em>Objective Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Objective Type</em>'.
	 * @see modl.ObjectiveType
	 * @generated
	 */
	EEnum getObjectiveType();

	/**
	 * Returns the meta object for enum '{@link modl.MetricType <em>Metric Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Metric Type</em>'.
	 * @see modl.MetricType
	 * @generated
	 */
	EEnum getMetricType();

	/**
	 * Returns the meta object for enum '{@link modl.OptimizerType <em>Optimizer Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Optimizer Type</em>'.
	 * @see modl.OptimizerType
	 * @generated
	 */
	EEnum getOptimizerType();

	/**
	 * Returns the meta object for enum '{@link modl.RegulizerType <em>Regulizer Type</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Regulizer Type</em>'.
	 * @see modl.RegulizerType
	 * @generated
	 */
	EEnum getRegulizerType();

	/**
	 * Returns the meta object for data type '{@link java.lang.Object <em>Image Array</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Image Array</em>'.
	 * @see java.lang.Object
	 * @model instanceClass="java.lang.Object"
	 * @generated
	 */
	EDataType getImageArray();

	/**
	 * Returns the meta object for data type '{@link java.lang.Object <em>Label Array</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for data type '<em>Label Array</em>'.
	 * @see java.lang.Object
	 * @model instanceClass="java.lang.Object"
	 * @generated
	 */
	EDataType getLabelArray();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	ModlFactory getModlFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each operation of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link modl.impl.DLFImpl <em>DLF</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.DLFImpl
		 * @see modl.impl.ModlPackageImpl#getDLF()
		 * @generated
		 */
		EClass DLF = eINSTANCE.getDLF();

		/**
		 * The meta object literal for the '<em><b>Dataset</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DLF__DATASET = eINSTANCE.getDLF_Dataset();

		/**
		 * The meta object literal for the '<em><b>Cnnmodel</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DLF__CNNMODEL = eINSTANCE.getDLF_Cnnmodel();

		/**
		 * The meta object literal for the '<em><b>Basicmodel</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DLF__BASICMODEL = eINSTANCE.getDLF_Basicmodel();

		/**
		 * The meta object literal for the '{@link modl.impl.DatasetImpl <em>Dataset</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.DatasetImpl
		 * @see modl.impl.ModlPackageImpl#getDataset()
		 * @generated
		 */
		EClass DATASET = eINSTANCE.getDataset();

		/**
		 * The meta object literal for the '<em><b>Qual path</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DATASET__QUAL_PATH = eINSTANCE.getDataset_Qual_path();

		/**
		 * The meta object literal for the '<em><b>Image</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATASET__IMAGE = eINSTANCE.getDataset_Image();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATASET__LABEL = eINSTANCE.getDataset_Label();

		/**
		 * The meta object literal for the '<em><b>Cnnmodel</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DATASET__CNNMODEL = eINSTANCE.getDataset_Cnnmodel();

		/**
		 * The meta object literal for the '{@link modl.impl.TrainingDSImpl <em>Training DS</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.TrainingDSImpl
		 * @see modl.impl.ModlPackageImpl#getTrainingDS()
		 * @generated
		 */
		EClass TRAINING_DS = eINSTANCE.getTrainingDS();

		/**
		 * The meta object literal for the '<em><b>Xtrain</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_DS__XTRAIN = eINSTANCE.getTrainingDS_X_train();

		/**
		 * The meta object literal for the '<em><b>Ytrain</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_DS__YTRAIN = eINSTANCE.getTrainingDS_Y_train();

		/**
		 * The meta object literal for the '{@link modl.impl.TestingDSImpl <em>Testing DS</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.TestingDSImpl
		 * @see modl.impl.ModlPackageImpl#getTestingDS()
		 * @generated
		 */
		EClass TESTING_DS = eINSTANCE.getTestingDS();

		/**
		 * The meta object literal for the '<em><b>Xtest</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TESTING_DS__XTEST = eINSTANCE.getTestingDS_X_test();

		/**
		 * The meta object literal for the '<em><b>Ytest</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TESTING_DS__YTEST = eINSTANCE.getTestingDS_Y_test();

		/**
		 * The meta object literal for the '{@link modl.impl.ImageImpl <em>Image</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.ImageImpl
		 * @see modl.impl.ModlPackageImpl#getImage()
		 * @generated
		 */
		EClass IMAGE = eINSTANCE.getImage();

		/**
		 * The meta object literal for the '<em><b>Label</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IMAGE__LABEL = eINSTANCE.getImage_Label();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__NAME = eINSTANCE.getImage_Name();

		/**
		 * The meta object literal for the '<em><b>File type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__FILE_TYPE = eINSTANCE.getImage_File_type();

		/**
		 * The meta object literal for the '<em><b>Image width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__IMAGE_WIDTH = eINSTANCE.getImage_Image_width();

		/**
		 * The meta object literal for the '<em><b>Image height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__IMAGE_HEIGHT = eINSTANCE.getImage_Image_height();

		/**
		 * The meta object literal for the '<em><b>Image channels</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute IMAGE__IMAGE_CHANNELS = eINSTANCE.getImage_Image_channels();

		/**
		 * The meta object literal for the '<em><b>Inputlayer</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference IMAGE__INPUTLAYER = eINSTANCE.getImage_Inputlayer();

		/**
		 * The meta object literal for the '{@link modl.impl.LabelImpl <em>Label</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.LabelImpl
		 * @see modl.impl.ModlPackageImpl#getLabel()
		 * @generated
		 */
		EClass LABEL = eINSTANCE.getLabel();

		/**
		 * The meta object literal for the '<em><b>Image</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LABEL__IMAGE = eINSTANCE.getLabel_Image();

		/**
		 * The meta object literal for the '{@link modl.impl.CNNModelImpl <em>CNN Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.CNNModelImpl
		 * @see modl.impl.ModlPackageImpl#getCNNModel()
		 * @generated
		 */
		EClass CNN_MODEL = eINSTANCE.getCNNModel();

		/**
		 * The meta object literal for the '<em><b>Dataset</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CNN_MODEL__DATASET = eINSTANCE.getCNNModel_Dataset();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CNN_MODEL__NAME = eINSTANCE.getCNNModel_Name();

		/**
		 * The meta object literal for the '<em><b>Layer</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CNN_MODEL__LAYER = eINSTANCE.getCNNModel_Layer();

		/**
		 * The meta object literal for the '<em><b>Cnnmodel</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CNN_MODEL__CNNMODEL = eINSTANCE.getCNNModel_Cnnmodel();

		/**
		 * The meta object literal for the '<em><b>Cnnmodele Opposite</b></em>' reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CNN_MODEL__CNNMODELE_OPPOSITE = eINSTANCE.getCNNModel_CnnmodeleOpposite();

		/**
		 * The meta object literal for the '<em><b>Parameters</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CNN_MODEL__PARAMETERS = eINSTANCE.getCNNModel_Parameters();

		/**
		 * The meta object literal for the '<em><b>Layeroperations</b></em>' containment reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference CNN_MODEL__LAYEROPERATIONS = eINSTANCE.getCNNModel_Layeroperations();

		/**
		 * The meta object literal for the '<em><b>Compile model</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CNN_MODEL___COMPILE_MODEL = eINSTANCE.getCNNModel__Compile_model();

		/**
		 * The meta object literal for the '<em><b>Layers</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CNN_MODEL___LAYERS = eINSTANCE.getCNNModel__Layers();

		/**
		 * The meta object literal for the '<em><b>Params</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CNN_MODEL___PARAMS = eINSTANCE.getCNNModel__Params();

		/**
		 * The meta object literal for the '{@link modl.impl.TrainingParametersImpl <em>Training Parameters</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.TrainingParametersImpl
		 * @see modl.impl.ModlPackageImpl#getTrainingParameters()
		 * @generated
		 */
		EClass TRAINING_PARAMETERS = eINSTANCE.getTrainingParameters();

		/**
		 * The meta object literal for the '<em><b>Epochs</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_PARAMETERS__EPOCHS = eINSTANCE.getTrainingParameters_Epochs();

		/**
		 * The meta object literal for the '<em><b>Objective function</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_PARAMETERS__OBJECTIVE_FUNCTION = eINSTANCE.getTrainingParameters_Objective_function();

		/**
		 * The meta object literal for the '<em><b>Optimizer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_PARAMETERS__OPTIMIZER = eINSTANCE.getTrainingParameters_Optimizer();

		/**
		 * The meta object literal for the '<em><b>Metric</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_PARAMETERS__METRIC = eINSTANCE.getTrainingParameters_Metric();

		/**
		 * The meta object literal for the '<em><b>Learning rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_PARAMETERS__LEARNING_RATE = eINSTANCE.getTrainingParameters_Learning_rate();

		/**
		 * The meta object literal for the '<em><b>Decay rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_PARAMETERS__DECAY_RATE = eINSTANCE.getTrainingParameters_Decay_rate();

		/**
		 * The meta object literal for the '<em><b>Momentum</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TRAINING_PARAMETERS__MOMENTUM = eINSTANCE.getTrainingParameters_Momentum();

		/**
		 * The meta object literal for the '{@link modl.impl.TestingParametersImpl <em>Testing Parameters</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.TestingParametersImpl
		 * @see modl.impl.ModlPackageImpl#getTestingParameters()
		 * @generated
		 */
		EClass TESTING_PARAMETERS = eINSTANCE.getTestingParameters();

		/**
		 * The meta object literal for the '<em><b>Confidence</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute TESTING_PARAMETERS__CONFIDENCE = eINSTANCE.getTestingParameters_Confidence();

		/**
		 * The meta object literal for the '{@link modl.impl.LayerImpl <em>Layer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.LayerImpl
		 * @see modl.impl.ModlPackageImpl#getLayer()
		 * @generated
		 */
		EClass LAYER = eINSTANCE.getLayer();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAYER__NAME = eINSTANCE.getLayer_Name();

		/**
		 * The meta object literal for the '<em><b>Activation</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAYER__ACTIVATION = eINSTANCE.getLayer_Activation();

		/**
		 * The meta object literal for the '<em><b>Batch normalization</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAYER__BATCH_NORMALIZATION = eINSTANCE.getLayer_Batch_normalization();

		/**
		 * The meta object literal for the '<em><b>Layer</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYER__LAYER = eINSTANCE.getLayer_Layer();

		/**
		 * The meta object literal for the '<em><b>Layere Opposite</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYER__LAYERE_OPPOSITE = eINSTANCE.getLayer_LayereOpposite();

		/**
		 * The meta object literal for the '<em><b>Layeroperations</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYER__LAYEROPERATIONS = eINSTANCE.getLayer_Layeroperations();

		/**
		 * The meta object literal for the '<em><b>Regularizer</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAYER__REGULARIZER = eINSTANCE.getLayer_Regularizer();

		/**
		 * The meta object literal for the '<em><b>Reg rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAYER__REG_RATE = eINSTANCE.getLayer_Reg_rate();

		/**
		 * The meta object literal for the '<em><b>Do dropout</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAYER__DO_DROPOUT = eINSTANCE.getLayer_Do_dropout();

		/**
		 * The meta object literal for the '<em><b>Dropout rate</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute LAYER__DROPOUT_RATE = eINSTANCE.getLayer_Dropout_rate();

		/**
		 * The meta object literal for the '<em><b>Activation function</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation LAYER___ACTIVATION_FUNCTION = eINSTANCE.getLayer__Activation_function();

		/**
		 * The meta object literal for the '{@link modl.impl.InputLayerImpl <em>Input Layer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.InputLayerImpl
		 * @see modl.impl.ModlPackageImpl#getInputLayer()
		 * @generated
		 */
		EClass INPUT_LAYER = eINSTANCE.getInputLayer();

		/**
		 * The meta object literal for the '<em><b>Input width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_LAYER__INPUT_WIDTH = eINSTANCE.getInputLayer_Input_width();

		/**
		 * The meta object literal for the '<em><b>Input height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_LAYER__INPUT_HEIGHT = eINSTANCE.getInputLayer_Input_height();

		/**
		 * The meta object literal for the '<em><b>Input channels</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_LAYER__INPUT_CHANNELS = eINSTANCE.getInputLayer_Input_channels();

		/**
		 * The meta object literal for the '<em><b>Array of classes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INPUT_LAYER__ARRAY_OF_CLASSES = eINSTANCE.getInputLayer_Array_of_classes();

		/**
		 * The meta object literal for the '<em><b>Image</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INPUT_LAYER__IMAGE = eINSTANCE.getInputLayer_Image();

		/**
		 * The meta object literal for the '<em><b>Reshape</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation INPUT_LAYER___RESHAPE__DOUBLE = eINSTANCE.getInputLayer__Reshape__double();

		/**
		 * The meta object literal for the '{@link modl.impl.ConvLayerImpl <em>Conv Layer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.ConvLayerImpl
		 * @see modl.impl.ModlPackageImpl#getConvLayer()
		 * @generated
		 */
		EClass CONV_LAYER = eINSTANCE.getConvLayer();

		/**
		 * The meta object literal for the '<em><b>Kernel width</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONV_LAYER__KERNEL_WIDTH = eINSTANCE.getConvLayer_Kernel_width();

		/**
		 * The meta object literal for the '<em><b>Kernel height</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONV_LAYER__KERNEL_HEIGHT = eINSTANCE.getConvLayer_Kernel_height();

		/**
		 * The meta object literal for the '<em><b>Stride</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONV_LAYER__STRIDE = eINSTANCE.getConvLayer_Stride();

		/**
		 * The meta object literal for the '<em><b>Padding</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONV_LAYER__PADDING = eINSTANCE.getConvLayer_Padding();

		/**
		 * The meta object literal for the '<em><b>Output channels</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONV_LAYER__OUTPUT_CHANNELS = eINSTANCE.getConvLayer_Output_channels();

		/**
		 * The meta object literal for the '<em><b>Flatten</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CONV_LAYER__FLATTEN = eINSTANCE.getConvLayer_Flatten();

		/**
		 * The meta object literal for the '<em><b>Output feature map</b></em>' operation.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EOperation CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT = eINSTANCE
				.getConvLayer__Output_feature_map__int_int_int();

		/**
		 * The meta object literal for the '{@link modl.impl.LinearLayerImpl <em>Linear Layer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.LinearLayerImpl
		 * @see modl.impl.ModlPackageImpl#getLinearLayer()
		 * @generated
		 */
		EClass LINEAR_LAYER = eINSTANCE.getLinearLayer();

		/**
		 * The meta object literal for the '{@link modl.impl.Conv2DImpl <em>Conv2 D</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.Conv2DImpl
		 * @see modl.impl.ModlPackageImpl#getConv2D()
		 * @generated
		 */
		EClass CONV2_D = eINSTANCE.getConv2D();

		/**
		 * The meta object literal for the '{@link modl.impl.Pooling2DImpl <em>Pooling2 D</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.Pooling2DImpl
		 * @see modl.impl.ModlPackageImpl#getPooling2D()
		 * @generated
		 */
		EClass POOLING2_D = eINSTANCE.getPooling2D();

		/**
		 * The meta object literal for the '<em><b>Type</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute POOLING2_D__TYPE = eINSTANCE.getPooling2D_Type();

		/**
		 * The meta object literal for the '{@link modl.impl.Upsampling2DImpl <em>Upsampling2 D</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.Upsampling2DImpl
		 * @see modl.impl.ModlPackageImpl#getUpsampling2D()
		 * @generated
		 */
		EClass UPSAMPLING2_D = eINSTANCE.getUpsampling2D();

		/**
		 * The meta object literal for the '{@link modl.impl.Conv2DTransposeImpl <em>Conv2 DTranspose</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.Conv2DTransposeImpl
		 * @see modl.impl.ModlPackageImpl#getConv2DTranspose()
		 * @generated
		 */
		EClass CONV2_DTRANSPOSE = eINSTANCE.getConv2DTranspose();

		/**
		 * The meta object literal for the '{@link modl.impl.DenseImpl <em>Dense</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.DenseImpl
		 * @see modl.impl.ModlPackageImpl#getDense()
		 * @generated
		 */
		EClass DENSE = eINSTANCE.getDense();

		/**
		 * The meta object literal for the '<em><b>Output features</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute DENSE__OUTPUT_FEATURES = eINSTANCE.getDense_Output_features();

		/**
		 * The meta object literal for the '{@link modl.impl.OutputImpl <em>Output</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.OutputImpl
		 * @see modl.impl.ModlPackageImpl#getOutput()
		 * @generated
		 */
		EClass OUTPUT = eINSTANCE.getOutput();

		/**
		 * The meta object literal for the '<em><b>Output classes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OUTPUT__OUTPUT_CLASSES = eINSTANCE.getOutput_Output_classes();

		/**
		 * The meta object literal for the '<em><b>Array of classes</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute OUTPUT__ARRAY_OF_CLASSES = eINSTANCE.getOutput_Array_of_classes();

		/**
		 * The meta object literal for the '{@link modl.impl.ParametersImpl <em>Parameters</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.ParametersImpl
		 * @see modl.impl.ModlPackageImpl#getParameters()
		 * @generated
		 */
		EClass PARAMETERS = eINSTANCE.getParameters();

		/**
		 * The meta object literal for the '<em><b>Batch size</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute PARAMETERS__BATCH_SIZE = eINSTANCE.getParameters_Batch_size();

		/**
		 * The meta object literal for the '{@link modl.impl.AutomotiveSystemImpl <em>Automotive System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.AutomotiveSystemImpl
		 * @see modl.impl.ModlPackageImpl#getAutomotiveSystem()
		 * @generated
		 */
		EClass AUTOMOTIVE_SYSTEM = eINSTANCE.getAutomotiveSystem();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AUTOMOTIVE_SYSTEM__DLF = eINSTANCE.getAutomotiveSystem_Dlf();

		/**
		 * The meta object literal for the '<em><b>Eastadl</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AUTOMOTIVE_SYSTEM__EASTADL = eINSTANCE.getAutomotiveSystem_Eastadl();

		/**
		 * The meta object literal for the '{@link modl.impl.EastADLImpl <em>East ADL</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.EastADLImpl
		 * @see modl.impl.ModlPackageImpl#getEastADL()
		 * @generated
		 */
		EClass EAST_ADL = eINSTANCE.getEastADL();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EAST_ADL__DLF = eINSTANCE.getEastADL_Dlf();

		/**
		 * The meta object literal for the '<em><b>Autosar</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference EAST_ADL__AUTOSAR = eINSTANCE.getEastADL_Autosar();

		/**
		 * The meta object literal for the '{@link modl.impl.AUTOSARImpl <em>AUTOSAR</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.AUTOSARImpl
		 * @see modl.impl.ModlPackageImpl#getAUTOSAR()
		 * @generated
		 */
		EClass AUTOSAR = eINSTANCE.getAUTOSAR();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference AUTOSAR__DLF = eINSTANCE.getAUTOSAR_Dlf();

		/**
		 * The meta object literal for the '{@link modl.impl.MedicalImagingSystemImpl <em>Medical Imaging System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.MedicalImagingSystemImpl
		 * @see modl.impl.ModlPackageImpl#getMedicalImagingSystem()
		 * @generated
		 */
		EClass MEDICAL_IMAGING_SYSTEM = eINSTANCE.getMedicalImagingSystem();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MEDICAL_IMAGING_SYSTEM__DLF = eINSTANCE.getMedicalImagingSystem_Dlf();

		/**
		 * The meta object literal for the '{@link modl.impl.SatelliteImagingSystemImpl <em>Satellite Imaging System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.SatelliteImagingSystemImpl
		 * @see modl.impl.ModlPackageImpl#getSatelliteImagingSystem()
		 * @generated
		 */
		EClass SATELLITE_IMAGING_SYSTEM = eINSTANCE.getSatelliteImagingSystem();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference SATELLITE_IMAGING_SYSTEM__DLF = eINSTANCE.getSatelliteImagingSystem_Dlf();

		/**
		 * The meta object literal for the '{@link modl.impl.DefenceAndSurvellianceSystemImpl <em>Defence And Survelliance System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.DefenceAndSurvellianceSystemImpl
		 * @see modl.impl.ModlPackageImpl#getDefenceAndSurvellianceSystem()
		 * @generated
		 */
		EClass DEFENCE_AND_SURVELLIANCE_SYSTEM = eINSTANCE.getDefenceAndSurvellianceSystem();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference DEFENCE_AND_SURVELLIANCE_SYSTEM__DLF = eINSTANCE.getDefenceAndSurvellianceSystem_Dlf();

		/**
		 * The meta object literal for the '{@link modl.impl.MIEROFImpl <em>MIEROF</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.MIEROFImpl
		 * @see modl.impl.ModlPackageImpl#getMIEROF()
		 * @generated
		 */
		EClass MIEROF = eINSTANCE.getMIEROF();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference MIEROF__DLF = eINSTANCE.getMIEROF_Dlf();

		/**
		 * The meta object literal for the '{@link modl.impl.IndustrialAutomationSystemImpl <em>Industrial Automation System</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.IndustrialAutomationSystemImpl
		 * @see modl.impl.ModlPackageImpl#getIndustrialAutomationSystem()
		 * @generated
		 */
		EClass INDUSTRIAL_AUTOMATION_SYSTEM = eINSTANCE.getIndustrialAutomationSystem();

		/**
		 * The meta object literal for the '<em><b>Dlf</b></em>' containment reference feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference INDUSTRIAL_AUTOMATION_SYSTEM__DLF = eINSTANCE.getIndustrialAutomationSystem_Dlf();

		/**
		 * The meta object literal for the '{@link modl.impl.LayerOperationsImpl <em>Layer Operations</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.LayerOperationsImpl
		 * @see modl.impl.ModlPackageImpl#getLayerOperations()
		 * @generated
		 */
		EClass LAYER_OPERATIONS = eINSTANCE.getLayerOperations();

		/**
		 * The meta object literal for the '<em><b>Layer</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EReference LAYER_OPERATIONS__LAYER = eINSTANCE.getLayerOperations_Layer();

		/**
		 * The meta object literal for the '{@link modl.impl.MultiplicationImpl <em>Multiplication</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.MultiplicationImpl
		 * @see modl.impl.ModlPackageImpl#getMultiplication()
		 * @generated
		 */
		EClass MULTIPLICATION = eINSTANCE.getMultiplication();

		/**
		 * The meta object literal for the '{@link modl.impl.AdditionImpl <em>Addition</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.AdditionImpl
		 * @see modl.impl.ModlPackageImpl#getAddition()
		 * @generated
		 */
		EClass ADDITION = eINSTANCE.getAddition();

		/**
		 * The meta object literal for the '{@link modl.impl.ConcatenationImpl <em>Concatenation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.ConcatenationImpl
		 * @see modl.impl.ModlPackageImpl#getConcatenation()
		 * @generated
		 */
		EClass CONCATENATION = eINSTANCE.getConcatenation();

		/**
		 * The meta object literal for the '{@link modl.impl.DepthConcatenationImpl <em>Depth Concatenation</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.DepthConcatenationImpl
		 * @see modl.impl.ModlPackageImpl#getDepthConcatenation()
		 * @generated
		 */
		EClass DEPTH_CONCATENATION = eINSTANCE.getDepthConcatenation();

		/**
		 * The meta object literal for the '{@link modl.impl.VGG16Impl <em>VGG16</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.VGG16Impl
		 * @see modl.impl.ModlPackageImpl#getVGG16()
		 * @generated
		 */
		EClass VGG16 = eINSTANCE.getVGG16();

		/**
		 * The meta object literal for the '{@link modl.impl.AlexNetImpl <em>Alex Net</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.AlexNetImpl
		 * @see modl.impl.ModlPackageImpl#getAlexNet()
		 * @generated
		 */
		EClass ALEX_NET = eINSTANCE.getAlexNet();

		/**
		 * The meta object literal for the '{@link modl.impl.InceptionImpl <em>Inception</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.InceptionImpl
		 * @see modl.impl.ModlPackageImpl#getInception()
		 * @generated
		 */
		EClass INCEPTION = eINSTANCE.getInception();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute INCEPTION__VERSION = eINSTANCE.getInception_Version();

		/**
		 * The meta object literal for the '{@link modl.impl.ResNet50Impl <em>Res Net50</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.ResNet50Impl
		 * @see modl.impl.ModlPackageImpl#getResNet50()
		 * @generated
		 */
		EClass RES_NET50 = eINSTANCE.getResNet50();

		/**
		 * The meta object literal for the '{@link modl.impl.BasicModelImpl <em>Basic Model</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.BasicModelImpl
		 * @see modl.impl.ModlPackageImpl#getBasicModel()
		 * @generated
		 */
		EClass BASIC_MODEL = eINSTANCE.getBasicModel();

		/**
		 * The meta object literal for the '<em><b>Trainable</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_MODEL__TRAINABLE = eINSTANCE.getBasicModel_Trainable();

		/**
		 * The meta object literal for the '<em><b>Include top</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_MODEL__INCLUDE_TOP = eINSTANCE.getBasicModel_Include_top();

		/**
		 * The meta object literal for the '<em><b>Weights trained on</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute BASIC_MODEL__WEIGHTS_TRAINED_ON = eINSTANCE.getBasicModel_Weights_trained_on();

		/**
		 * The meta object literal for the '{@link modl.impl.EfficientNetImpl <em>Efficient Net</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.EfficientNetImpl
		 * @see modl.impl.ModlPackageImpl#getEfficientNet()
		 * @generated
		 */
		EClass EFFICIENT_NET = eINSTANCE.getEfficientNet();

		/**
		 * The meta object literal for the '{@link modl.impl.MobileNetImpl <em>Mobile Net</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.MobileNetImpl
		 * @see modl.impl.ModlPackageImpl#getMobileNet()
		 * @generated
		 */
		EClass MOBILE_NET = eINSTANCE.getMobileNet();

		/**
		 * The meta object literal for the '<em><b>Version</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute MOBILE_NET__VERSION = eINSTANCE.getMobileNet_Version();

		/**
		 * The meta object literal for the '{@link modl.impl.RegNetImpl <em>Reg Net</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.RegNetImpl
		 * @see modl.impl.ModlPackageImpl#getRegNet()
		 * @generated
		 */
		EClass REG_NET = eINSTANCE.getRegNet();

		/**
		 * The meta object literal for the '{@link modl.impl.DenseNetImpl <em>Dense Net</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.impl.DenseNetImpl
		 * @see modl.impl.ModlPackageImpl#getDenseNet()
		 * @generated
		 */
		EClass DENSE_NET = eINSTANCE.getDenseNet();

		/**
		 * The meta object literal for the '{@link modl.PoolingType <em>Pooling Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.PoolingType
		 * @see modl.impl.ModlPackageImpl#getPoolingType()
		 * @generated
		 */
		EEnum POOLING_TYPE = eINSTANCE.getPoolingType();

		/**
		 * The meta object literal for the '{@link modl.ActivationType <em>Activation Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.ActivationType
		 * @see modl.impl.ModlPackageImpl#getActivationType()
		 * @generated
		 */
		EEnum ACTIVATION_TYPE = eINSTANCE.getActivationType();

		/**
		 * The meta object literal for the '{@link modl.ObjectiveType <em>Objective Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.ObjectiveType
		 * @see modl.impl.ModlPackageImpl#getObjectiveType()
		 * @generated
		 */
		EEnum OBJECTIVE_TYPE = eINSTANCE.getObjectiveType();

		/**
		 * The meta object literal for the '{@link modl.MetricType <em>Metric Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.MetricType
		 * @see modl.impl.ModlPackageImpl#getMetricType()
		 * @generated
		 */
		EEnum METRIC_TYPE = eINSTANCE.getMetricType();

		/**
		 * The meta object literal for the '{@link modl.OptimizerType <em>Optimizer Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.OptimizerType
		 * @see modl.impl.ModlPackageImpl#getOptimizerType()
		 * @generated
		 */
		EEnum OPTIMIZER_TYPE = eINSTANCE.getOptimizerType();

		/**
		 * The meta object literal for the '{@link modl.RegulizerType <em>Regulizer Type</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see modl.RegulizerType
		 * @see modl.impl.ModlPackageImpl#getRegulizerType()
		 * @generated
		 */
		EEnum REGULIZER_TYPE = eINSTANCE.getRegulizerType();

		/**
		 * The meta object literal for the '<em>Image Array</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.Object
		 * @see modl.impl.ModlPackageImpl#getImageArray()
		 * @generated
		 */
		EDataType IMAGE_ARRAY = eINSTANCE.getImageArray();

		/**
		 * The meta object literal for the '<em>Label Array</em>' data type.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see java.lang.Object
		 * @see modl.impl.ModlPackageImpl#getLabelArray()
		 * @generated
		 */
		EDataType LABEL_ARRAY = eINSTANCE.getLabelArray();

	}

} //ModlPackage
