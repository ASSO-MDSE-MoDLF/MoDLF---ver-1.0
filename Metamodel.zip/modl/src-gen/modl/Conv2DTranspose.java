/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conv2 DTranspose</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getConv2DTranspose()
 * @model
 * @generated
 */
public interface Conv2DTranspose extends ConvLayer {
} // Conv2DTranspose
