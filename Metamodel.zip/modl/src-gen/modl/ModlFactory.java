/**
 */
package modl;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see modl.ModlPackage
 * @generated
 */
public interface ModlFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ModlFactory eINSTANCE = modl.impl.ModlFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>DLF</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>DLF</em>'.
	 * @generated
	 */
	DLF createDLF();

	/**
	 * Returns a new object of class '<em>Training DS</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Training DS</em>'.
	 * @generated
	 */
	TrainingDS createTrainingDS();

	/**
	 * Returns a new object of class '<em>Testing DS</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Testing DS</em>'.
	 * @generated
	 */
	TestingDS createTestingDS();

	/**
	 * Returns a new object of class '<em>Image</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Image</em>'.
	 * @generated
	 */
	Image createImage();

	/**
	 * Returns a new object of class '<em>Label</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Label</em>'.
	 * @generated
	 */
	Label createLabel();

	/**
	 * Returns a new object of class '<em>CNN Model</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>CNN Model</em>'.
	 * @generated
	 */
	CNNModel createCNNModel();

	/**
	 * Returns a new object of class '<em>Training Parameters</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Training Parameters</em>'.
	 * @generated
	 */
	TrainingParameters createTrainingParameters();

	/**
	 * Returns a new object of class '<em>Testing Parameters</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Testing Parameters</em>'.
	 * @generated
	 */
	TestingParameters createTestingParameters();

	/**
	 * Returns a new object of class '<em>Input Layer</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Input Layer</em>'.
	 * @generated
	 */
	InputLayer createInputLayer();

	/**
	 * Returns a new object of class '<em>Conv2 D</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Conv2 D</em>'.
	 * @generated
	 */
	Conv2D createConv2D();

	/**
	 * Returns a new object of class '<em>Pooling2 D</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Pooling2 D</em>'.
	 * @generated
	 */
	Pooling2D createPooling2D();

	/**
	 * Returns a new object of class '<em>Upsampling2 D</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Upsampling2 D</em>'.
	 * @generated
	 */
	Upsampling2D createUpsampling2D();

	/**
	 * Returns a new object of class '<em>Conv2 DTranspose</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Conv2 DTranspose</em>'.
	 * @generated
	 */
	Conv2DTranspose createConv2DTranspose();

	/**
	 * Returns a new object of class '<em>Dense</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dense</em>'.
	 * @generated
	 */
	Dense createDense();

	/**
	 * Returns a new object of class '<em>Output</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Output</em>'.
	 * @generated
	 */
	Output createOutput();

	/**
	 * Returns a new object of class '<em>Automotive System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Automotive System</em>'.
	 * @generated
	 */
	AutomotiveSystem createAutomotiveSystem();

	/**
	 * Returns a new object of class '<em>East ADL</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>East ADL</em>'.
	 * @generated
	 */
	EastADL createEastADL();

	/**
	 * Returns a new object of class '<em>AUTOSAR</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>AUTOSAR</em>'.
	 * @generated
	 */
	AUTOSAR createAUTOSAR();

	/**
	 * Returns a new object of class '<em>Medical Imaging System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Medical Imaging System</em>'.
	 * @generated
	 */
	MedicalImagingSystem createMedicalImagingSystem();

	/**
	 * Returns a new object of class '<em>Satellite Imaging System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Satellite Imaging System</em>'.
	 * @generated
	 */
	SatelliteImagingSystem createSatelliteImagingSystem();

	/**
	 * Returns a new object of class '<em>Defence And Survelliance System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Defence And Survelliance System</em>'.
	 * @generated
	 */
	DefenceAndSurvellianceSystem createDefenceAndSurvellianceSystem();

	/**
	 * Returns a new object of class '<em>MIEROF</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>MIEROF</em>'.
	 * @generated
	 */
	MIEROF createMIEROF();

	/**
	 * Returns a new object of class '<em>Industrial Automation System</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Industrial Automation System</em>'.
	 * @generated
	 */
	IndustrialAutomationSystem createIndustrialAutomationSystem();

	/**
	 * Returns a new object of class '<em>Multiplication</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Multiplication</em>'.
	 * @generated
	 */
	Multiplication createMultiplication();

	/**
	 * Returns a new object of class '<em>Addition</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Addition</em>'.
	 * @generated
	 */
	Addition createAddition();

	/**
	 * Returns a new object of class '<em>Concatenation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Concatenation</em>'.
	 * @generated
	 */
	Concatenation createConcatenation();

	/**
	 * Returns a new object of class '<em>Depth Concatenation</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Depth Concatenation</em>'.
	 * @generated
	 */
	DepthConcatenation createDepthConcatenation();

	/**
	 * Returns a new object of class '<em>VGG16</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>VGG16</em>'.
	 * @generated
	 */
	VGG16 createVGG16();

	/**
	 * Returns a new object of class '<em>Alex Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Alex Net</em>'.
	 * @generated
	 */
	AlexNet createAlexNet();

	/**
	 * Returns a new object of class '<em>Inception</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Inception</em>'.
	 * @generated
	 */
	Inception createInception();

	/**
	 * Returns a new object of class '<em>Res Net50</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Res Net50</em>'.
	 * @generated
	 */
	ResNet50 createResNet50();

	/**
	 * Returns a new object of class '<em>Efficient Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Efficient Net</em>'.
	 * @generated
	 */
	EfficientNet createEfficientNet();

	/**
	 * Returns a new object of class '<em>Mobile Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Mobile Net</em>'.
	 * @generated
	 */
	MobileNet createMobileNet();

	/**
	 * Returns a new object of class '<em>Reg Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Reg Net</em>'.
	 * @generated
	 */
	RegNet createRegNet();

	/**
	 * Returns a new object of class '<em>Dense Net</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Dense Net</em>'.
	 * @generated
	 */
	DenseNet createDenseNet();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ModlPackage getModlPackage();

} //ModlFactory
