/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Conv Layer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.ConvLayer#getKernel_width <em>Kernel width</em>}</li>
 *   <li>{@link modl.ConvLayer#getKernel_height <em>Kernel height</em>}</li>
 *   <li>{@link modl.ConvLayer#getStride <em>Stride</em>}</li>
 *   <li>{@link modl.ConvLayer#getPadding <em>Padding</em>}</li>
 *   <li>{@link modl.ConvLayer#getOutput_channels <em>Output channels</em>}</li>
 *   <li>{@link modl.ConvLayer#isFlatten <em>Flatten</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getConvLayer()
 * @model abstract="true"
 * @generated
 */
public interface ConvLayer extends Layer {
	/**
	 * Returns the value of the '<em><b>Kernel width</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Kernel width</em>' attribute.
	 * @see #setKernel_width(int)
	 * @see modl.ModlPackage#getConvLayer_Kernel_width()
	 * @model
	 * @generated
	 */
	int getKernel_width();

	/**
	 * Sets the value of the '{@link modl.ConvLayer#getKernel_width <em>Kernel width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Kernel width</em>' attribute.
	 * @see #getKernel_width()
	 * @generated
	 */
	void setKernel_width(int value);

	/**
	 * Returns the value of the '<em><b>Kernel height</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Kernel height</em>' attribute.
	 * @see #setKernel_height(int)
	 * @see modl.ModlPackage#getConvLayer_Kernel_height()
	 * @model
	 * @generated
	 */
	int getKernel_height();

	/**
	 * Sets the value of the '{@link modl.ConvLayer#getKernel_height <em>Kernel height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Kernel height</em>' attribute.
	 * @see #getKernel_height()
	 * @generated
	 */
	void setKernel_height(int value);

	/**
	 * Returns the value of the '<em><b>Stride</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Stride</em>' attribute.
	 * @see #setStride(int)
	 * @see modl.ModlPackage#getConvLayer_Stride()
	 * @model
	 * @generated
	 */
	int getStride();

	/**
	 * Sets the value of the '{@link modl.ConvLayer#getStride <em>Stride</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Stride</em>' attribute.
	 * @see #getStride()
	 * @generated
	 */
	void setStride(int value);

	/**
	 * Returns the value of the '<em><b>Padding</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Padding</em>' attribute.
	 * @see #setPadding(int)
	 * @see modl.ModlPackage#getConvLayer_Padding()
	 * @model
	 * @generated
	 */
	int getPadding();

	/**
	 * Sets the value of the '{@link modl.ConvLayer#getPadding <em>Padding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Padding</em>' attribute.
	 * @see #getPadding()
	 * @generated
	 */
	void setPadding(int value);

	/**
	 * Returns the value of the '<em><b>Output channels</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Output channels</em>' attribute.
	 * @see #setOutput_channels(int)
	 * @see modl.ModlPackage#getConvLayer_Output_channels()
	 * @model
	 * @generated
	 */
	int getOutput_channels();

	/**
	 * Sets the value of the '{@link modl.ConvLayer#getOutput_channels <em>Output channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Output channels</em>' attribute.
	 * @see #getOutput_channels()
	 * @generated
	 */
	void setOutput_channels(int value);

	/**
	 * Returns the value of the '<em><b>Flatten</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Flatten</em>' attribute.
	 * @see #setFlatten(boolean)
	 * @see modl.ModlPackage#getConvLayer_Flatten()
	 * @model
	 * @generated
	 */
	boolean isFlatten();

	/**
	 * Sets the value of the '{@link modl.ConvLayer#isFlatten <em>Flatten</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Flatten</em>' attribute.
	 * @see #isFlatten()
	 * @generated
	 */
	void setFlatten(boolean value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void output_feature_map(int width, int height, int depth);

} // ConvLayer
