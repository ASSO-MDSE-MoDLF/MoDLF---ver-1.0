/**
 */
package modl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Activation Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see modl.ModlPackage#getActivationType()
 * @model
 * @generated
 */
public enum ActivationType implements Enumerator {
	/**
	 * The '<em><b>Sigmoid</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SIGMOID_VALUE
	 * @generated
	 * @ordered
	 */
	SIGMOID(0, "sigmoid", "sigmoid"),

	/**
	 * The '<em><b>Relu</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RELU_VALUE
	 * @generated
	 * @ordered
	 */
	RELU(1, "relu", "relu"),

	/**
	 * The '<em><b>Leaky relu</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LEAKY_RELU_VALUE
	 * @generated
	 * @ordered
	 */
	LEAKY_RELU(2, "leaky_relu", "leaky_relu"),

	/**
	 * The '<em><b>Swish</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SWISH_VALUE
	 * @generated
	 * @ordered
	 */
	SWISH(3, "swish", "swish"),

	/**
	 * The '<em><b>Tanh</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TANH_VALUE
	 * @generated
	 * @ordered
	 */
	TANH(4, "tanh", "tanh"),

	/**
	 * The '<em><b>Softmax</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SOFTMAX_VALUE
	 * @generated
	 * @ordered
	 */
	SOFTMAX(5, "softmax", "softmax"),

	/**
	 * The '<em><b>Null</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NULL_VALUE
	 * @generated
	 * @ordered
	 */
	NULL(6, "null", "null");

	/**
	 * The '<em><b>Sigmoid</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SIGMOID
	 * @model name="sigmoid"
	 * @generated
	 * @ordered
	 */
	public static final int SIGMOID_VALUE = 0;

	/**
	 * The '<em><b>Relu</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #RELU
	 * @model name="relu"
	 * @generated
	 * @ordered
	 */
	public static final int RELU_VALUE = 1;

	/**
	 * The '<em><b>Leaky relu</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #LEAKY_RELU
	 * @model name="leaky_relu"
	 * @generated
	 * @ordered
	 */
	public static final int LEAKY_RELU_VALUE = 2;

	/**
	 * The '<em><b>Swish</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SWISH
	 * @model name="swish"
	 * @generated
	 * @ordered
	 */
	public static final int SWISH_VALUE = 3;

	/**
	 * The '<em><b>Tanh</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TANH
	 * @model name="tanh"
	 * @generated
	 * @ordered
	 */
	public static final int TANH_VALUE = 4;

	/**
	 * The '<em><b>Softmax</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #SOFTMAX
	 * @model name="softmax"
	 * @generated
	 * @ordered
	 */
	public static final int SOFTMAX_VALUE = 5;

	/**
	 * The '<em><b>Null</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #NULL
	 * @model name="null"
	 * @generated
	 * @ordered
	 */
	public static final int NULL_VALUE = 6;

	/**
	 * An array of all the '<em><b>Activation Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final ActivationType[] VALUES_ARRAY = new ActivationType[] { SIGMOID, RELU, LEAKY_RELU, SWISH, TANH,
			SOFTMAX, NULL, };

	/**
	 * A public read-only list of all the '<em><b>Activation Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<ActivationType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Activation Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ActivationType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ActivationType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Activation Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ActivationType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ActivationType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Activation Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ActivationType get(int value) {
		switch (value) {
		case SIGMOID_VALUE:
			return SIGMOID;
		case RELU_VALUE:
			return RELU;
		case LEAKY_RELU_VALUE:
			return LEAKY_RELU;
		case SWISH_VALUE:
			return SWISH;
		case TANH_VALUE:
			return TANH;
		case SOFTMAX_VALUE:
			return SOFTMAX;
		case NULL_VALUE:
			return NULL;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ActivationType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //ActivationType
