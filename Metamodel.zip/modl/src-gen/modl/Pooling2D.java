/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pooling2 D</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Pooling2D#getType <em>Type</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getPooling2D()
 * @model
 * @generated
 */
public interface Pooling2D extends ConvLayer {
	/**
	 * Returns the value of the '<em><b>Type</b></em>' attribute.
	 * The literals are from the enumeration {@link modl.PoolingType}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Type</em>' attribute.
	 * @see modl.PoolingType
	 * @see #setType(PoolingType)
	 * @see modl.ModlPackage#getPooling2D_Type()
	 * @model
	 * @generated
	 */
	PoolingType getType();

	/**
	 * Sets the value of the '{@link modl.Pooling2D#getType <em>Type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Type</em>' attribute.
	 * @see modl.PoolingType
	 * @see #getType()
	 * @generated
	 */
	void setType(PoolingType value);

} // Pooling2D
