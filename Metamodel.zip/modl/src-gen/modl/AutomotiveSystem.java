/**
 */
package modl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Automotive System</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.AutomotiveSystem#getDlf <em>Dlf</em>}</li>
 *   <li>{@link modl.AutomotiveSystem#getEastadl <em>Eastadl</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getAutomotiveSystem()
 * @model
 * @generated
 */
public interface AutomotiveSystem extends EObject {
	/**
	 * Returns the value of the '<em><b>Dlf</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dlf</em>' containment reference.
	 * @see #setDlf(DLF)
	 * @see modl.ModlPackage#getAutomotiveSystem_Dlf()
	 * @model containment="true"
	 * @generated
	 */
	DLF getDlf();

	/**
	 * Sets the value of the '{@link modl.AutomotiveSystem#getDlf <em>Dlf</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Dlf</em>' containment reference.
	 * @see #getDlf()
	 * @generated
	 */
	void setDlf(DLF value);

	/**
	 * Returns the value of the '<em><b>Eastadl</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Eastadl</em>' containment reference.
	 * @see #setEastadl(EastADL)
	 * @see modl.ModlPackage#getAutomotiveSystem_Eastadl()
	 * @model containment="true"
	 * @generated
	 */
	EastADL getEastadl();

	/**
	 * Sets the value of the '{@link modl.AutomotiveSystem#getEastadl <em>Eastadl</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Eastadl</em>' containment reference.
	 * @see #getEastadl()
	 * @generated
	 */
	void setEastadl(EastADL value);

} // AutomotiveSystem
