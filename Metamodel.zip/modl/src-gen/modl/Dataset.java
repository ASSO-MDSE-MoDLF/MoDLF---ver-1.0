/**
 */
package modl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dataset</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Dataset#getQual_path <em>Qual path</em>}</li>
 *   <li>{@link modl.Dataset#getImage <em>Image</em>}</li>
 *   <li>{@link modl.Dataset#getLabel <em>Label</em>}</li>
 *   <li>{@link modl.Dataset#getCnnmodel <em>Cnnmodel</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getDataset()
 * @model abstract="true"
 * @generated
 */
public interface Dataset extends EObject {
	/**
	 * Returns the value of the '<em><b>Qual path</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Qual path</em>' attribute.
	 * @see #setQual_path(String)
	 * @see modl.ModlPackage#getDataset_Qual_path()
	 * @model
	 * @generated
	 */
	String getQual_path();

	/**
	 * Sets the value of the '{@link modl.Dataset#getQual_path <em>Qual path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Qual path</em>' attribute.
	 * @see #getQual_path()
	 * @generated
	 */
	void setQual_path(String value);

	/**
	 * Returns the value of the '<em><b>Image</b></em>' containment reference list.
	 * The list contents are of type {@link modl.Image}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image</em>' containment reference list.
	 * @see modl.ModlPackage#getDataset_Image()
	 * @model containment="true"
	 * @generated
	 */
	EList<Image> getImage();

	/**
	 * Returns the value of the '<em><b>Label</b></em>' containment reference list.
	 * The list contents are of type {@link modl.Label}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Label</em>' containment reference list.
	 * @see modl.ModlPackage#getDataset_Label()
	 * @model containment="true"
	 * @generated
	 */
	EList<Label> getLabel();

	/**
	 * Returns the value of the '<em><b>Cnnmodel</b></em>' reference list.
	 * The list contents are of type {@link modl.CNNModel}.
	 * It is bidirectional and its opposite is '{@link modl.CNNModel#getDataset <em>Dataset</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cnnmodel</em>' reference list.
	 * @see modl.ModlPackage#getDataset_Cnnmodel()
	 * @see modl.CNNModel#getDataset
	 * @model opposite="dataset"
	 * @generated
	 */
	EList<CNNModel> getCnnmodel();

} // Dataset
