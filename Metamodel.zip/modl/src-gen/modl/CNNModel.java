/**
 */
package modl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>CNN Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.CNNModel#getDataset <em>Dataset</em>}</li>
 *   <li>{@link modl.CNNModel#getName <em>Name</em>}</li>
 *   <li>{@link modl.CNNModel#getLayer <em>Layer</em>}</li>
 *   <li>{@link modl.CNNModel#getCnnmodel <em>Cnnmodel</em>}</li>
 *   <li>{@link modl.CNNModel#getCnnmodeleOpposite <em>Cnnmodele Opposite</em>}</li>
 *   <li>{@link modl.CNNModel#getParameters <em>Parameters</em>}</li>
 *   <li>{@link modl.CNNModel#getLayeroperations <em>Layeroperations</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getCNNModel()
 * @model
 * @generated
 */
public interface CNNModel extends EObject {
	/**
	 * Returns the value of the '<em><b>Dataset</b></em>' reference list.
	 * The list contents are of type {@link modl.Dataset}.
	 * It is bidirectional and its opposite is '{@link modl.Dataset#getCnnmodel <em>Cnnmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Dataset</em>' reference list.
	 * @see modl.ModlPackage#getCNNModel_Dataset()
	 * @see modl.Dataset#getCnnmodel
	 * @model opposite="cnnmodel"
	 * @generated
	 */
	EList<Dataset> getDataset();

	/**
	 * Returns the value of the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Name</em>' attribute.
	 * @see #setName(String)
	 * @see modl.ModlPackage#getCNNModel_Name()
	 * @model
	 * @generated
	 */
	String getName();

	/**
	 * Sets the value of the '{@link modl.CNNModel#getName <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Name</em>' attribute.
	 * @see #getName()
	 * @generated
	 */
	void setName(String value);

	/**
	 * Returns the value of the '<em><b>Layer</b></em>' containment reference list.
	 * The list contents are of type {@link modl.Layer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layer</em>' containment reference list.
	 * @see modl.ModlPackage#getCNNModel_Layer()
	 * @model containment="true"
	 * @generated
	 */
	EList<Layer> getLayer();

	/**
	 * Returns the value of the '<em><b>Cnnmodel</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link modl.CNNModel#getCnnmodeleOpposite <em>Cnnmodele Opposite</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cnnmodel</em>' reference.
	 * @see #setCnnmodel(CNNModel)
	 * @see modl.ModlPackage#getCNNModel_Cnnmodel()
	 * @see modl.CNNModel#getCnnmodeleOpposite
	 * @model opposite="cnnmodeleOpposite"
	 * @generated
	 */
	CNNModel getCnnmodel();

	/**
	 * Sets the value of the '{@link modl.CNNModel#getCnnmodel <em>Cnnmodel</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cnnmodel</em>' reference.
	 * @see #getCnnmodel()
	 * @generated
	 */
	void setCnnmodel(CNNModel value);

	/**
	 * Returns the value of the '<em><b>Cnnmodele Opposite</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link modl.CNNModel#getCnnmodel <em>Cnnmodel</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Cnnmodele Opposite</em>' reference.
	 * @see #setCnnmodeleOpposite(CNNModel)
	 * @see modl.ModlPackage#getCNNModel_CnnmodeleOpposite()
	 * @see modl.CNNModel#getCnnmodel
	 * @model opposite="cnnmodel"
	 * @generated
	 */
	CNNModel getCnnmodeleOpposite();

	/**
	 * Sets the value of the '{@link modl.CNNModel#getCnnmodeleOpposite <em>Cnnmodele Opposite</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Cnnmodele Opposite</em>' reference.
	 * @see #getCnnmodeleOpposite()
	 * @generated
	 */
	void setCnnmodeleOpposite(CNNModel value);

	/**
	 * Returns the value of the '<em><b>Parameters</b></em>' containment reference list.
	 * The list contents are of type {@link modl.Parameters}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parameters</em>' containment reference list.
	 * @see modl.ModlPackage#getCNNModel_Parameters()
	 * @model containment="true" upper="2"
	 * @generated
	 */
	EList<Parameters> getParameters();

	/**
	 * Returns the value of the '<em><b>Layeroperations</b></em>' containment reference list.
	 * The list contents are of type {@link modl.LayerOperations}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layeroperations</em>' containment reference list.
	 * @see modl.ModlPackage#getCNNModel_Layeroperations()
	 * @model containment="true"
	 * @generated
	 */
	EList<LayerOperations> getLayeroperations();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void compile_model();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void layers();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model
	 * @generated
	 */
	void params();

} // CNNModel
