/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Addition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getAddition()
 * @model
 * @generated
 */
public interface Addition extends LayerOperations {
} // Addition
