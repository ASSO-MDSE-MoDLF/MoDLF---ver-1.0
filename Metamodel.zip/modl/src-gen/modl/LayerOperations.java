/**
 */
package modl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layer Operations</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.LayerOperations#getLayer <em>Layer</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getLayerOperations()
 * @model abstract="true"
 * @generated
 */
public interface LayerOperations extends EObject {
	/**
	 * Returns the value of the '<em><b>Layer</b></em>' reference list.
	 * The list contents are of type {@link modl.Layer}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Layer</em>' reference list.
	 * @see modl.ModlPackage#getLayerOperations_Layer()
	 * @model
	 * @generated
	 */
	EList<Layer> getLayer();

} // LayerOperations
