/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Alex Net</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getAlexNet()
 * @model
 * @generated
 */
public interface AlexNet extends BasicModel {
} // AlexNet
