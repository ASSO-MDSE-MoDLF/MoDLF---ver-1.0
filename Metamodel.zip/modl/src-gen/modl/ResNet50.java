/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Res Net50</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getResNet50()
 * @model
 * @generated
 */
public interface ResNet50 extends BasicModel {
} // ResNet50
