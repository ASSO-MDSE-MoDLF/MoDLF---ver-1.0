/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dense Net</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getDenseNet()
 * @model
 * @generated
 */
public interface DenseNet extends BasicModel {
} // DenseNet
