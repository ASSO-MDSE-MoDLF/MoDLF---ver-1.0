/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>VGG16</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see modl.ModlPackage#getVGG16()
 * @model
 * @generated
 */
public interface VGG16 extends BasicModel {
} // VGG16
