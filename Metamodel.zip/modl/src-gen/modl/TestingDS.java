/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Testing DS</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.TestingDS#getX_test <em>Xtest</em>}</li>
 *   <li>{@link modl.TestingDS#getY_test <em>Ytest</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getTestingDS()
 * @model
 * @generated
 */
public interface TestingDS extends Dataset {
	/**
	 * Returns the value of the '<em><b>Xtest</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Xtest</em>' attribute.
	 * @see #setX_test(Object)
	 * @see modl.ModlPackage#getTestingDS_X_test()
	 * @model dataType="modl.ImageArray"
	 * @generated
	 */
	Object getX_test();

	/**
	 * Sets the value of the '{@link modl.TestingDS#getX_test <em>Xtest</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Xtest</em>' attribute.
	 * @see #getX_test()
	 * @generated
	 */
	void setX_test(Object value);

	/**
	 * Returns the value of the '<em><b>Ytest</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ytest</em>' attribute.
	 * @see #setY_test(Object)
	 * @see modl.ModlPackage#getTestingDS_Y_test()
	 * @model dataType="modl.LabelArray"
	 * @generated
	 */
	Object getY_test();

	/**
	 * Sets the value of the '{@link modl.TestingDS#getY_test <em>Ytest</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ytest</em>' attribute.
	 * @see #getY_test()
	 * @generated
	 */
	void setY_test(Object value);

} // TestingDS
