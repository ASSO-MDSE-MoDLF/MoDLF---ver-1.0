/**
 */
package modl.impl;

import modl.DenseNet;
import modl.ModlPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dense Net</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class DenseNetImpl extends BasicModelImpl implements DenseNet {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DenseNetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.DENSE_NET;
	}

} //DenseNetImpl
