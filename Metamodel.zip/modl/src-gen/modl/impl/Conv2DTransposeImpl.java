/**
 */
package modl.impl;

import modl.Conv2DTranspose;
import modl.ModlPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Conv2 DTranspose</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class Conv2DTransposeImpl extends ConvLayerImpl implements Conv2DTranspose {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Conv2DTransposeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.CONV2_DTRANSPOSE;
	}

} //Conv2DTransposeImpl
