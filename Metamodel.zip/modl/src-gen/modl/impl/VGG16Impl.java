/**
 */
package modl.impl;

import modl.ModlPackage;
import modl.VGG16;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>VGG16</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class VGG16Impl extends BasicModelImpl implements VGG16 {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected VGG16Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.VGG16;
	}

} //VGG16Impl
