/**
 */
package modl.impl;

import modl.EfficientNet;
import modl.ModlPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Efficient Net</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EfficientNetImpl extends BasicModelImpl implements EfficientNet {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EfficientNetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.EFFICIENT_NET;
	}

} //EfficientNetImpl
