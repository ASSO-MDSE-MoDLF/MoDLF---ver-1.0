/**
 */
package modl.impl;

import modl.MetricType;
import modl.ModlPackage;
import modl.ObjectiveType;
import modl.OptimizerType;
import modl.TrainingParameters;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Training Parameters</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.TrainingParametersImpl#getEpochs <em>Epochs</em>}</li>
 *   <li>{@link modl.impl.TrainingParametersImpl#getObjective_function <em>Objective function</em>}</li>
 *   <li>{@link modl.impl.TrainingParametersImpl#getOptimizer <em>Optimizer</em>}</li>
 *   <li>{@link modl.impl.TrainingParametersImpl#getMetric <em>Metric</em>}</li>
 *   <li>{@link modl.impl.TrainingParametersImpl#getLearning_rate <em>Learning rate</em>}</li>
 *   <li>{@link modl.impl.TrainingParametersImpl#getDecay_rate <em>Decay rate</em>}</li>
 *   <li>{@link modl.impl.TrainingParametersImpl#getMomentum <em>Momentum</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TrainingParametersImpl extends ParametersImpl implements TrainingParameters {
	/**
	 * The default value of the '{@link #getEpochs() <em>Epochs</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEpochs()
	 * @generated
	 * @ordered
	 */
	protected static final int EPOCHS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getEpochs() <em>Epochs</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEpochs()
	 * @generated
	 * @ordered
	 */
	protected int epochs = EPOCHS_EDEFAULT;

	/**
	 * The default value of the '{@link #getObjective_function() <em>Objective function</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjective_function()
	 * @generated
	 * @ordered
	 */
	protected static final ObjectiveType OBJECTIVE_FUNCTION_EDEFAULT = ObjectiveType.MSE;

	/**
	 * The cached value of the '{@link #getObjective_function() <em>Objective function</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getObjective_function()
	 * @generated
	 * @ordered
	 */
	protected ObjectiveType objective_function = OBJECTIVE_FUNCTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getOptimizer() <em>Optimizer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOptimizer()
	 * @generated
	 * @ordered
	 */
	protected static final OptimizerType OPTIMIZER_EDEFAULT = OptimizerType.SGD;

	/**
	 * The cached value of the '{@link #getOptimizer() <em>Optimizer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOptimizer()
	 * @generated
	 * @ordered
	 */
	protected OptimizerType optimizer = OPTIMIZER_EDEFAULT;

	/**
	 * The default value of the '{@link #getMetric() <em>Metric</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMetric()
	 * @generated
	 * @ordered
	 */
	protected static final MetricType METRIC_EDEFAULT = MetricType.ACCURACY;

	/**
	 * The cached value of the '{@link #getMetric() <em>Metric</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMetric()
	 * @generated
	 * @ordered
	 */
	protected MetricType metric = METRIC_EDEFAULT;

	/**
	 * The default value of the '{@link #getLearning_rate() <em>Learning rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLearning_rate()
	 * @generated
	 * @ordered
	 */
	protected static final double LEARNING_RATE_EDEFAULT = 0.01;

	/**
	 * The cached value of the '{@link #getLearning_rate() <em>Learning rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLearning_rate()
	 * @generated
	 * @ordered
	 */
	protected double learning_rate = LEARNING_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getDecay_rate() <em>Decay rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDecay_rate()
	 * @generated
	 * @ordered
	 */
	protected static final float DECAY_RATE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getDecay_rate() <em>Decay rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDecay_rate()
	 * @generated
	 * @ordered
	 */
	protected float decay_rate = DECAY_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getMomentum() <em>Momentum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMomentum()
	 * @generated
	 * @ordered
	 */
	protected static final float MOMENTUM_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getMomentum() <em>Momentum</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getMomentum()
	 * @generated
	 * @ordered
	 */
	protected float momentum = MOMENTUM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TrainingParametersImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.TRAINING_PARAMETERS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getEpochs() {
		return epochs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEpochs(int newEpochs) {
		int oldEpochs = epochs;
		epochs = newEpochs;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_PARAMETERS__EPOCHS, oldEpochs,
					epochs));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ObjectiveType getObjective_function() {
		return objective_function;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setObjective_function(ObjectiveType newObjective_function) {
		ObjectiveType oldObjective_function = objective_function;
		objective_function = newObjective_function == null ? OBJECTIVE_FUNCTION_EDEFAULT : newObjective_function;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_PARAMETERS__OBJECTIVE_FUNCTION,
					oldObjective_function, objective_function));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public OptimizerType getOptimizer() {
		return optimizer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOptimizer(OptimizerType newOptimizer) {
		OptimizerType oldOptimizer = optimizer;
		optimizer = newOptimizer == null ? OPTIMIZER_EDEFAULT : newOptimizer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_PARAMETERS__OPTIMIZER,
					oldOptimizer, optimizer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MetricType getMetric() {
		return metric;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMetric(MetricType newMetric) {
		MetricType oldMetric = metric;
		metric = newMetric == null ? METRIC_EDEFAULT : newMetric;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_PARAMETERS__METRIC, oldMetric,
					metric));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public double getLearning_rate() {
		return learning_rate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLearning_rate(double newLearning_rate) {
		double oldLearning_rate = learning_rate;
		learning_rate = newLearning_rate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_PARAMETERS__LEARNING_RATE,
					oldLearning_rate, learning_rate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getDecay_rate() {
		return decay_rate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDecay_rate(float newDecay_rate) {
		float oldDecay_rate = decay_rate;
		decay_rate = newDecay_rate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_PARAMETERS__DECAY_RATE,
					oldDecay_rate, decay_rate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getMomentum() {
		return momentum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setMomentum(float newMomentum) {
		float oldMomentum = momentum;
		momentum = newMomentum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_PARAMETERS__MOMENTUM,
					oldMomentum, momentum));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.TRAINING_PARAMETERS__EPOCHS:
			return getEpochs();
		case ModlPackage.TRAINING_PARAMETERS__OBJECTIVE_FUNCTION:
			return getObjective_function();
		case ModlPackage.TRAINING_PARAMETERS__OPTIMIZER:
			return getOptimizer();
		case ModlPackage.TRAINING_PARAMETERS__METRIC:
			return getMetric();
		case ModlPackage.TRAINING_PARAMETERS__LEARNING_RATE:
			return getLearning_rate();
		case ModlPackage.TRAINING_PARAMETERS__DECAY_RATE:
			return getDecay_rate();
		case ModlPackage.TRAINING_PARAMETERS__MOMENTUM:
			return getMomentum();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.TRAINING_PARAMETERS__EPOCHS:
			setEpochs((Integer) newValue);
			return;
		case ModlPackage.TRAINING_PARAMETERS__OBJECTIVE_FUNCTION:
			setObjective_function((ObjectiveType) newValue);
			return;
		case ModlPackage.TRAINING_PARAMETERS__OPTIMIZER:
			setOptimizer((OptimizerType) newValue);
			return;
		case ModlPackage.TRAINING_PARAMETERS__METRIC:
			setMetric((MetricType) newValue);
			return;
		case ModlPackage.TRAINING_PARAMETERS__LEARNING_RATE:
			setLearning_rate((Double) newValue);
			return;
		case ModlPackage.TRAINING_PARAMETERS__DECAY_RATE:
			setDecay_rate((Float) newValue);
			return;
		case ModlPackage.TRAINING_PARAMETERS__MOMENTUM:
			setMomentum((Float) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.TRAINING_PARAMETERS__EPOCHS:
			setEpochs(EPOCHS_EDEFAULT);
			return;
		case ModlPackage.TRAINING_PARAMETERS__OBJECTIVE_FUNCTION:
			setObjective_function(OBJECTIVE_FUNCTION_EDEFAULT);
			return;
		case ModlPackage.TRAINING_PARAMETERS__OPTIMIZER:
			setOptimizer(OPTIMIZER_EDEFAULT);
			return;
		case ModlPackage.TRAINING_PARAMETERS__METRIC:
			setMetric(METRIC_EDEFAULT);
			return;
		case ModlPackage.TRAINING_PARAMETERS__LEARNING_RATE:
			setLearning_rate(LEARNING_RATE_EDEFAULT);
			return;
		case ModlPackage.TRAINING_PARAMETERS__DECAY_RATE:
			setDecay_rate(DECAY_RATE_EDEFAULT);
			return;
		case ModlPackage.TRAINING_PARAMETERS__MOMENTUM:
			setMomentum(MOMENTUM_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.TRAINING_PARAMETERS__EPOCHS:
			return epochs != EPOCHS_EDEFAULT;
		case ModlPackage.TRAINING_PARAMETERS__OBJECTIVE_FUNCTION:
			return objective_function != OBJECTIVE_FUNCTION_EDEFAULT;
		case ModlPackage.TRAINING_PARAMETERS__OPTIMIZER:
			return optimizer != OPTIMIZER_EDEFAULT;
		case ModlPackage.TRAINING_PARAMETERS__METRIC:
			return metric != METRIC_EDEFAULT;
		case ModlPackage.TRAINING_PARAMETERS__LEARNING_RATE:
			return learning_rate != LEARNING_RATE_EDEFAULT;
		case ModlPackage.TRAINING_PARAMETERS__DECAY_RATE:
			return decay_rate != DECAY_RATE_EDEFAULT;
		case ModlPackage.TRAINING_PARAMETERS__MOMENTUM:
			return momentum != MOMENTUM_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (epochs: ");
		result.append(epochs);
		result.append(", objective_function: ");
		result.append(objective_function);
		result.append(", optimizer: ");
		result.append(optimizer);
		result.append(", metric: ");
		result.append(metric);
		result.append(", learning_rate: ");
		result.append(learning_rate);
		result.append(", decay_rate: ");
		result.append(decay_rate);
		result.append(", momentum: ");
		result.append(momentum);
		result.append(')');
		return result.toString();
	}

} //TrainingParametersImpl
