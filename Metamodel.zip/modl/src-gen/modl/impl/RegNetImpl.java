/**
 */
package modl.impl;

import modl.ModlPackage;
import modl.RegNet;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Reg Net</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RegNetImpl extends BasicModelImpl implements RegNet {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RegNetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.REG_NET;
	}

} //RegNetImpl
