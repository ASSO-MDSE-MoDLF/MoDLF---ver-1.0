/**
 */
package modl.impl;

import modl.AutomotiveSystem;
import modl.DLF;
import modl.EastADL;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Automotive System</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.AutomotiveSystemImpl#getDlf <em>Dlf</em>}</li>
 *   <li>{@link modl.impl.AutomotiveSystemImpl#getEastadl <em>Eastadl</em>}</li>
 * </ul>
 *
 * @generated
 */
public class AutomotiveSystemImpl extends MinimalEObjectImpl.Container implements AutomotiveSystem {
	/**
	 * The cached value of the '{@link #getDlf() <em>Dlf</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDlf()
	 * @generated
	 * @ordered
	 */
	protected DLF dlf;

	/**
	 * The cached value of the '{@link #getEastadl() <em>Eastadl</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEastadl()
	 * @generated
	 * @ordered
	 */
	protected EastADL eastadl;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected AutomotiveSystemImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.AUTOMOTIVE_SYSTEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DLF getDlf() {
		return dlf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDlf(DLF newDlf, NotificationChain msgs) {
		DLF oldDlf = dlf;
		dlf = newDlf;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ModlPackage.AUTOMOTIVE_SYSTEM__DLF, oldDlf, newDlf);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDlf(DLF newDlf) {
		if (newDlf != dlf) {
			NotificationChain msgs = null;
			if (dlf != null)
				msgs = ((InternalEObject) dlf).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - ModlPackage.AUTOMOTIVE_SYSTEM__DLF, null, msgs);
			if (newDlf != null)
				msgs = ((InternalEObject) newDlf).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - ModlPackage.AUTOMOTIVE_SYSTEM__DLF, null, msgs);
			msgs = basicSetDlf(newDlf, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.AUTOMOTIVE_SYSTEM__DLF, newDlf, newDlf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EastADL getEastadl() {
		return eastadl;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetEastadl(EastADL newEastadl, NotificationChain msgs) {
		EastADL oldEastadl = eastadl;
		eastadl = newEastadl;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL, oldEastadl, newEastadl);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setEastadl(EastADL newEastadl) {
		if (newEastadl != eastadl) {
			NotificationChain msgs = null;
			if (eastadl != null)
				msgs = ((InternalEObject) eastadl).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL, null, msgs);
			if (newEastadl != null)
				msgs = ((InternalEObject) newEastadl).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL, null, msgs);
			msgs = basicSetEastadl(newEastadl, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL, newEastadl,
					newEastadl));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.AUTOMOTIVE_SYSTEM__DLF:
			return basicSetDlf(null, msgs);
		case ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL:
			return basicSetEastadl(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.AUTOMOTIVE_SYSTEM__DLF:
			return getDlf();
		case ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL:
			return getEastadl();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.AUTOMOTIVE_SYSTEM__DLF:
			setDlf((DLF) newValue);
			return;
		case ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL:
			setEastadl((EastADL) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.AUTOMOTIVE_SYSTEM__DLF:
			setDlf((DLF) null);
			return;
		case ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL:
			setEastadl((EastADL) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.AUTOMOTIVE_SYSTEM__DLF:
			return dlf != null;
		case ModlPackage.AUTOMOTIVE_SYSTEM__EASTADL:
			return eastadl != null;
		}
		return super.eIsSet(featureID);
	}

} //AutomotiveSystemImpl
