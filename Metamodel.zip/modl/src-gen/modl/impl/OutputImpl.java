/**
 */
package modl.impl;

import modl.ModlPackage;
import modl.Output;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Output</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.OutputImpl#getOutput_classes <em>Output classes</em>}</li>
 *   <li>{@link modl.impl.OutputImpl#getArray_of_classes <em>Array of classes</em>}</li>
 * </ul>
 *
 * @generated
 */
public class OutputImpl extends LinearLayerImpl implements Output {
	/**
	 * The default value of the '{@link #getOutput_classes() <em>Output classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutput_classes()
	 * @generated
	 * @ordered
	 */
	protected static final int OUTPUT_CLASSES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getOutput_classes() <em>Output classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutput_classes()
	 * @generated
	 * @ordered
	 */
	protected int output_classes = OUTPUT_CLASSES_EDEFAULT;

	/**
	 * The default value of the '{@link #getArray_of_classes() <em>Array of classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArray_of_classes()
	 * @generated
	 * @ordered
	 */
	protected static final int ARRAY_OF_CLASSES_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getArray_of_classes() <em>Array of classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArray_of_classes()
	 * @generated
	 * @ordered
	 */
	protected int array_of_classes = ARRAY_OF_CLASSES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OutputImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.OUTPUT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getOutput_classes() {
		return output_classes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOutput_classes(int newOutput_classes) {
		int oldOutput_classes = output_classes;
		output_classes = newOutput_classes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.OUTPUT__OUTPUT_CLASSES, oldOutput_classes,
					output_classes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getArray_of_classes() {
		return array_of_classes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setArray_of_classes(int newArray_of_classes) {
		int oldArray_of_classes = array_of_classes;
		array_of_classes = newArray_of_classes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.OUTPUT__ARRAY_OF_CLASSES,
					oldArray_of_classes, array_of_classes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.OUTPUT__OUTPUT_CLASSES:
			return getOutput_classes();
		case ModlPackage.OUTPUT__ARRAY_OF_CLASSES:
			return getArray_of_classes();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.OUTPUT__OUTPUT_CLASSES:
			setOutput_classes((Integer) newValue);
			return;
		case ModlPackage.OUTPUT__ARRAY_OF_CLASSES:
			setArray_of_classes((Integer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.OUTPUT__OUTPUT_CLASSES:
			setOutput_classes(OUTPUT_CLASSES_EDEFAULT);
			return;
		case ModlPackage.OUTPUT__ARRAY_OF_CLASSES:
			setArray_of_classes(ARRAY_OF_CLASSES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.OUTPUT__OUTPUT_CLASSES:
			return output_classes != OUTPUT_CLASSES_EDEFAULT;
		case ModlPackage.OUTPUT__ARRAY_OF_CLASSES:
			return array_of_classes != ARRAY_OF_CLASSES_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (output_classes: ");
		result.append(output_classes);
		result.append(", array_of_classes: ");
		result.append(array_of_classes);
		result.append(')');
		return result.toString();
	}

} //OutputImpl
