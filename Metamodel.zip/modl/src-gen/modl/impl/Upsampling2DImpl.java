/**
 */
package modl.impl;

import modl.ModlPackage;
import modl.Upsampling2D;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Upsampling2 D</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class Upsampling2DImpl extends ConvLayerImpl implements Upsampling2D {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Upsampling2DImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.UPSAMPLING2_D;
	}

} //Upsampling2DImpl
