/**
 */
package modl.impl;

import modl.DLF;
import modl.MIEROF;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>MIEROF</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.MIEROFImpl#getDlf <em>Dlf</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MIEROFImpl extends MinimalEObjectImpl.Container implements MIEROF {
	/**
	 * The cached value of the '{@link #getDlf() <em>Dlf</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDlf()
	 * @generated
	 * @ordered
	 */
	protected DLF dlf;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MIEROFImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.MIEROF;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DLF getDlf() {
		return dlf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDlf(DLF newDlf, NotificationChain msgs) {
		DLF oldDlf = dlf;
		dlf = newDlf;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModlPackage.MIEROF__DLF,
					oldDlf, newDlf);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDlf(DLF newDlf) {
		if (newDlf != dlf) {
			NotificationChain msgs = null;
			if (dlf != null)
				msgs = ((InternalEObject) dlf).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - ModlPackage.MIEROF__DLF,
						null, msgs);
			if (newDlf != null)
				msgs = ((InternalEObject) newDlf).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - ModlPackage.MIEROF__DLF,
						null, msgs);
			msgs = basicSetDlf(newDlf, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.MIEROF__DLF, newDlf, newDlf));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.MIEROF__DLF:
			return basicSetDlf(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.MIEROF__DLF:
			return getDlf();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.MIEROF__DLF:
			setDlf((DLF) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.MIEROF__DLF:
			setDlf((DLF) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.MIEROF__DLF:
			return dlf != null;
		}
		return super.eIsSet(featureID);
	}

} //MIEROFImpl
