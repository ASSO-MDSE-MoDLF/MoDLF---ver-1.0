/**
 */
package modl.impl;

import modl.*;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.impl.EFactoryImpl;

import org.eclipse.emf.ecore.plugin.EcorePlugin;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Factory</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModlFactoryImpl extends EFactoryImpl implements ModlFactory {
	/**
	 * Creates the default factory implementation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static ModlFactory init() {
		try {
			ModlFactory theModlFactory = (ModlFactory) EPackage.Registry.INSTANCE.getEFactory(ModlPackage.eNS_URI);
			if (theModlFactory != null) {
				return theModlFactory;
			}
		} catch (Exception exception) {
			EcorePlugin.INSTANCE.log(exception);
		}
		return new ModlFactoryImpl();
	}

	/**
	 * Creates an instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ModlFactoryImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EObject create(EClass eClass) {
		switch (eClass.getClassifierID()) {
		case ModlPackage.DLF:
			return createDLF();
		case ModlPackage.TRAINING_DS:
			return createTrainingDS();
		case ModlPackage.TESTING_DS:
			return createTestingDS();
		case ModlPackage.IMAGE:
			return createImage();
		case ModlPackage.LABEL:
			return createLabel();
		case ModlPackage.CNN_MODEL:
			return createCNNModel();
		case ModlPackage.TRAINING_PARAMETERS:
			return createTrainingParameters();
		case ModlPackage.TESTING_PARAMETERS:
			return createTestingParameters();
		case ModlPackage.INPUT_LAYER:
			return createInputLayer();
		case ModlPackage.CONV2_D:
			return createConv2D();
		case ModlPackage.POOLING2_D:
			return createPooling2D();
		case ModlPackage.UPSAMPLING2_D:
			return createUpsampling2D();
		case ModlPackage.CONV2_DTRANSPOSE:
			return createConv2DTranspose();
		case ModlPackage.DENSE:
			return createDense();
		case ModlPackage.OUTPUT:
			return createOutput();
		case ModlPackage.AUTOMOTIVE_SYSTEM:
			return createAutomotiveSystem();
		case ModlPackage.EAST_ADL:
			return createEastADL();
		case ModlPackage.AUTOSAR:
			return createAUTOSAR();
		case ModlPackage.MEDICAL_IMAGING_SYSTEM:
			return createMedicalImagingSystem();
		case ModlPackage.SATELLITE_IMAGING_SYSTEM:
			return createSatelliteImagingSystem();
		case ModlPackage.DEFENCE_AND_SURVELLIANCE_SYSTEM:
			return createDefenceAndSurvellianceSystem();
		case ModlPackage.MIEROF:
			return createMIEROF();
		case ModlPackage.INDUSTRIAL_AUTOMATION_SYSTEM:
			return createIndustrialAutomationSystem();
		case ModlPackage.MULTIPLICATION:
			return createMultiplication();
		case ModlPackage.ADDITION:
			return createAddition();
		case ModlPackage.CONCATENATION:
			return createConcatenation();
		case ModlPackage.DEPTH_CONCATENATION:
			return createDepthConcatenation();
		case ModlPackage.VGG16:
			return createVGG16();
		case ModlPackage.ALEX_NET:
			return createAlexNet();
		case ModlPackage.INCEPTION:
			return createInception();
		case ModlPackage.RES_NET50:
			return createResNet50();
		case ModlPackage.EFFICIENT_NET:
			return createEfficientNet();
		case ModlPackage.MOBILE_NET:
			return createMobileNet();
		case ModlPackage.REG_NET:
			return createRegNet();
		case ModlPackage.DENSE_NET:
			return createDenseNet();
		default:
			throw new IllegalArgumentException("The class '" + eClass.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object createFromString(EDataType eDataType, String initialValue) {
		switch (eDataType.getClassifierID()) {
		case ModlPackage.POOLING_TYPE:
			return createPoolingTypeFromString(eDataType, initialValue);
		case ModlPackage.ACTIVATION_TYPE:
			return createActivationTypeFromString(eDataType, initialValue);
		case ModlPackage.OBJECTIVE_TYPE:
			return createObjectiveTypeFromString(eDataType, initialValue);
		case ModlPackage.METRIC_TYPE:
			return createMetricTypeFromString(eDataType, initialValue);
		case ModlPackage.OPTIMIZER_TYPE:
			return createOptimizerTypeFromString(eDataType, initialValue);
		case ModlPackage.REGULIZER_TYPE:
			return createRegulizerTypeFromString(eDataType, initialValue);
		case ModlPackage.IMAGE_ARRAY:
			return createImageArrayFromString(eDataType, initialValue);
		case ModlPackage.LABEL_ARRAY:
			return createLabelArrayFromString(eDataType, initialValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String convertToString(EDataType eDataType, Object instanceValue) {
		switch (eDataType.getClassifierID()) {
		case ModlPackage.POOLING_TYPE:
			return convertPoolingTypeToString(eDataType, instanceValue);
		case ModlPackage.ACTIVATION_TYPE:
			return convertActivationTypeToString(eDataType, instanceValue);
		case ModlPackage.OBJECTIVE_TYPE:
			return convertObjectiveTypeToString(eDataType, instanceValue);
		case ModlPackage.METRIC_TYPE:
			return convertMetricTypeToString(eDataType, instanceValue);
		case ModlPackage.OPTIMIZER_TYPE:
			return convertOptimizerTypeToString(eDataType, instanceValue);
		case ModlPackage.REGULIZER_TYPE:
			return convertRegulizerTypeToString(eDataType, instanceValue);
		case ModlPackage.IMAGE_ARRAY:
			return convertImageArrayToString(eDataType, instanceValue);
		case ModlPackage.LABEL_ARRAY:
			return convertLabelArrayToString(eDataType, instanceValue);
		default:
			throw new IllegalArgumentException("The datatype '" + eDataType.getName() + "' is not a valid classifier");
		}
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DLF createDLF() {
		DLFImpl dlf = new DLFImpl();
		return dlf;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TrainingDS createTrainingDS() {
		TrainingDSImpl trainingDS = new TrainingDSImpl();
		return trainingDS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TestingDS createTestingDS() {
		TestingDSImpl testingDS = new TestingDSImpl();
		return testingDS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Image createImage() {
		ImageImpl image = new ImageImpl();
		return image;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Label createLabel() {
		LabelImpl label = new LabelImpl();
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CNNModel createCNNModel() {
		CNNModelImpl cnnModel = new CNNModelImpl();
		return cnnModel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TrainingParameters createTrainingParameters() {
		TrainingParametersImpl trainingParameters = new TrainingParametersImpl();
		return trainingParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public TestingParameters createTestingParameters() {
		TestingParametersImpl testingParameters = new TestingParametersImpl();
		return testingParameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InputLayer createInputLayer() {
		InputLayerImpl inputLayer = new InputLayerImpl();
		return inputLayer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Conv2D createConv2D() {
		Conv2DImpl conv2D = new Conv2DImpl();
		return conv2D;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Pooling2D createPooling2D() {
		Pooling2DImpl pooling2D = new Pooling2DImpl();
		return pooling2D;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Upsampling2D createUpsampling2D() {
		Upsampling2DImpl upsampling2D = new Upsampling2DImpl();
		return upsampling2D;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Conv2DTranspose createConv2DTranspose() {
		Conv2DTransposeImpl conv2DTranspose = new Conv2DTransposeImpl();
		return conv2DTranspose;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Dense createDense() {
		DenseImpl dense = new DenseImpl();
		return dense;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Output createOutput() {
		OutputImpl output = new OutputImpl();
		return output;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AutomotiveSystem createAutomotiveSystem() {
		AutomotiveSystemImpl automotiveSystem = new AutomotiveSystemImpl();
		return automotiveSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EastADL createEastADL() {
		EastADLImpl eastADL = new EastADLImpl();
		return eastADL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AUTOSAR createAUTOSAR() {
		AUTOSARImpl autosar = new AUTOSARImpl();
		return autosar;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MedicalImagingSystem createMedicalImagingSystem() {
		MedicalImagingSystemImpl medicalImagingSystem = new MedicalImagingSystemImpl();
		return medicalImagingSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public SatelliteImagingSystem createSatelliteImagingSystem() {
		SatelliteImagingSystemImpl satelliteImagingSystem = new SatelliteImagingSystemImpl();
		return satelliteImagingSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DefenceAndSurvellianceSystem createDefenceAndSurvellianceSystem() {
		DefenceAndSurvellianceSystemImpl defenceAndSurvellianceSystem = new DefenceAndSurvellianceSystemImpl();
		return defenceAndSurvellianceSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MIEROF createMIEROF() {
		MIEROFImpl mierof = new MIEROFImpl();
		return mierof;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public IndustrialAutomationSystem createIndustrialAutomationSystem() {
		IndustrialAutomationSystemImpl industrialAutomationSystem = new IndustrialAutomationSystemImpl();
		return industrialAutomationSystem;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Multiplication createMultiplication() {
		MultiplicationImpl multiplication = new MultiplicationImpl();
		return multiplication;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Addition createAddition() {
		AdditionImpl addition = new AdditionImpl();
		return addition;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Concatenation createConcatenation() {
		ConcatenationImpl concatenation = new ConcatenationImpl();
		return concatenation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DepthConcatenation createDepthConcatenation() {
		DepthConcatenationImpl depthConcatenation = new DepthConcatenationImpl();
		return depthConcatenation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public VGG16 createVGG16() {
		VGG16Impl vgg16 = new VGG16Impl();
		return vgg16;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public AlexNet createAlexNet() {
		AlexNetImpl alexNet = new AlexNetImpl();
		return alexNet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Inception createInception() {
		InceptionImpl inception = new InceptionImpl();
		return inception;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ResNet50 createResNet50() {
		ResNet50Impl resNet50 = new ResNet50Impl();
		return resNet50;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EfficientNet createEfficientNet() {
		EfficientNetImpl efficientNet = new EfficientNetImpl();
		return efficientNet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public MobileNet createMobileNet() {
		MobileNetImpl mobileNet = new MobileNetImpl();
		return mobileNet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RegNet createRegNet() {
		RegNetImpl regNet = new RegNetImpl();
		return regNet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public DenseNet createDenseNet() {
		DenseNetImpl denseNet = new DenseNetImpl();
		return denseNet;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PoolingType createPoolingTypeFromString(EDataType eDataType, String initialValue) {
		PoolingType result = PoolingType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertPoolingTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ActivationType createActivationTypeFromString(EDataType eDataType, String initialValue) {
		ActivationType result = ActivationType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertActivationTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ObjectiveType createObjectiveTypeFromString(EDataType eDataType, String initialValue) {
		ObjectiveType result = ObjectiveType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertObjectiveTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MetricType createMetricTypeFromString(EDataType eDataType, String initialValue) {
		MetricType result = MetricType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertMetricTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public OptimizerType createOptimizerTypeFromString(EDataType eDataType, String initialValue) {
		OptimizerType result = OptimizerType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertOptimizerTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public RegulizerType createRegulizerTypeFromString(EDataType eDataType, String initialValue) {
		RegulizerType result = RegulizerType.get(initialValue);
		if (result == null)
			throw new IllegalArgumentException(
					"The value '" + initialValue + "' is not a valid enumerator of '" + eDataType.getName() + "'");
		return result;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertRegulizerTypeToString(EDataType eDataType, Object instanceValue) {
		return instanceValue == null ? null : instanceValue.toString();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createImageArrayFromString(EDataType eDataType, String initialValue) {
		return super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertImageArrayToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object createLabelArrayFromString(EDataType eDataType, String initialValue) {
		return super.createFromString(eDataType, initialValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String convertLabelArrayToString(EDataType eDataType, Object instanceValue) {
		return super.convertToString(eDataType, instanceValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ModlPackage getModlPackage() {
		return (ModlPackage) getEPackage();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @deprecated
	 * @generated
	 */
	@Deprecated
	public static ModlPackage getPackage() {
		return ModlPackage.eINSTANCE;
	}

} //ModlFactoryImpl
