/**
 */
package modl.impl;

import modl.BasicModel;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Basic Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.BasicModelImpl#isTrainable <em>Trainable</em>}</li>
 *   <li>{@link modl.impl.BasicModelImpl#isInclude_top <em>Include top</em>}</li>
 *   <li>{@link modl.impl.BasicModelImpl#getWeights_trained_on <em>Weights trained on</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class BasicModelImpl extends CNNModelImpl implements BasicModel {
	/**
	 * The default value of the '{@link #isTrainable() <em>Trainable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTrainable()
	 * @generated
	 * @ordered
	 */
	protected static final boolean TRAINABLE_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isTrainable() <em>Trainable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isTrainable()
	 * @generated
	 * @ordered
	 */
	protected boolean trainable = TRAINABLE_EDEFAULT;

	/**
	 * The default value of the '{@link #isInclude_top() <em>Include top</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isInclude_top()
	 * @generated
	 * @ordered
	 */
	protected static final boolean INCLUDE_TOP_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isInclude_top() <em>Include top</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isInclude_top()
	 * @generated
	 * @ordered
	 */
	protected boolean include_top = INCLUDE_TOP_EDEFAULT;

	/**
	 * The default value of the '{@link #getWeights_trained_on() <em>Weights trained on</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeights_trained_on()
	 * @generated
	 * @ordered
	 */
	protected static final String WEIGHTS_TRAINED_ON_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getWeights_trained_on() <em>Weights trained on</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getWeights_trained_on()
	 * @generated
	 * @ordered
	 */
	protected String weights_trained_on = WEIGHTS_TRAINED_ON_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BasicModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.BASIC_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isTrainable() {
		return trainable;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setTrainable(boolean newTrainable) {
		boolean oldTrainable = trainable;
		trainable = newTrainable;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.BASIC_MODEL__TRAINABLE, oldTrainable,
					trainable));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isInclude_top() {
		return include_top;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInclude_top(boolean newInclude_top) {
		boolean oldInclude_top = include_top;
		include_top = newInclude_top;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.BASIC_MODEL__INCLUDE_TOP, oldInclude_top,
					include_top));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getWeights_trained_on() {
		return weights_trained_on;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setWeights_trained_on(String newWeights_trained_on) {
		String oldWeights_trained_on = weights_trained_on;
		weights_trained_on = newWeights_trained_on;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.BASIC_MODEL__WEIGHTS_TRAINED_ON,
					oldWeights_trained_on, weights_trained_on));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.BASIC_MODEL__TRAINABLE:
			return isTrainable();
		case ModlPackage.BASIC_MODEL__INCLUDE_TOP:
			return isInclude_top();
		case ModlPackage.BASIC_MODEL__WEIGHTS_TRAINED_ON:
			return getWeights_trained_on();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.BASIC_MODEL__TRAINABLE:
			setTrainable((Boolean) newValue);
			return;
		case ModlPackage.BASIC_MODEL__INCLUDE_TOP:
			setInclude_top((Boolean) newValue);
			return;
		case ModlPackage.BASIC_MODEL__WEIGHTS_TRAINED_ON:
			setWeights_trained_on((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.BASIC_MODEL__TRAINABLE:
			setTrainable(TRAINABLE_EDEFAULT);
			return;
		case ModlPackage.BASIC_MODEL__INCLUDE_TOP:
			setInclude_top(INCLUDE_TOP_EDEFAULT);
			return;
		case ModlPackage.BASIC_MODEL__WEIGHTS_TRAINED_ON:
			setWeights_trained_on(WEIGHTS_TRAINED_ON_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.BASIC_MODEL__TRAINABLE:
			return trainable != TRAINABLE_EDEFAULT;
		case ModlPackage.BASIC_MODEL__INCLUDE_TOP:
			return include_top != INCLUDE_TOP_EDEFAULT;
		case ModlPackage.BASIC_MODEL__WEIGHTS_TRAINED_ON:
			return WEIGHTS_TRAINED_ON_EDEFAULT == null ? weights_trained_on != null
					: !WEIGHTS_TRAINED_ON_EDEFAULT.equals(weights_trained_on);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (trainable: ");
		result.append(trainable);
		result.append(", include_top: ");
		result.append(include_top);
		result.append(", weights_trained_on: ");
		result.append(weights_trained_on);
		result.append(')');
		return result.toString();
	}

} //BasicModelImpl
