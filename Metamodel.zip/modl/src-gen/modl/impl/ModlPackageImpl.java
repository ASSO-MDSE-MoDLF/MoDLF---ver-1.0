/**
 */
package modl.impl;

import modl.ActivationType;
import modl.Addition;
import modl.AlexNet;
import modl.AutomotiveSystem;
import modl.BasicModel;
import modl.CNNModel;
import modl.Concatenation;
import modl.Conv2D;
import modl.Conv2DTranspose;
import modl.ConvLayer;
import modl.Dataset;
import modl.DefenceAndSurvellianceSystem;
import modl.Dense;
import modl.DenseNet;
import modl.DepthConcatenation;
import modl.EastADL;
import modl.EfficientNet;
import modl.Image;
import modl.Inception;
import modl.IndustrialAutomationSystem;
import modl.InputLayer;
import modl.Label;
import modl.Layer;
import modl.LayerOperations;
import modl.LinearLayer;
import modl.MedicalImagingSystem;
import modl.MetricType;
import modl.MobileNet;
import modl.ModlFactory;
import modl.ModlPackage;
import modl.Multiplication;
import modl.ObjectiveType;
import modl.OptimizerType;
import modl.Output;
import modl.Parameters;
import modl.Pooling2D;
import modl.PoolingType;
import modl.RegNet;
import modl.RegulizerType;
import modl.ResNet50;
import modl.SatelliteImagingSystem;
import modl.TestingDS;
import modl.TestingParameters;
import modl.TrainingDS;
import modl.TrainingParameters;
import modl.Upsampling2D;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EOperation;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ModlPackageImpl extends EPackageImpl implements ModlPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass dlfEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass datasetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass trainingDSEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testingDSEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass imageEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass labelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass cnnModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass trainingParametersEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass testingParametersEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass layerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inputLayerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass convLayerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass linearLayerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conv2DEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass pooling2DEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass upsampling2DEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass conv2DTransposeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass denseEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass outputEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass parametersEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass automotiveSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass eastADLEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass autosarEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass medicalImagingSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass satelliteImagingSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass defenceAndSurvellianceSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mierofEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass industrialAutomationSystemEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass layerOperationsEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass multiplicationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass additionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass concatenationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass depthConcatenationEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass vgg16EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass alexNetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass inceptionEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass resNet50EClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass basicModelEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass efficientNetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass mobileNetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass regNetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass denseNetEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum poolingTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum activationTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum objectiveTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum metricTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum optimizerTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum regulizerTypeEEnum = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType imageArrayEDataType = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EDataType labelArrayEDataType = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see modl.ModlPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ModlPackageImpl() {
		super(eNS_URI, ModlFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ModlPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ModlPackage init() {
		if (isInited)
			return (ModlPackage) EPackage.Registry.INSTANCE.getEPackage(ModlPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredModlPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ModlPackageImpl theModlPackage = registeredModlPackage instanceof ModlPackageImpl
				? (ModlPackageImpl) registeredModlPackage
				: new ModlPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theModlPackage.createPackageContents();

		// Initialize created meta-data
		theModlPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theModlPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ModlPackage.eNS_URI, theModlPackage);
		return theModlPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDLF() {
		return dlfEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDLF_Dataset() {
		return (EReference) dlfEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDLF_Cnnmodel() {
		return (EReference) dlfEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDLF_Basicmodel() {
		return (EReference) dlfEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDataset() {
		return datasetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDataset_Qual_path() {
		return (EAttribute) datasetEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDataset_Image() {
		return (EReference) datasetEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDataset_Label() {
		return (EReference) datasetEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDataset_Cnnmodel() {
		return (EReference) datasetEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTrainingDS() {
		return trainingDSEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingDS_X_train() {
		return (EAttribute) trainingDSEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingDS_Y_train() {
		return (EAttribute) trainingDSEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTestingDS() {
		return testingDSEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTestingDS_X_test() {
		return (EAttribute) testingDSEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTestingDS_Y_test() {
		return (EAttribute) testingDSEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getImage() {
		return imageEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getImage_Label() {
		return (EReference) imageEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getImage_Name() {
		return (EAttribute) imageEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getImage_File_type() {
		return (EAttribute) imageEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getImage_Image_width() {
		return (EAttribute) imageEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getImage_Image_height() {
		return (EAttribute) imageEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getImage_Image_channels() {
		return (EAttribute) imageEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getImage_Inputlayer() {
		return (EReference) imageEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLabel() {
		return labelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLabel_Image() {
		return (EReference) labelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getCNNModel() {
		return cnnModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCNNModel_Dataset() {
		return (EReference) cnnModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getCNNModel_Name() {
		return (EAttribute) cnnModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCNNModel_Layer() {
		return (EReference) cnnModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCNNModel_Cnnmodel() {
		return (EReference) cnnModelEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCNNModel_CnnmodeleOpposite() {
		return (EReference) cnnModelEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCNNModel_Parameters() {
		return (EReference) cnnModelEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getCNNModel_Layeroperations() {
		return (EReference) cnnModelEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCNNModel__Compile_model() {
		return cnnModelEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCNNModel__Layers() {
		return cnnModelEClass.getEOperations().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getCNNModel__Params() {
		return cnnModelEClass.getEOperations().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTrainingParameters() {
		return trainingParametersEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingParameters_Epochs() {
		return (EAttribute) trainingParametersEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingParameters_Objective_function() {
		return (EAttribute) trainingParametersEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingParameters_Optimizer() {
		return (EAttribute) trainingParametersEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingParameters_Metric() {
		return (EAttribute) trainingParametersEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingParameters_Learning_rate() {
		return (EAttribute) trainingParametersEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingParameters_Decay_rate() {
		return (EAttribute) trainingParametersEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTrainingParameters_Momentum() {
		return (EAttribute) trainingParametersEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getTestingParameters() {
		return testingParametersEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getTestingParameters_Confidence() {
		return (EAttribute) testingParametersEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLayer() {
		return layerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLayer_Name() {
		return (EAttribute) layerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLayer_Activation() {
		return (EAttribute) layerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLayer_Batch_normalization() {
		return (EAttribute) layerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLayer_Layer() {
		return (EReference) layerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLayer_LayereOpposite() {
		return (EReference) layerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLayer_Layeroperations() {
		return (EReference) layerEClass.getEStructuralFeatures().get(9);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLayer_Regularizer() {
		return (EAttribute) layerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLayer_Reg_rate() {
		return (EAttribute) layerEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLayer_Do_dropout() {
		return (EAttribute) layerEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getLayer_Dropout_rate() {
		return (EAttribute) layerEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getLayer__Activation_function() {
		return layerEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInputLayer() {
		return inputLayerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInputLayer_Input_width() {
		return (EAttribute) inputLayerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInputLayer_Input_height() {
		return (EAttribute) inputLayerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInputLayer_Input_channels() {
		return (EAttribute) inputLayerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInputLayer_Array_of_classes() {
		return (EAttribute) inputLayerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getInputLayer_Image() {
		return (EReference) inputLayerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getInputLayer__Reshape__double() {
		return inputLayerEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConvLayer() {
		return convLayerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConvLayer_Kernel_width() {
		return (EAttribute) convLayerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConvLayer_Kernel_height() {
		return (EAttribute) convLayerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConvLayer_Stride() {
		return (EAttribute) convLayerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConvLayer_Padding() {
		return (EAttribute) convLayerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConvLayer_Output_channels() {
		return (EAttribute) convLayerEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getConvLayer_Flatten() {
		return (EAttribute) convLayerEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EOperation getConvLayer__Output_feature_map__int_int_int() {
		return convLayerEClass.getEOperations().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLinearLayer() {
		return linearLayerEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConv2D() {
		return conv2DEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getPooling2D() {
		return pooling2DEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getPooling2D_Type() {
		return (EAttribute) pooling2DEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getUpsampling2D() {
		return upsampling2DEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConv2DTranspose() {
		return conv2DTransposeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDense() {
		return denseEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getDense_Output_features() {
		return (EAttribute) denseEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getOutput() {
		return outputEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getOutput_Output_classes() {
		return (EAttribute) outputEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getOutput_Array_of_classes() {
		return (EAttribute) outputEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getParameters() {
		return parametersEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getParameters_Batch_size() {
		return (EAttribute) parametersEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAutomotiveSystem() {
		return automotiveSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAutomotiveSystem_Dlf() {
		return (EReference) automotiveSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAutomotiveSystem_Eastadl() {
		return (EReference) automotiveSystemEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getEastADL() {
		return eastADLEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEastADL_Dlf() {
		return (EReference) eastADLEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getEastADL_Autosar() {
		return (EReference) eastADLEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAUTOSAR() {
		return autosarEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getAUTOSAR_Dlf() {
		return (EReference) autosarEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMedicalImagingSystem() {
		return medicalImagingSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMedicalImagingSystem_Dlf() {
		return (EReference) medicalImagingSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getSatelliteImagingSystem() {
		return satelliteImagingSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getSatelliteImagingSystem_Dlf() {
		return (EReference) satelliteImagingSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDefenceAndSurvellianceSystem() {
		return defenceAndSurvellianceSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getDefenceAndSurvellianceSystem_Dlf() {
		return (EReference) defenceAndSurvellianceSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMIEROF() {
		return mierofEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getMIEROF_Dlf() {
		return (EReference) mierofEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getIndustrialAutomationSystem() {
		return industrialAutomationSystemEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getIndustrialAutomationSystem_Dlf() {
		return (EReference) industrialAutomationSystemEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getLayerOperations() {
		return layerOperationsEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EReference getLayerOperations_Layer() {
		return (EReference) layerOperationsEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMultiplication() {
		return multiplicationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAddition() {
		return additionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getConcatenation() {
		return concatenationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDepthConcatenation() {
		return depthConcatenationEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getVGG16() {
		return vgg16EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getAlexNet() {
		return alexNetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getInception() {
		return inceptionEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getInception_Version() {
		return (EAttribute) inceptionEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getResNet50() {
		return resNet50EClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getBasicModel() {
		return basicModelEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getBasicModel_Trainable() {
		return (EAttribute) basicModelEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getBasicModel_Include_top() {
		return (EAttribute) basicModelEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getBasicModel_Weights_trained_on() {
		return (EAttribute) basicModelEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getEfficientNet() {
		return efficientNetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getMobileNet() {
		return mobileNetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EAttribute getMobileNet_Version() {
		return (EAttribute) mobileNetEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getRegNet() {
		return regNetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EClass getDenseNet() {
		return denseNetEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getPoolingType() {
		return poolingTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getActivationType() {
		return activationTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getObjectiveType() {
		return objectiveTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getMetricType() {
		return metricTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getOptimizerType() {
		return optimizerTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EEnum getRegulizerType() {
		return regulizerTypeEEnum;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EDataType getImageArray() {
		return imageArrayEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EDataType getLabelArray() {
		return labelArrayEDataType;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ModlFactory getModlFactory() {
		return (ModlFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		dlfEClass = createEClass(DLF);
		createEReference(dlfEClass, DLF__DATASET);
		createEReference(dlfEClass, DLF__CNNMODEL);
		createEReference(dlfEClass, DLF__BASICMODEL);

		datasetEClass = createEClass(DATASET);
		createEAttribute(datasetEClass, DATASET__QUAL_PATH);
		createEReference(datasetEClass, DATASET__IMAGE);
		createEReference(datasetEClass, DATASET__LABEL);
		createEReference(datasetEClass, DATASET__CNNMODEL);

		trainingDSEClass = createEClass(TRAINING_DS);
		createEAttribute(trainingDSEClass, TRAINING_DS__XTRAIN);
		createEAttribute(trainingDSEClass, TRAINING_DS__YTRAIN);

		testingDSEClass = createEClass(TESTING_DS);
		createEAttribute(testingDSEClass, TESTING_DS__XTEST);
		createEAttribute(testingDSEClass, TESTING_DS__YTEST);

		imageEClass = createEClass(IMAGE);
		createEReference(imageEClass, IMAGE__LABEL);
		createEAttribute(imageEClass, IMAGE__NAME);
		createEAttribute(imageEClass, IMAGE__FILE_TYPE);
		createEAttribute(imageEClass, IMAGE__IMAGE_WIDTH);
		createEAttribute(imageEClass, IMAGE__IMAGE_HEIGHT);
		createEAttribute(imageEClass, IMAGE__IMAGE_CHANNELS);
		createEReference(imageEClass, IMAGE__INPUTLAYER);

		labelEClass = createEClass(LABEL);
		createEReference(labelEClass, LABEL__IMAGE);

		cnnModelEClass = createEClass(CNN_MODEL);
		createEReference(cnnModelEClass, CNN_MODEL__DATASET);
		createEAttribute(cnnModelEClass, CNN_MODEL__NAME);
		createEReference(cnnModelEClass, CNN_MODEL__LAYER);
		createEReference(cnnModelEClass, CNN_MODEL__CNNMODEL);
		createEReference(cnnModelEClass, CNN_MODEL__CNNMODELE_OPPOSITE);
		createEReference(cnnModelEClass, CNN_MODEL__PARAMETERS);
		createEReference(cnnModelEClass, CNN_MODEL__LAYEROPERATIONS);
		createEOperation(cnnModelEClass, CNN_MODEL___COMPILE_MODEL);
		createEOperation(cnnModelEClass, CNN_MODEL___LAYERS);
		createEOperation(cnnModelEClass, CNN_MODEL___PARAMS);

		trainingParametersEClass = createEClass(TRAINING_PARAMETERS);
		createEAttribute(trainingParametersEClass, TRAINING_PARAMETERS__EPOCHS);
		createEAttribute(trainingParametersEClass, TRAINING_PARAMETERS__OBJECTIVE_FUNCTION);
		createEAttribute(trainingParametersEClass, TRAINING_PARAMETERS__OPTIMIZER);
		createEAttribute(trainingParametersEClass, TRAINING_PARAMETERS__METRIC);
		createEAttribute(trainingParametersEClass, TRAINING_PARAMETERS__LEARNING_RATE);
		createEAttribute(trainingParametersEClass, TRAINING_PARAMETERS__DECAY_RATE);
		createEAttribute(trainingParametersEClass, TRAINING_PARAMETERS__MOMENTUM);

		testingParametersEClass = createEClass(TESTING_PARAMETERS);
		createEAttribute(testingParametersEClass, TESTING_PARAMETERS__CONFIDENCE);

		layerEClass = createEClass(LAYER);
		createEAttribute(layerEClass, LAYER__NAME);
		createEAttribute(layerEClass, LAYER__ACTIVATION);
		createEAttribute(layerEClass, LAYER__BATCH_NORMALIZATION);
		createEReference(layerEClass, LAYER__LAYER);
		createEReference(layerEClass, LAYER__LAYERE_OPPOSITE);
		createEAttribute(layerEClass, LAYER__REGULARIZER);
		createEAttribute(layerEClass, LAYER__REG_RATE);
		createEAttribute(layerEClass, LAYER__DO_DROPOUT);
		createEAttribute(layerEClass, LAYER__DROPOUT_RATE);
		createEReference(layerEClass, LAYER__LAYEROPERATIONS);
		createEOperation(layerEClass, LAYER___ACTIVATION_FUNCTION);

		inputLayerEClass = createEClass(INPUT_LAYER);
		createEAttribute(inputLayerEClass, INPUT_LAYER__INPUT_WIDTH);
		createEAttribute(inputLayerEClass, INPUT_LAYER__INPUT_HEIGHT);
		createEAttribute(inputLayerEClass, INPUT_LAYER__INPUT_CHANNELS);
		createEAttribute(inputLayerEClass, INPUT_LAYER__ARRAY_OF_CLASSES);
		createEReference(inputLayerEClass, INPUT_LAYER__IMAGE);
		createEOperation(inputLayerEClass, INPUT_LAYER___RESHAPE__DOUBLE);

		convLayerEClass = createEClass(CONV_LAYER);
		createEAttribute(convLayerEClass, CONV_LAYER__KERNEL_WIDTH);
		createEAttribute(convLayerEClass, CONV_LAYER__KERNEL_HEIGHT);
		createEAttribute(convLayerEClass, CONV_LAYER__STRIDE);
		createEAttribute(convLayerEClass, CONV_LAYER__PADDING);
		createEAttribute(convLayerEClass, CONV_LAYER__OUTPUT_CHANNELS);
		createEAttribute(convLayerEClass, CONV_LAYER__FLATTEN);
		createEOperation(convLayerEClass, CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT);

		linearLayerEClass = createEClass(LINEAR_LAYER);

		conv2DEClass = createEClass(CONV2_D);

		pooling2DEClass = createEClass(POOLING2_D);
		createEAttribute(pooling2DEClass, POOLING2_D__TYPE);

		upsampling2DEClass = createEClass(UPSAMPLING2_D);

		conv2DTransposeEClass = createEClass(CONV2_DTRANSPOSE);

		denseEClass = createEClass(DENSE);
		createEAttribute(denseEClass, DENSE__OUTPUT_FEATURES);

		outputEClass = createEClass(OUTPUT);
		createEAttribute(outputEClass, OUTPUT__OUTPUT_CLASSES);
		createEAttribute(outputEClass, OUTPUT__ARRAY_OF_CLASSES);

		parametersEClass = createEClass(PARAMETERS);
		createEAttribute(parametersEClass, PARAMETERS__BATCH_SIZE);

		automotiveSystemEClass = createEClass(AUTOMOTIVE_SYSTEM);
		createEReference(automotiveSystemEClass, AUTOMOTIVE_SYSTEM__DLF);
		createEReference(automotiveSystemEClass, AUTOMOTIVE_SYSTEM__EASTADL);

		eastADLEClass = createEClass(EAST_ADL);
		createEReference(eastADLEClass, EAST_ADL__DLF);
		createEReference(eastADLEClass, EAST_ADL__AUTOSAR);

		autosarEClass = createEClass(AUTOSAR);
		createEReference(autosarEClass, AUTOSAR__DLF);

		medicalImagingSystemEClass = createEClass(MEDICAL_IMAGING_SYSTEM);
		createEReference(medicalImagingSystemEClass, MEDICAL_IMAGING_SYSTEM__DLF);

		satelliteImagingSystemEClass = createEClass(SATELLITE_IMAGING_SYSTEM);
		createEReference(satelliteImagingSystemEClass, SATELLITE_IMAGING_SYSTEM__DLF);

		defenceAndSurvellianceSystemEClass = createEClass(DEFENCE_AND_SURVELLIANCE_SYSTEM);
		createEReference(defenceAndSurvellianceSystemEClass, DEFENCE_AND_SURVELLIANCE_SYSTEM__DLF);

		mierofEClass = createEClass(MIEROF);
		createEReference(mierofEClass, MIEROF__DLF);

		industrialAutomationSystemEClass = createEClass(INDUSTRIAL_AUTOMATION_SYSTEM);
		createEReference(industrialAutomationSystemEClass, INDUSTRIAL_AUTOMATION_SYSTEM__DLF);

		layerOperationsEClass = createEClass(LAYER_OPERATIONS);
		createEReference(layerOperationsEClass, LAYER_OPERATIONS__LAYER);

		multiplicationEClass = createEClass(MULTIPLICATION);

		additionEClass = createEClass(ADDITION);

		concatenationEClass = createEClass(CONCATENATION);

		depthConcatenationEClass = createEClass(DEPTH_CONCATENATION);

		vgg16EClass = createEClass(VGG16);

		alexNetEClass = createEClass(ALEX_NET);

		inceptionEClass = createEClass(INCEPTION);
		createEAttribute(inceptionEClass, INCEPTION__VERSION);

		resNet50EClass = createEClass(RES_NET50);

		basicModelEClass = createEClass(BASIC_MODEL);
		createEAttribute(basicModelEClass, BASIC_MODEL__TRAINABLE);
		createEAttribute(basicModelEClass, BASIC_MODEL__INCLUDE_TOP);
		createEAttribute(basicModelEClass, BASIC_MODEL__WEIGHTS_TRAINED_ON);

		efficientNetEClass = createEClass(EFFICIENT_NET);

		mobileNetEClass = createEClass(MOBILE_NET);
		createEAttribute(mobileNetEClass, MOBILE_NET__VERSION);

		regNetEClass = createEClass(REG_NET);

		denseNetEClass = createEClass(DENSE_NET);

		// Create enums
		poolingTypeEEnum = createEEnum(POOLING_TYPE);
		activationTypeEEnum = createEEnum(ACTIVATION_TYPE);
		objectiveTypeEEnum = createEEnum(OBJECTIVE_TYPE);
		metricTypeEEnum = createEEnum(METRIC_TYPE);
		optimizerTypeEEnum = createEEnum(OPTIMIZER_TYPE);
		regulizerTypeEEnum = createEEnum(REGULIZER_TYPE);

		// Create data types
		imageArrayEDataType = createEDataType(IMAGE_ARRAY);
		labelArrayEDataType = createEDataType(LABEL_ARRAY);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		trainingDSEClass.getESuperTypes().add(this.getDataset());
		testingDSEClass.getESuperTypes().add(this.getDataset());
		trainingParametersEClass.getESuperTypes().add(this.getParameters());
		testingParametersEClass.getESuperTypes().add(this.getParameters());
		inputLayerEClass.getESuperTypes().add(this.getLayer());
		convLayerEClass.getESuperTypes().add(this.getLayer());
		linearLayerEClass.getESuperTypes().add(this.getLayer());
		conv2DEClass.getESuperTypes().add(this.getConvLayer());
		pooling2DEClass.getESuperTypes().add(this.getConvLayer());
		upsampling2DEClass.getESuperTypes().add(this.getConvLayer());
		conv2DTransposeEClass.getESuperTypes().add(this.getConvLayer());
		denseEClass.getESuperTypes().add(this.getLinearLayer());
		outputEClass.getESuperTypes().add(this.getLinearLayer());
		multiplicationEClass.getESuperTypes().add(this.getLayerOperations());
		additionEClass.getESuperTypes().add(this.getLayerOperations());
		concatenationEClass.getESuperTypes().add(this.getLayerOperations());
		depthConcatenationEClass.getESuperTypes().add(this.getLayerOperations());
		vgg16EClass.getESuperTypes().add(this.getBasicModel());
		alexNetEClass.getESuperTypes().add(this.getBasicModel());
		inceptionEClass.getESuperTypes().add(this.getBasicModel());
		resNet50EClass.getESuperTypes().add(this.getBasicModel());
		basicModelEClass.getESuperTypes().add(this.getCNNModel());
		efficientNetEClass.getESuperTypes().add(this.getBasicModel());
		mobileNetEClass.getESuperTypes().add(this.getBasicModel());
		regNetEClass.getESuperTypes().add(this.getBasicModel());
		denseNetEClass.getESuperTypes().add(this.getBasicModel());

		// Initialize classes, features, and operations; add parameters
		initEClass(dlfEClass, modl.DLF.class, "DLF", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDLF_Dataset(), this.getDataset(), null, "dataset", null, 0, -1, modl.DLF.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getDLF_Cnnmodel(), this.getCNNModel(), null, "cnnmodel", null, 0, -1, modl.DLF.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDLF_Basicmodel(), this.getBasicModel(), null, "basicmodel", null, 0, -1, modl.DLF.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(datasetEClass, Dataset.class, "Dataset", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDataset_Qual_path(), ecorePackage.getEString(), "qual_path", null, 0, 1, Dataset.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getDataset_Image(), this.getImage(), null, "image", null, 0, -1, Dataset.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getDataset_Label(), this.getLabel(), null, "label", null, 0, -1, Dataset.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getDataset_Cnnmodel(), this.getCNNModel(), this.getCNNModel_Dataset(), "cnnmodel", null, 0, -1,
				Dataset.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(trainingDSEClass, TrainingDS.class, "TrainingDS", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTrainingDS_X_train(), this.getImageArray(), "x_train", null, 0, 1, TrainingDS.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrainingDS_Y_train(), this.getLabelArray(), "y_train", null, 0, 1, TrainingDS.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(testingDSEClass, TestingDS.class, "TestingDS", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTestingDS_X_test(), this.getImageArray(), "x_test", null, 0, 1, TestingDS.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTestingDS_Y_test(), this.getLabelArray(), "y_test", null, 0, 1, TestingDS.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(imageEClass, Image.class, "Image", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getImage_Label(), this.getLabel(), this.getLabel_Image(), "label", null, 1, 1, Image.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getImage_Name(), ecorePackage.getEString(), "name", null, 0, 1, Image.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getImage_File_type(), ecorePackage.getEString(), "file_type", null, 0, 1, Image.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getImage_Image_width(), ecorePackage.getEInt(), "image_width", null, 0, 1, Image.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getImage_Image_height(), ecorePackage.getEInt(), "image_height", null, 0, 1, Image.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getImage_Image_channels(), ecorePackage.getEInt(), "image_channels", null, 0, 1, Image.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getImage_Inputlayer(), this.getInputLayer(), this.getInputLayer_Image(), "inputlayer", null, 0,
				1, Image.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(labelEClass, Label.class, "Label", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getLabel_Image(), this.getImage(), this.getImage_Label(), "image", null, 0, -1, Label.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(cnnModelEClass, CNNModel.class, "CNNModel", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCNNModel_Dataset(), this.getDataset(), this.getDataset_Cnnmodel(), "dataset", null, 0, -1,
				CNNModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCNNModel_Name(), ecorePackage.getEString(), "name", null, 0, 1, CNNModel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCNNModel_Layer(), this.getLayer(), null, "layer", null, 0, -1, CNNModel.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getCNNModel_Cnnmodel(), this.getCNNModel(), this.getCNNModel_CnnmodeleOpposite(), "cnnmodel",
				null, 0, 1, CNNModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCNNModel_CnnmodeleOpposite(), this.getCNNModel(), this.getCNNModel_Cnnmodel(),
				"cnnmodeleOpposite", null, 0, 1, CNNModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE,
				!IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCNNModel_Parameters(), this.getParameters(), null, "parameters", null, 0, 2, CNNModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getCNNModel_Layeroperations(), this.getLayerOperations(), null, "layeroperations", null, 0, -1,
				CNNModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getCNNModel__Compile_model(), null, "compile_model", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCNNModel__Layers(), null, "layers", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEOperation(getCNNModel__Params(), null, "params", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(trainingParametersEClass, TrainingParameters.class, "TrainingParameters", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTrainingParameters_Epochs(), ecorePackage.getEInt(), "epochs", null, 0, 1,
				TrainingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrainingParameters_Objective_function(), this.getObjectiveType(), "objective_function", null,
				0, 1, TrainingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrainingParameters_Optimizer(), this.getOptimizerType(), "optimizer", null, 0, 1,
				TrainingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrainingParameters_Metric(), this.getMetricType(), "metric", null, 0, 1,
				TrainingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrainingParameters_Learning_rate(), ecorePackage.getEDouble(), "learning_rate", "0.01", 0, 1,
				TrainingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrainingParameters_Decay_rate(), ecorePackage.getEFloat(), "decay_rate", "0", 0, 1,
				TrainingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getTrainingParameters_Momentum(), ecorePackage.getEFloat(), "momentum", "0", 0, 1,
				TrainingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(testingParametersEClass, TestingParameters.class, "TestingParameters", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTestingParameters_Confidence(), ecorePackage.getEFloat(), "confidence", "0.5", 0, 1,
				TestingParameters.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(layerEClass, Layer.class, "Layer", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getLayer_Name(), ecorePackage.getEString(), "name", null, 0, 1, Layer.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLayer_Activation(), this.getActivationType(), "activation", null, 0, 1, Layer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLayer_Batch_normalization(), ecorePackage.getEBoolean(), "batch_normalization", null, 0, 1,
				Layer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getLayer_Layer(), this.getLayer(), this.getLayer_LayereOpposite(), "layer", null, 0, -1,
				Layer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getLayer_LayereOpposite(), this.getLayer(), this.getLayer_Layer(), "layereOpposite", null, 0, -1,
				Layer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLayer_Regularizer(), this.getRegulizerType(), "regularizer", "null", 0, 1, Layer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLayer_Reg_rate(), ecorePackage.getEFloat(), "reg_rate", "0.001", 0, 1, Layer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLayer_Do_dropout(), ecorePackage.getEBoolean(), "do_dropout", null, 0, 1, Layer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getLayer_Dropout_rate(), ecorePackage.getEFloat(), "dropout_rate", "0.01", 0, 1, Layer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getLayer_Layeroperations(), this.getLayerOperations(), null, "layeroperations", null, 0, -1,
				Layer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEOperation(getLayer__Activation_function(), null, "activation_function", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(inputLayerEClass, InputLayer.class, "InputLayer", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInputLayer_Input_width(), ecorePackage.getEInt(), "input_width", null, 0, 1, InputLayer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getInputLayer_Input_height(), ecorePackage.getEInt(), "input_height", null, 0, 1,
				InputLayer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getInputLayer_Input_channels(), ecorePackage.getEInt(), "input_channels", null, 0, 1,
				InputLayer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getInputLayer_Array_of_classes(), ecorePackage.getEString(), "array_of_classes", null, 0, 1,
				InputLayer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEReference(getInputLayer_Image(), this.getImage(), this.getImage_Inputlayer(), "image", null, 0, -1,
				InputLayer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		EOperation op = initEOperation(getInputLayer__Reshape__double(), null, "reshape", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEDouble(), "scale_factor", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(convLayerEClass, ConvLayer.class, "ConvLayer", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getConvLayer_Kernel_width(), ecorePackage.getEInt(), "kernel_width", null, 0, 1, ConvLayer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConvLayer_Kernel_height(), ecorePackage.getEInt(), "kernel_height", null, 0, 1,
				ConvLayer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getConvLayer_Stride(), ecorePackage.getEInt(), "stride", null, 0, 1, ConvLayer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConvLayer_Padding(), ecorePackage.getEInt(), "padding", null, 0, 1, ConvLayer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getConvLayer_Output_channels(), ecorePackage.getEInt(), "output_channels", null, 0, 1,
				ConvLayer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getConvLayer_Flatten(), ecorePackage.getEBoolean(), "flatten", null, 0, 1, ConvLayer.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		op = initEOperation(getConvLayer__Output_feature_map__int_int_int(), null, "output_feature_map", 0, 1,
				IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "width", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "height", 0, 1, IS_UNIQUE, IS_ORDERED);
		addEParameter(op, ecorePackage.getEInt(), "depth", 0, 1, IS_UNIQUE, IS_ORDERED);

		initEClass(linearLayerEClass, LinearLayer.class, "LinearLayer", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(conv2DEClass, Conv2D.class, "Conv2D", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(pooling2DEClass, Pooling2D.class, "Pooling2D", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPooling2D_Type(), this.getPoolingType(), "type", null, 0, 1, Pooling2D.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(upsampling2DEClass, Upsampling2D.class, "Upsampling2D", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(conv2DTransposeEClass, Conv2DTranspose.class, "Conv2DTranspose", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(denseEClass, Dense.class, "Dense", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getDense_Output_features(), ecorePackage.getEInt(), "output_features", null, 0, 1, Dense.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(outputEClass, Output.class, "Output", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getOutput_Output_classes(), ecorePackage.getEInt(), "output_classes", null, 0, 1, Output.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getOutput_Array_of_classes(), ecorePackage.getEInt(), "array_of_classes", null, 0, 1,
				Output.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(parametersEClass, Parameters.class, "Parameters", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getParameters_Batch_size(), ecorePackage.getEInt(), "batch_size", null, 0, 1, Parameters.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(automotiveSystemEClass, AutomotiveSystem.class, "AutomotiveSystem", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAutomotiveSystem_Dlf(), this.getDLF(), null, "dlf", null, 0, 1, AutomotiveSystem.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getAutomotiveSystem_Eastadl(), this.getEastADL(), null, "eastadl", null, 0, 1,
				AutomotiveSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(eastADLEClass, EastADL.class, "EastADL", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getEastADL_Dlf(), this.getDLF(), null, "dlf", null, 0, 1, EastADL.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);
		initEReference(getEastADL_Autosar(), this.getAUTOSAR(), null, "autosar", null, 1, 1, EastADL.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(autosarEClass, modl.AUTOSAR.class, "AUTOSAR", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getAUTOSAR_Dlf(), this.getDLF(), null, "dlf", null, 0, 1, modl.AUTOSAR.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(medicalImagingSystemEClass, MedicalImagingSystem.class, "MedicalImagingSystem", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMedicalImagingSystem_Dlf(), this.getDLF(), null, "dlf", null, 0, 1,
				MedicalImagingSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(satelliteImagingSystemEClass, SatelliteImagingSystem.class, "SatelliteImagingSystem", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getSatelliteImagingSystem_Dlf(), this.getDLF(), null, "dlf", null, 0, 1,
				SatelliteImagingSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(defenceAndSurvellianceSystemEClass, DefenceAndSurvellianceSystem.class,
				"DefenceAndSurvellianceSystem", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getDefenceAndSurvellianceSystem_Dlf(), this.getDLF(), null, "dlf", null, 0, 1,
				DefenceAndSurvellianceSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(mierofEClass, modl.MIEROF.class, "MIEROF", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getMIEROF_Dlf(), this.getDLF(), null, "dlf", null, 0, 1, modl.MIEROF.class, !IS_TRANSIENT,
				!IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED,
				IS_ORDERED);

		initEClass(industrialAutomationSystemEClass, IndustrialAutomationSystem.class, "IndustrialAutomationSystem",
				!IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getIndustrialAutomationSystem_Dlf(), this.getDLF(), null, "dlf", null, 0, 1,
				IndustrialAutomationSystem.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE,
				!IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(layerOperationsEClass, LayerOperations.class, "LayerOperations", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEReference(getLayerOperations_Layer(), this.getLayer(), null, "layer", null, 0, -1, LayerOperations.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(multiplicationEClass, Multiplication.class, "Multiplication", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(additionEClass, Addition.class, "Addition", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(concatenationEClass, Concatenation.class, "Concatenation", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(depthConcatenationEClass, DepthConcatenation.class, "DepthConcatenation", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(vgg16EClass, modl.VGG16.class, "VGG16", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(alexNetEClass, AlexNet.class, "AlexNet", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(inceptionEClass, Inception.class, "Inception", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getInception_Version(), ecorePackage.getEInt(), "version", null, 0, 1, Inception.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(resNet50EClass, ResNet50.class, "ResNet50", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(basicModelEClass, BasicModel.class, "BasicModel", IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getBasicModel_Trainable(), ecorePackage.getEBoolean(), "trainable", null, 0, 1, BasicModel.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getBasicModel_Include_top(), ecorePackage.getEBoolean(), "include_top", null, 0, 1,
				BasicModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);
		initEAttribute(getBasicModel_Weights_trained_on(), ecorePackage.getEString(), "weights_trained_on", null, 0, 1,
				BasicModel.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(efficientNetEClass, EfficientNet.class, "EfficientNet", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		initEClass(mobileNetEClass, MobileNet.class, "MobileNet", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getMobileNet_Version(), ecorePackage.getEInt(), "version", null, 0, 1, MobileNet.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(regNetEClass, RegNet.class, "RegNet", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);

		initEClass(denseNetEClass, DenseNet.class, "DenseNet", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);

		// Initialize enums and add enum literals
		initEEnum(poolingTypeEEnum, PoolingType.class, "PoolingType");
		addEEnumLiteral(poolingTypeEEnum, PoolingType.AVERAGE);
		addEEnumLiteral(poolingTypeEEnum, PoolingType.MAX);
		addEEnumLiteral(poolingTypeEEnum, PoolingType.GLOBAL_AVERAGE);

		initEEnum(activationTypeEEnum, ActivationType.class, "ActivationType");
		addEEnumLiteral(activationTypeEEnum, ActivationType.SIGMOID);
		addEEnumLiteral(activationTypeEEnum, ActivationType.RELU);
		addEEnumLiteral(activationTypeEEnum, ActivationType.LEAKY_RELU);
		addEEnumLiteral(activationTypeEEnum, ActivationType.SWISH);
		addEEnumLiteral(activationTypeEEnum, ActivationType.TANH);
		addEEnumLiteral(activationTypeEEnum, ActivationType.SOFTMAX);
		addEEnumLiteral(activationTypeEEnum, ActivationType.NULL);

		initEEnum(objectiveTypeEEnum, ObjectiveType.class, "ObjectiveType");
		addEEnumLiteral(objectiveTypeEEnum, ObjectiveType.MSE);
		addEEnumLiteral(objectiveTypeEEnum, ObjectiveType.MAE);
		addEEnumLiteral(objectiveTypeEEnum, ObjectiveType.BINARY_CROSSENTROPY);
		addEEnumLiteral(objectiveTypeEEnum, ObjectiveType.CATEGORICAL_CROSSENTROPY);
		addEEnumLiteral(objectiveTypeEEnum, ObjectiveType.CAT_CROSS_ENTROPY);

		initEEnum(metricTypeEEnum, MetricType.class, "MetricType");
		addEEnumLiteral(metricTypeEEnum, MetricType.ACCURACY);
		addEEnumLiteral(metricTypeEEnum, MetricType.AUC);
		addEEnumLiteral(metricTypeEEnum, MetricType.KL_DIVERGENCE);

		initEEnum(optimizerTypeEEnum, OptimizerType.class, "OptimizerType");
		addEEnumLiteral(optimizerTypeEEnum, OptimizerType.SGD);
		addEEnumLiteral(optimizerTypeEEnum, OptimizerType.ADAGRAD);
		addEEnumLiteral(optimizerTypeEEnum, OptimizerType.ADAM);
		addEEnumLiteral(optimizerTypeEEnum, OptimizerType.RM_SPROP);
		addEEnumLiteral(optimizerTypeEEnum, OptimizerType.ADA_DELTA);

		initEEnum(regulizerTypeEEnum, RegulizerType.class, "RegulizerType");
		addEEnumLiteral(regulizerTypeEEnum, RegulizerType.L1);
		addEEnumLiteral(regulizerTypeEEnum, RegulizerType.L2);
		addEEnumLiteral(regulizerTypeEEnum, RegulizerType.L1L2);
		addEEnumLiteral(regulizerTypeEEnum, RegulizerType.NULL);

		// Initialize data types
		initEDataType(imageArrayEDataType, Object.class, "ImageArray", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);
		initEDataType(labelArrayEDataType, Object.class, "LabelArray", IS_SERIALIZABLE, !IS_GENERATED_INSTANCE_CLASS);

		// Create resource
		createResource(eNS_URI);
	}

} //ModlPackageImpl
