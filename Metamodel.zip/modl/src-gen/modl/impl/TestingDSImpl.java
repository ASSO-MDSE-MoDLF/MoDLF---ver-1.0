/**
 */
package modl.impl;

import modl.ModlPackage;
import modl.TestingDS;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Testing DS</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.TestingDSImpl#getX_test <em>Xtest</em>}</li>
 *   <li>{@link modl.impl.TestingDSImpl#getY_test <em>Ytest</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TestingDSImpl extends DatasetImpl implements TestingDS {
	/**
	 * The cached value of the '{@link #getX_test() <em>Xtest</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX_test()
	 * @generated
	 * @ordered
	 */
	protected Object x_test;

	/**
	 * The cached value of the '{@link #getY_test() <em>Ytest</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY_test()
	 * @generated
	 * @ordered
	 */
	protected Object y_test;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TestingDSImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.TESTING_DS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getX_test() {
		return x_test;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setX_test(Object newX_test) {
		Object oldX_test = x_test;
		x_test = newX_test;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TESTING_DS__XTEST, oldX_test, x_test));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getY_test() {
		return y_test;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setY_test(Object newY_test) {
		Object oldY_test = y_test;
		y_test = newY_test;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TESTING_DS__YTEST, oldY_test, y_test));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.TESTING_DS__XTEST:
			return getX_test();
		case ModlPackage.TESTING_DS__YTEST:
			return getY_test();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.TESTING_DS__XTEST:
			setX_test(newValue);
			return;
		case ModlPackage.TESTING_DS__YTEST:
			setY_test(newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.TESTING_DS__XTEST:
			setX_test((Object) null);
			return;
		case ModlPackage.TESTING_DS__YTEST:
			setY_test((Object) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.TESTING_DS__XTEST:
			return x_test != null;
		case ModlPackage.TESTING_DS__YTEST:
			return y_test != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (x_test: ");
		result.append(x_test);
		result.append(", y_test: ");
		result.append(y_test);
		result.append(')');
		return result.toString();
	}

} //TestingDSImpl
