/**
 */
package modl.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import modl.ActivationType;
import modl.Layer;
import modl.LayerOperations;
import modl.ModlPackage;

import modl.RegulizerType;
import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Layer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.LayerImpl#getName <em>Name</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#getActivation <em>Activation</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#isBatch_normalization <em>Batch normalization</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#getLayer <em>Layer</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#getLayereOpposite <em>Layere Opposite</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#getRegularizer <em>Regularizer</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#getReg_rate <em>Reg rate</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#isDo_dropout <em>Do dropout</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#getDropout_rate <em>Dropout rate</em>}</li>
 *   <li>{@link modl.impl.LayerImpl#getLayeroperations <em>Layeroperations</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class LayerImpl extends MinimalEObjectImpl.Container implements Layer {
	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getActivation() <em>Activation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivation()
	 * @generated
	 * @ordered
	 */
	protected static final ActivationType ACTIVATION_EDEFAULT = ActivationType.SIGMOID;

	/**
	 * The cached value of the '{@link #getActivation() <em>Activation</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivation()
	 * @generated
	 * @ordered
	 */
	protected ActivationType activation = ACTIVATION_EDEFAULT;

	/**
	 * The default value of the '{@link #isBatch_normalization() <em>Batch normalization</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBatch_normalization()
	 * @generated
	 * @ordered
	 */
	protected static final boolean BATCH_NORMALIZATION_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isBatch_normalization() <em>Batch normalization</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isBatch_normalization()
	 * @generated
	 * @ordered
	 */
	protected boolean batch_normalization = BATCH_NORMALIZATION_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLayer() <em>Layer</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLayer()
	 * @generated
	 * @ordered
	 */
	protected EList<Layer> layer;

	/**
	 * The cached value of the '{@link #getLayereOpposite() <em>Layere Opposite</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLayereOpposite()
	 * @generated
	 * @ordered
	 */
	protected EList<Layer> layereOpposite;

	/**
	 * The default value of the '{@link #getRegularizer() <em>Regularizer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRegularizer()
	 * @generated
	 * @ordered
	 */
	protected static final RegulizerType REGULARIZER_EDEFAULT = RegulizerType.NULL;

	/**
	 * The cached value of the '{@link #getRegularizer() <em>Regularizer</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRegularizer()
	 * @generated
	 * @ordered
	 */
	protected RegulizerType regularizer = REGULARIZER_EDEFAULT;

	/**
	 * The default value of the '{@link #getReg_rate() <em>Reg rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReg_rate()
	 * @generated
	 * @ordered
	 */
	protected static final float REG_RATE_EDEFAULT = 0.001F;

	/**
	 * The cached value of the '{@link #getReg_rate() <em>Reg rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getReg_rate()
	 * @generated
	 * @ordered
	 */
	protected float reg_rate = REG_RATE_EDEFAULT;

	/**
	 * The default value of the '{@link #isDo_dropout() <em>Do dropout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDo_dropout()
	 * @generated
	 * @ordered
	 */
	protected static final boolean DO_DROPOUT_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isDo_dropout() <em>Do dropout</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isDo_dropout()
	 * @generated
	 * @ordered
	 */
	protected boolean do_dropout = DO_DROPOUT_EDEFAULT;

	/**
	 * The default value of the '{@link #getDropout_rate() <em>Dropout rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDropout_rate()
	 * @generated
	 * @ordered
	 */
	protected static final float DROPOUT_RATE_EDEFAULT = 0.01F;

	/**
	 * The cached value of the '{@link #getDropout_rate() <em>Dropout rate</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDropout_rate()
	 * @generated
	 * @ordered
	 */
	protected float dropout_rate = DROPOUT_RATE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLayeroperations() <em>Layeroperations</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLayeroperations()
	 * @generated
	 * @ordered
	 */
	protected EList<LayerOperations> layeroperations;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LayerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.LAYER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.LAYER__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public ActivationType getActivation() {
		return activation;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setActivation(ActivationType newActivation) {
		ActivationType oldActivation = activation;
		activation = newActivation == null ? ACTIVATION_EDEFAULT : newActivation;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.LAYER__ACTIVATION, oldActivation,
					activation));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isBatch_normalization() {
		return batch_normalization;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setBatch_normalization(boolean newBatch_normalization) {
		boolean oldBatch_normalization = batch_normalization;
		batch_normalization = newBatch_normalization;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.LAYER__BATCH_NORMALIZATION,
					oldBatch_normalization, batch_normalization));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Layer> getLayer() {
		if (layer == null) {
			layer = new EObjectWithInverseResolvingEList.ManyInverse<Layer>(Layer.class, this, ModlPackage.LAYER__LAYER,
					ModlPackage.LAYER__LAYERE_OPPOSITE);
		}
		return layer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Layer> getLayereOpposite() {
		if (layereOpposite == null) {
			layereOpposite = new EObjectWithInverseResolvingEList.ManyInverse<Layer>(Layer.class, this,
					ModlPackage.LAYER__LAYERE_OPPOSITE, ModlPackage.LAYER__LAYER);
		}
		return layereOpposite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<LayerOperations> getLayeroperations() {
		if (layeroperations == null) {
			layeroperations = new EObjectResolvingEList<LayerOperations>(LayerOperations.class, this,
					ModlPackage.LAYER__LAYEROPERATIONS);
		}
		return layeroperations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public RegulizerType getRegularizer() {
		return regularizer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setRegularizer(RegulizerType newRegularizer) {
		RegulizerType oldRegularizer = regularizer;
		regularizer = newRegularizer == null ? REGULARIZER_EDEFAULT : newRegularizer;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.LAYER__REGULARIZER, oldRegularizer,
					regularizer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getReg_rate() {
		return reg_rate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setReg_rate(float newReg_rate) {
		float oldReg_rate = reg_rate;
		reg_rate = newReg_rate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.LAYER__REG_RATE, oldReg_rate, reg_rate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isDo_dropout() {
		return do_dropout;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDo_dropout(boolean newDo_dropout) {
		boolean oldDo_dropout = do_dropout;
		do_dropout = newDo_dropout;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.LAYER__DO_DROPOUT, oldDo_dropout,
					do_dropout));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public float getDropout_rate() {
		return dropout_rate;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setDropout_rate(float newDropout_rate) {
		float oldDropout_rate = dropout_rate;
		dropout_rate = newDropout_rate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.LAYER__DROPOUT_RATE, oldDropout_rate,
					dropout_rate));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void activation_function() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.LAYER__LAYER:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getLayer()).basicAdd(otherEnd, msgs);
		case ModlPackage.LAYER__LAYERE_OPPOSITE:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getLayereOpposite()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.LAYER__LAYER:
			return ((InternalEList<?>) getLayer()).basicRemove(otherEnd, msgs);
		case ModlPackage.LAYER__LAYERE_OPPOSITE:
			return ((InternalEList<?>) getLayereOpposite()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.LAYER__NAME:
			return getName();
		case ModlPackage.LAYER__ACTIVATION:
			return getActivation();
		case ModlPackage.LAYER__BATCH_NORMALIZATION:
			return isBatch_normalization();
		case ModlPackage.LAYER__LAYER:
			return getLayer();
		case ModlPackage.LAYER__LAYERE_OPPOSITE:
			return getLayereOpposite();
		case ModlPackage.LAYER__REGULARIZER:
			return getRegularizer();
		case ModlPackage.LAYER__REG_RATE:
			return getReg_rate();
		case ModlPackage.LAYER__DO_DROPOUT:
			return isDo_dropout();
		case ModlPackage.LAYER__DROPOUT_RATE:
			return getDropout_rate();
		case ModlPackage.LAYER__LAYEROPERATIONS:
			return getLayeroperations();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.LAYER__NAME:
			setName((String) newValue);
			return;
		case ModlPackage.LAYER__ACTIVATION:
			setActivation((ActivationType) newValue);
			return;
		case ModlPackage.LAYER__BATCH_NORMALIZATION:
			setBatch_normalization((Boolean) newValue);
			return;
		case ModlPackage.LAYER__LAYER:
			getLayer().clear();
			getLayer().addAll((Collection<? extends Layer>) newValue);
			return;
		case ModlPackage.LAYER__LAYERE_OPPOSITE:
			getLayereOpposite().clear();
			getLayereOpposite().addAll((Collection<? extends Layer>) newValue);
			return;
		case ModlPackage.LAYER__REGULARIZER:
			setRegularizer((RegulizerType) newValue);
			return;
		case ModlPackage.LAYER__REG_RATE:
			setReg_rate((Float) newValue);
			return;
		case ModlPackage.LAYER__DO_DROPOUT:
			setDo_dropout((Boolean) newValue);
			return;
		case ModlPackage.LAYER__DROPOUT_RATE:
			setDropout_rate((Float) newValue);
			return;
		case ModlPackage.LAYER__LAYEROPERATIONS:
			getLayeroperations().clear();
			getLayeroperations().addAll((Collection<? extends LayerOperations>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.LAYER__NAME:
			setName(NAME_EDEFAULT);
			return;
		case ModlPackage.LAYER__ACTIVATION:
			setActivation(ACTIVATION_EDEFAULT);
			return;
		case ModlPackage.LAYER__BATCH_NORMALIZATION:
			setBatch_normalization(BATCH_NORMALIZATION_EDEFAULT);
			return;
		case ModlPackage.LAYER__LAYER:
			getLayer().clear();
			return;
		case ModlPackage.LAYER__LAYERE_OPPOSITE:
			getLayereOpposite().clear();
			return;
		case ModlPackage.LAYER__REGULARIZER:
			setRegularizer(REGULARIZER_EDEFAULT);
			return;
		case ModlPackage.LAYER__REG_RATE:
			setReg_rate(REG_RATE_EDEFAULT);
			return;
		case ModlPackage.LAYER__DO_DROPOUT:
			setDo_dropout(DO_DROPOUT_EDEFAULT);
			return;
		case ModlPackage.LAYER__DROPOUT_RATE:
			setDropout_rate(DROPOUT_RATE_EDEFAULT);
			return;
		case ModlPackage.LAYER__LAYEROPERATIONS:
			getLayeroperations().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.LAYER__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case ModlPackage.LAYER__ACTIVATION:
			return activation != ACTIVATION_EDEFAULT;
		case ModlPackage.LAYER__BATCH_NORMALIZATION:
			return batch_normalization != BATCH_NORMALIZATION_EDEFAULT;
		case ModlPackage.LAYER__LAYER:
			return layer != null && !layer.isEmpty();
		case ModlPackage.LAYER__LAYERE_OPPOSITE:
			return layereOpposite != null && !layereOpposite.isEmpty();
		case ModlPackage.LAYER__REGULARIZER:
			return regularizer != REGULARIZER_EDEFAULT;
		case ModlPackage.LAYER__REG_RATE:
			return reg_rate != REG_RATE_EDEFAULT;
		case ModlPackage.LAYER__DO_DROPOUT:
			return do_dropout != DO_DROPOUT_EDEFAULT;
		case ModlPackage.LAYER__DROPOUT_RATE:
			return dropout_rate != DROPOUT_RATE_EDEFAULT;
		case ModlPackage.LAYER__LAYEROPERATIONS:
			return layeroperations != null && !layeroperations.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case ModlPackage.LAYER___ACTIVATION_FUNCTION:
			activation_function();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", activation: ");
		result.append(activation);
		result.append(", batch_normalization: ");
		result.append(batch_normalization);
		result.append(", regularizer: ");
		result.append(regularizer);
		result.append(", reg_rate: ");
		result.append(reg_rate);
		result.append(", do_dropout: ");
		result.append(do_dropout);
		result.append(", dropout_rate: ");
		result.append(dropout_rate);
		result.append(')');
		return result.toString();
	}

} //LayerImpl
