/**
 */
package modl.impl;

import modl.Image;
import modl.InputLayer;
import modl.Label;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Image</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.ImageImpl#getLabel <em>Label</em>}</li>
 *   <li>{@link modl.impl.ImageImpl#getName <em>Name</em>}</li>
 *   <li>{@link modl.impl.ImageImpl#getFile_type <em>File type</em>}</li>
 *   <li>{@link modl.impl.ImageImpl#getImage_width <em>Image width</em>}</li>
 *   <li>{@link modl.impl.ImageImpl#getImage_height <em>Image height</em>}</li>
 *   <li>{@link modl.impl.ImageImpl#getImage_channels <em>Image channels</em>}</li>
 *   <li>{@link modl.impl.ImageImpl#getInputlayer <em>Inputlayer</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ImageImpl extends MinimalEObjectImpl.Container implements Image {
	/**
	 * The cached value of the '{@link #getLabel() <em>Label</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected Label label;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getFile_type() <em>File type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFile_type()
	 * @generated
	 * @ordered
	 */
	protected static final String FILE_TYPE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getFile_type() <em>File type</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getFile_type()
	 * @generated
	 * @ordered
	 */
	protected String file_type = FILE_TYPE_EDEFAULT;

	/**
	 * The default value of the '{@link #getImage_width() <em>Image width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage_width()
	 * @generated
	 * @ordered
	 */
	protected static final int IMAGE_WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getImage_width() <em>Image width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage_width()
	 * @generated
	 * @ordered
	 */
	protected int image_width = IMAGE_WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getImage_height() <em>Image height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage_height()
	 * @generated
	 * @ordered
	 */
	protected static final int IMAGE_HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getImage_height() <em>Image height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage_height()
	 * @generated
	 * @ordered
	 */
	protected int image_height = IMAGE_HEIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #getImage_channels() <em>Image channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage_channels()
	 * @generated
	 * @ordered
	 */
	protected static final int IMAGE_CHANNELS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getImage_channels() <em>Image channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage_channels()
	 * @generated
	 * @ordered
	 */
	protected int image_channels = IMAGE_CHANNELS_EDEFAULT;

	/**
	 * The cached value of the '{@link #getInputlayer() <em>Inputlayer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInputlayer()
	 * @generated
	 * @ordered
	 */
	protected InputLayer inputlayer;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ImageImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.IMAGE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Label getLabel() {
		if (label != null && label.eIsProxy()) {
			InternalEObject oldLabel = (InternalEObject) label;
			label = (Label) eResolveProxy(oldLabel);
			if (label != oldLabel) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModlPackage.IMAGE__LABEL, oldLabel,
							label));
			}
		}
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Label basicGetLabel() {
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLabel(Label newLabel, NotificationChain msgs) {
		Label oldLabel = label;
		label = newLabel;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__LABEL,
					oldLabel, newLabel);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setLabel(Label newLabel) {
		if (newLabel != label) {
			NotificationChain msgs = null;
			if (label != null)
				msgs = ((InternalEObject) label).eInverseRemove(this, ModlPackage.LABEL__IMAGE, Label.class, msgs);
			if (newLabel != null)
				msgs = ((InternalEObject) newLabel).eInverseAdd(this, ModlPackage.LABEL__IMAGE, Label.class, msgs);
			msgs = basicSetLabel(newLabel, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__LABEL, newLabel, newLabel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getFile_type() {
		return file_type;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFile_type(String newFile_type) {
		String oldFile_type = file_type;
		file_type = newFile_type;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__FILE_TYPE, oldFile_type,
					file_type));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getImage_width() {
		return image_width;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setImage_width(int newImage_width) {
		int oldImage_width = image_width;
		image_width = newImage_width;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__IMAGE_WIDTH, oldImage_width,
					image_width));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getImage_height() {
		return image_height;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setImage_height(int newImage_height) {
		int oldImage_height = image_height;
		image_height = newImage_height;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__IMAGE_HEIGHT, oldImage_height,
					image_height));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getImage_channels() {
		return image_channels;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setImage_channels(int newImage_channels) {
		int oldImage_channels = image_channels;
		image_channels = newImage_channels;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__IMAGE_CHANNELS, oldImage_channels,
					image_channels));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public InputLayer getInputlayer() {
		if (inputlayer != null && inputlayer.eIsProxy()) {
			InternalEObject oldInputlayer = (InternalEObject) inputlayer;
			inputlayer = (InputLayer) eResolveProxy(oldInputlayer);
			if (inputlayer != oldInputlayer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModlPackage.IMAGE__INPUTLAYER,
							oldInputlayer, inputlayer));
			}
		}
		return inputlayer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public InputLayer basicGetInputlayer() {
		return inputlayer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetInputlayer(InputLayer newInputlayer, NotificationChain msgs) {
		InputLayer oldInputlayer = inputlayer;
		inputlayer = newInputlayer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ModlPackage.IMAGE__INPUTLAYER, oldInputlayer, newInputlayer);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInputlayer(InputLayer newInputlayer) {
		if (newInputlayer != inputlayer) {
			NotificationChain msgs = null;
			if (inputlayer != null)
				msgs = ((InternalEObject) inputlayer).eInverseRemove(this, ModlPackage.INPUT_LAYER__IMAGE,
						InputLayer.class, msgs);
			if (newInputlayer != null)
				msgs = ((InternalEObject) newInputlayer).eInverseAdd(this, ModlPackage.INPUT_LAYER__IMAGE,
						InputLayer.class, msgs);
			msgs = basicSetInputlayer(newInputlayer, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.IMAGE__INPUTLAYER, newInputlayer,
					newInputlayer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.IMAGE__LABEL:
			if (label != null)
				msgs = ((InternalEObject) label).eInverseRemove(this, ModlPackage.LABEL__IMAGE, Label.class, msgs);
			return basicSetLabel((Label) otherEnd, msgs);
		case ModlPackage.IMAGE__INPUTLAYER:
			if (inputlayer != null)
				msgs = ((InternalEObject) inputlayer).eInverseRemove(this, ModlPackage.INPUT_LAYER__IMAGE,
						InputLayer.class, msgs);
			return basicSetInputlayer((InputLayer) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.IMAGE__LABEL:
			return basicSetLabel(null, msgs);
		case ModlPackage.IMAGE__INPUTLAYER:
			return basicSetInputlayer(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.IMAGE__LABEL:
			if (resolve)
				return getLabel();
			return basicGetLabel();
		case ModlPackage.IMAGE__NAME:
			return getName();
		case ModlPackage.IMAGE__FILE_TYPE:
			return getFile_type();
		case ModlPackage.IMAGE__IMAGE_WIDTH:
			return getImage_width();
		case ModlPackage.IMAGE__IMAGE_HEIGHT:
			return getImage_height();
		case ModlPackage.IMAGE__IMAGE_CHANNELS:
			return getImage_channels();
		case ModlPackage.IMAGE__INPUTLAYER:
			if (resolve)
				return getInputlayer();
			return basicGetInputlayer();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.IMAGE__LABEL:
			setLabel((Label) newValue);
			return;
		case ModlPackage.IMAGE__NAME:
			setName((String) newValue);
			return;
		case ModlPackage.IMAGE__FILE_TYPE:
			setFile_type((String) newValue);
			return;
		case ModlPackage.IMAGE__IMAGE_WIDTH:
			setImage_width((Integer) newValue);
			return;
		case ModlPackage.IMAGE__IMAGE_HEIGHT:
			setImage_height((Integer) newValue);
			return;
		case ModlPackage.IMAGE__IMAGE_CHANNELS:
			setImage_channels((Integer) newValue);
			return;
		case ModlPackage.IMAGE__INPUTLAYER:
			setInputlayer((InputLayer) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.IMAGE__LABEL:
			setLabel((Label) null);
			return;
		case ModlPackage.IMAGE__NAME:
			setName(NAME_EDEFAULT);
			return;
		case ModlPackage.IMAGE__FILE_TYPE:
			setFile_type(FILE_TYPE_EDEFAULT);
			return;
		case ModlPackage.IMAGE__IMAGE_WIDTH:
			setImage_width(IMAGE_WIDTH_EDEFAULT);
			return;
		case ModlPackage.IMAGE__IMAGE_HEIGHT:
			setImage_height(IMAGE_HEIGHT_EDEFAULT);
			return;
		case ModlPackage.IMAGE__IMAGE_CHANNELS:
			setImage_channels(IMAGE_CHANNELS_EDEFAULT);
			return;
		case ModlPackage.IMAGE__INPUTLAYER:
			setInputlayer((InputLayer) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.IMAGE__LABEL:
			return label != null;
		case ModlPackage.IMAGE__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case ModlPackage.IMAGE__FILE_TYPE:
			return FILE_TYPE_EDEFAULT == null ? file_type != null : !FILE_TYPE_EDEFAULT.equals(file_type);
		case ModlPackage.IMAGE__IMAGE_WIDTH:
			return image_width != IMAGE_WIDTH_EDEFAULT;
		case ModlPackage.IMAGE__IMAGE_HEIGHT:
			return image_height != IMAGE_HEIGHT_EDEFAULT;
		case ModlPackage.IMAGE__IMAGE_CHANNELS:
			return image_channels != IMAGE_CHANNELS_EDEFAULT;
		case ModlPackage.IMAGE__INPUTLAYER:
			return inputlayer != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(", file_type: ");
		result.append(file_type);
		result.append(", image_width: ");
		result.append(image_width);
		result.append(", image_height: ");
		result.append(image_height);
		result.append(", image_channels: ");
		result.append(image_channels);
		result.append(')');
		return result.toString();
	}

} //ImageImpl
