/**
 */
package modl.impl;

import java.lang.reflect.InvocationTargetException;

import modl.ConvLayer;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Conv Layer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.ConvLayerImpl#getKernel_width <em>Kernel width</em>}</li>
 *   <li>{@link modl.impl.ConvLayerImpl#getKernel_height <em>Kernel height</em>}</li>
 *   <li>{@link modl.impl.ConvLayerImpl#getStride <em>Stride</em>}</li>
 *   <li>{@link modl.impl.ConvLayerImpl#getPadding <em>Padding</em>}</li>
 *   <li>{@link modl.impl.ConvLayerImpl#getOutput_channels <em>Output channels</em>}</li>
 *   <li>{@link modl.impl.ConvLayerImpl#isFlatten <em>Flatten</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class ConvLayerImpl extends LayerImpl implements ConvLayer {
	/**
	 * The default value of the '{@link #getKernel_width() <em>Kernel width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKernel_width()
	 * @generated
	 * @ordered
	 */
	protected static final int KERNEL_WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getKernel_width() <em>Kernel width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKernel_width()
	 * @generated
	 * @ordered
	 */
	protected int kernel_width = KERNEL_WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getKernel_height() <em>Kernel height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKernel_height()
	 * @generated
	 * @ordered
	 */
	protected static final int KERNEL_HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getKernel_height() <em>Kernel height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getKernel_height()
	 * @generated
	 * @ordered
	 */
	protected int kernel_height = KERNEL_HEIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #getStride() <em>Stride</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStride()
	 * @generated
	 * @ordered
	 */
	protected static final int STRIDE_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getStride() <em>Stride</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getStride()
	 * @generated
	 * @ordered
	 */
	protected int stride = STRIDE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPadding() <em>Padding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPadding()
	 * @generated
	 * @ordered
	 */
	protected static final int PADDING_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getPadding() <em>Padding</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPadding()
	 * @generated
	 * @ordered
	 */
	protected int padding = PADDING_EDEFAULT;

	/**
	 * The default value of the '{@link #getOutput_channels() <em>Output channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutput_channels()
	 * @generated
	 * @ordered
	 */
	protected static final int OUTPUT_CHANNELS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getOutput_channels() <em>Output channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutput_channels()
	 * @generated
	 * @ordered
	 */
	protected int output_channels = OUTPUT_CHANNELS_EDEFAULT;

	/**
	 * The default value of the '{@link #isFlatten() <em>Flatten</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isFlatten()
	 * @generated
	 * @ordered
	 */
	protected static final boolean FLATTEN_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isFlatten() <em>Flatten</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isFlatten()
	 * @generated
	 * @ordered
	 */
	protected boolean flatten = FLATTEN_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConvLayerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.CONV_LAYER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getKernel_width() {
		return kernel_width;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setKernel_width(int newKernel_width) {
		int oldKernel_width = kernel_width;
		kernel_width = newKernel_width;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CONV_LAYER__KERNEL_WIDTH, oldKernel_width,
					kernel_width));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getKernel_height() {
		return kernel_height;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setKernel_height(int newKernel_height) {
		int oldKernel_height = kernel_height;
		kernel_height = newKernel_height;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CONV_LAYER__KERNEL_HEIGHT,
					oldKernel_height, kernel_height));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getStride() {
		return stride;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setStride(int newStride) {
		int oldStride = stride;
		stride = newStride;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CONV_LAYER__STRIDE, oldStride, stride));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getPadding() {
		return padding;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setPadding(int newPadding) {
		int oldPadding = padding;
		padding = newPadding;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CONV_LAYER__PADDING, oldPadding,
					padding));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getOutput_channels() {
		return output_channels;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setOutput_channels(int newOutput_channels) {
		int oldOutput_channels = output_channels;
		output_channels = newOutput_channels;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CONV_LAYER__OUTPUT_CHANNELS,
					oldOutput_channels, output_channels));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean isFlatten() {
		return flatten;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setFlatten(boolean newFlatten) {
		boolean oldFlatten = flatten;
		flatten = newFlatten;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CONV_LAYER__FLATTEN, oldFlatten,
					flatten));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void output_feature_map(int width, int height, int depth) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.CONV_LAYER__KERNEL_WIDTH:
			return getKernel_width();
		case ModlPackage.CONV_LAYER__KERNEL_HEIGHT:
			return getKernel_height();
		case ModlPackage.CONV_LAYER__STRIDE:
			return getStride();
		case ModlPackage.CONV_LAYER__PADDING:
			return getPadding();
		case ModlPackage.CONV_LAYER__OUTPUT_CHANNELS:
			return getOutput_channels();
		case ModlPackage.CONV_LAYER__FLATTEN:
			return isFlatten();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.CONV_LAYER__KERNEL_WIDTH:
			setKernel_width((Integer) newValue);
			return;
		case ModlPackage.CONV_LAYER__KERNEL_HEIGHT:
			setKernel_height((Integer) newValue);
			return;
		case ModlPackage.CONV_LAYER__STRIDE:
			setStride((Integer) newValue);
			return;
		case ModlPackage.CONV_LAYER__PADDING:
			setPadding((Integer) newValue);
			return;
		case ModlPackage.CONV_LAYER__OUTPUT_CHANNELS:
			setOutput_channels((Integer) newValue);
			return;
		case ModlPackage.CONV_LAYER__FLATTEN:
			setFlatten((Boolean) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.CONV_LAYER__KERNEL_WIDTH:
			setKernel_width(KERNEL_WIDTH_EDEFAULT);
			return;
		case ModlPackage.CONV_LAYER__KERNEL_HEIGHT:
			setKernel_height(KERNEL_HEIGHT_EDEFAULT);
			return;
		case ModlPackage.CONV_LAYER__STRIDE:
			setStride(STRIDE_EDEFAULT);
			return;
		case ModlPackage.CONV_LAYER__PADDING:
			setPadding(PADDING_EDEFAULT);
			return;
		case ModlPackage.CONV_LAYER__OUTPUT_CHANNELS:
			setOutput_channels(OUTPUT_CHANNELS_EDEFAULT);
			return;
		case ModlPackage.CONV_LAYER__FLATTEN:
			setFlatten(FLATTEN_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.CONV_LAYER__KERNEL_WIDTH:
			return kernel_width != KERNEL_WIDTH_EDEFAULT;
		case ModlPackage.CONV_LAYER__KERNEL_HEIGHT:
			return kernel_height != KERNEL_HEIGHT_EDEFAULT;
		case ModlPackage.CONV_LAYER__STRIDE:
			return stride != STRIDE_EDEFAULT;
		case ModlPackage.CONV_LAYER__PADDING:
			return padding != PADDING_EDEFAULT;
		case ModlPackage.CONV_LAYER__OUTPUT_CHANNELS:
			return output_channels != OUTPUT_CHANNELS_EDEFAULT;
		case ModlPackage.CONV_LAYER__FLATTEN:
			return flatten != FLATTEN_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case ModlPackage.CONV_LAYER___OUTPUT_FEATURE_MAP__INT_INT_INT:
			output_feature_map((Integer) arguments.get(0), (Integer) arguments.get(1), (Integer) arguments.get(2));
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (kernel_width: ");
		result.append(kernel_width);
		result.append(", kernel_height: ");
		result.append(kernel_height);
		result.append(", stride: ");
		result.append(stride);
		result.append(", padding: ");
		result.append(padding);
		result.append(", output_channels: ");
		result.append(output_channels);
		result.append(", flatten: ");
		result.append(flatten);
		result.append(')');
		return result.toString();
	}

} //ConvLayerImpl
