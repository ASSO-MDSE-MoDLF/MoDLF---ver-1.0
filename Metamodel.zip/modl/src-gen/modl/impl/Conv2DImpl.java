/**
 */
package modl.impl;

import modl.Conv2D;
import modl.ModlPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Conv2 D</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class Conv2DImpl extends ConvLayerImpl implements Conv2D {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Conv2DImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.CONV2_D;
	}

} //Conv2DImpl
