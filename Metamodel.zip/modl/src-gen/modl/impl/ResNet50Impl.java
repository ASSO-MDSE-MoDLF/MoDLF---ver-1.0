/**
 */
package modl.impl;

import modl.ModlPackage;
import modl.ResNet50;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Res Net50</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ResNet50Impl extends BasicModelImpl implements ResNet50 {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ResNet50Impl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.RES_NET50;
	}

} //ResNet50Impl
