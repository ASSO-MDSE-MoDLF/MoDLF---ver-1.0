/**
 */
package modl.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import modl.Image;
import modl.InputLayer;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Input Layer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.InputLayerImpl#getInput_width <em>Input width</em>}</li>
 *   <li>{@link modl.impl.InputLayerImpl#getInput_height <em>Input height</em>}</li>
 *   <li>{@link modl.impl.InputLayerImpl#getInput_channels <em>Input channels</em>}</li>
 *   <li>{@link modl.impl.InputLayerImpl#getArray_of_classes <em>Array of classes</em>}</li>
 *   <li>{@link modl.impl.InputLayerImpl#getImage <em>Image</em>}</li>
 * </ul>
 *
 * @generated
 */
public class InputLayerImpl extends LayerImpl implements InputLayer {
	/**
	 * The default value of the '{@link #getInput_width() <em>Input width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInput_width()
	 * @generated
	 * @ordered
	 */
	protected static final int INPUT_WIDTH_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getInput_width() <em>Input width</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInput_width()
	 * @generated
	 * @ordered
	 */
	protected int input_width = INPUT_WIDTH_EDEFAULT;

	/**
	 * The default value of the '{@link #getInput_height() <em>Input height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInput_height()
	 * @generated
	 * @ordered
	 */
	protected static final int INPUT_HEIGHT_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getInput_height() <em>Input height</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInput_height()
	 * @generated
	 * @ordered
	 */
	protected int input_height = INPUT_HEIGHT_EDEFAULT;

	/**
	 * The default value of the '{@link #getInput_channels() <em>Input channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInput_channels()
	 * @generated
	 * @ordered
	 */
	protected static final int INPUT_CHANNELS_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getInput_channels() <em>Input channels</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getInput_channels()
	 * @generated
	 * @ordered
	 */
	protected int input_channels = INPUT_CHANNELS_EDEFAULT;

	/**
	 * The default value of the '{@link #getArray_of_classes() <em>Array of classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArray_of_classes()
	 * @generated
	 * @ordered
	 */
	protected static final String ARRAY_OF_CLASSES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getArray_of_classes() <em>Array of classes</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getArray_of_classes()
	 * @generated
	 * @ordered
	 */
	protected String array_of_classes = ARRAY_OF_CLASSES_EDEFAULT;

	/**
	 * The cached value of the '{@link #getImage() <em>Image</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage()
	 * @generated
	 * @ordered
	 */
	protected EList<Image> image;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InputLayerImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.INPUT_LAYER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getInput_width() {
		return input_width;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInput_width(int newInput_width) {
		int oldInput_width = input_width;
		input_width = newInput_width;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.INPUT_LAYER__INPUT_WIDTH, oldInput_width,
					input_width));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getInput_height() {
		return input_height;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInput_height(int newInput_height) {
		int oldInput_height = input_height;
		input_height = newInput_height;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.INPUT_LAYER__INPUT_HEIGHT,
					oldInput_height, input_height));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getInput_channels() {
		return input_channels;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setInput_channels(int newInput_channels) {
		int oldInput_channels = input_channels;
		input_channels = newInput_channels;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.INPUT_LAYER__INPUT_CHANNELS,
					oldInput_channels, input_channels));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getArray_of_classes() {
		return array_of_classes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setArray_of_classes(String newArray_of_classes) {
		String oldArray_of_classes = array_of_classes;
		array_of_classes = newArray_of_classes;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.INPUT_LAYER__ARRAY_OF_CLASSES,
					oldArray_of_classes, array_of_classes));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Image> getImage() {
		if (image == null) {
			image = new EObjectWithInverseResolvingEList<Image>(Image.class, this, ModlPackage.INPUT_LAYER__IMAGE,
					ModlPackage.IMAGE__INPUTLAYER);
		}
		return image;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void reshape(double scale_factor) {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.INPUT_LAYER__IMAGE:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getImage()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.INPUT_LAYER__IMAGE:
			return ((InternalEList<?>) getImage()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.INPUT_LAYER__INPUT_WIDTH:
			return getInput_width();
		case ModlPackage.INPUT_LAYER__INPUT_HEIGHT:
			return getInput_height();
		case ModlPackage.INPUT_LAYER__INPUT_CHANNELS:
			return getInput_channels();
		case ModlPackage.INPUT_LAYER__ARRAY_OF_CLASSES:
			return getArray_of_classes();
		case ModlPackage.INPUT_LAYER__IMAGE:
			return getImage();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.INPUT_LAYER__INPUT_WIDTH:
			setInput_width((Integer) newValue);
			return;
		case ModlPackage.INPUT_LAYER__INPUT_HEIGHT:
			setInput_height((Integer) newValue);
			return;
		case ModlPackage.INPUT_LAYER__INPUT_CHANNELS:
			setInput_channels((Integer) newValue);
			return;
		case ModlPackage.INPUT_LAYER__ARRAY_OF_CLASSES:
			setArray_of_classes((String) newValue);
			return;
		case ModlPackage.INPUT_LAYER__IMAGE:
			getImage().clear();
			getImage().addAll((Collection<? extends Image>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.INPUT_LAYER__INPUT_WIDTH:
			setInput_width(INPUT_WIDTH_EDEFAULT);
			return;
		case ModlPackage.INPUT_LAYER__INPUT_HEIGHT:
			setInput_height(INPUT_HEIGHT_EDEFAULT);
			return;
		case ModlPackage.INPUT_LAYER__INPUT_CHANNELS:
			setInput_channels(INPUT_CHANNELS_EDEFAULT);
			return;
		case ModlPackage.INPUT_LAYER__ARRAY_OF_CLASSES:
			setArray_of_classes(ARRAY_OF_CLASSES_EDEFAULT);
			return;
		case ModlPackage.INPUT_LAYER__IMAGE:
			getImage().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.INPUT_LAYER__INPUT_WIDTH:
			return input_width != INPUT_WIDTH_EDEFAULT;
		case ModlPackage.INPUT_LAYER__INPUT_HEIGHT:
			return input_height != INPUT_HEIGHT_EDEFAULT;
		case ModlPackage.INPUT_LAYER__INPUT_CHANNELS:
			return input_channels != INPUT_CHANNELS_EDEFAULT;
		case ModlPackage.INPUT_LAYER__ARRAY_OF_CLASSES:
			return ARRAY_OF_CLASSES_EDEFAULT == null ? array_of_classes != null
					: !ARRAY_OF_CLASSES_EDEFAULT.equals(array_of_classes);
		case ModlPackage.INPUT_LAYER__IMAGE:
			return image != null && !image.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case ModlPackage.INPUT_LAYER___RESHAPE__DOUBLE:
			reshape((Double) arguments.get(0));
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (input_width: ");
		result.append(input_width);
		result.append(", input_height: ");
		result.append(input_height);
		result.append(", input_channels: ");
		result.append(input_channels);
		result.append(", array_of_classes: ");
		result.append(array_of_classes);
		result.append(')');
		return result.toString();
	}

} //InputLayerImpl
