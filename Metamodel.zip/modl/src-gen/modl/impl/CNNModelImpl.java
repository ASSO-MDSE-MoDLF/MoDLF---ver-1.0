/**
 */
package modl.impl;

import java.lang.reflect.InvocationTargetException;

import java.util.Collection;

import modl.CNNModel;
import modl.Dataset;
import modl.Layer;
import modl.LayerOperations;
import modl.ModlPackage;
import modl.Parameters;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>CNN Model</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.CNNModelImpl#getDataset <em>Dataset</em>}</li>
 *   <li>{@link modl.impl.CNNModelImpl#getName <em>Name</em>}</li>
 *   <li>{@link modl.impl.CNNModelImpl#getLayer <em>Layer</em>}</li>
 *   <li>{@link modl.impl.CNNModelImpl#getCnnmodel <em>Cnnmodel</em>}</li>
 *   <li>{@link modl.impl.CNNModelImpl#getCnnmodeleOpposite <em>Cnnmodele Opposite</em>}</li>
 *   <li>{@link modl.impl.CNNModelImpl#getParameters <em>Parameters</em>}</li>
 *   <li>{@link modl.impl.CNNModelImpl#getLayeroperations <em>Layeroperations</em>}</li>
 * </ul>
 *
 * @generated
 */
public class CNNModelImpl extends MinimalEObjectImpl.Container implements CNNModel {
	/**
	 * The cached value of the '{@link #getDataset() <em>Dataset</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataset()
	 * @generated
	 * @ordered
	 */
	protected EList<Dataset> dataset;

	/**
	 * The default value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected static final String NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getName() <em>Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getName()
	 * @generated
	 * @ordered
	 */
	protected String name = NAME_EDEFAULT;

	/**
	 * The cached value of the '{@link #getLayer() <em>Layer</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLayer()
	 * @generated
	 * @ordered
	 */
	protected EList<Layer> layer;

	/**
	 * The cached value of the '{@link #getCnnmodel() <em>Cnnmodel</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCnnmodel()
	 * @generated
	 * @ordered
	 */
	protected CNNModel cnnmodel;

	/**
	 * The cached value of the '{@link #getCnnmodeleOpposite() <em>Cnnmodele Opposite</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCnnmodeleOpposite()
	 * @generated
	 * @ordered
	 */
	protected CNNModel cnnmodeleOpposite;

	/**
	 * The cached value of the '{@link #getParameters() <em>Parameters</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getParameters()
	 * @generated
	 * @ordered
	 */
	protected EList<Parameters> parameters;

	/**
	 * The cached value of the '{@link #getLayeroperations() <em>Layeroperations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLayeroperations()
	 * @generated
	 * @ordered
	 */
	protected EList<LayerOperations> layeroperations;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected CNNModelImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.CNN_MODEL;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Dataset> getDataset() {
		if (dataset == null) {
			dataset = new EObjectWithInverseResolvingEList.ManyInverse<Dataset>(Dataset.class, this,
					ModlPackage.CNN_MODEL__DATASET, ModlPackage.DATASET__CNNMODEL);
		}
		return dataset;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setName(String newName) {
		String oldName = name;
		name = newName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CNN_MODEL__NAME, oldName, name));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Layer> getLayer() {
		if (layer == null) {
			layer = new EObjectContainmentEList<Layer>(Layer.class, this, ModlPackage.CNN_MODEL__LAYER);
		}
		return layer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CNNModel getCnnmodel() {
		if (cnnmodel != null && cnnmodel.eIsProxy()) {
			InternalEObject oldCnnmodel = (InternalEObject) cnnmodel;
			cnnmodel = (CNNModel) eResolveProxy(oldCnnmodel);
			if (cnnmodel != oldCnnmodel) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModlPackage.CNN_MODEL__CNNMODEL,
							oldCnnmodel, cnnmodel));
			}
		}
		return cnnmodel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CNNModel basicGetCnnmodel() {
		return cnnmodel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCnnmodel(CNNModel newCnnmodel, NotificationChain msgs) {
		CNNModel oldCnnmodel = cnnmodel;
		cnnmodel = newCnnmodel;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ModlPackage.CNN_MODEL__CNNMODEL, oldCnnmodel, newCnnmodel);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCnnmodel(CNNModel newCnnmodel) {
		if (newCnnmodel != cnnmodel) {
			NotificationChain msgs = null;
			if (cnnmodel != null)
				msgs = ((InternalEObject) cnnmodel).eInverseRemove(this, ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE,
						CNNModel.class, msgs);
			if (newCnnmodel != null)
				msgs = ((InternalEObject) newCnnmodel).eInverseAdd(this, ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE,
						CNNModel.class, msgs);
			msgs = basicSetCnnmodel(newCnnmodel, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CNN_MODEL__CNNMODEL, newCnnmodel,
					newCnnmodel));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public CNNModel getCnnmodeleOpposite() {
		if (cnnmodeleOpposite != null && cnnmodeleOpposite.eIsProxy()) {
			InternalEObject oldCnnmodeleOpposite = (InternalEObject) cnnmodeleOpposite;
			cnnmodeleOpposite = (CNNModel) eResolveProxy(oldCnnmodeleOpposite);
			if (cnnmodeleOpposite != oldCnnmodeleOpposite) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE,
							oldCnnmodeleOpposite, cnnmodeleOpposite));
			}
		}
		return cnnmodeleOpposite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public CNNModel basicGetCnnmodeleOpposite() {
		return cnnmodeleOpposite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCnnmodeleOpposite(CNNModel newCnnmodeleOpposite, NotificationChain msgs) {
		CNNModel oldCnnmodeleOpposite = cnnmodeleOpposite;
		cnnmodeleOpposite = newCnnmodeleOpposite;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE, oldCnnmodeleOpposite, newCnnmodeleOpposite);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setCnnmodeleOpposite(CNNModel newCnnmodeleOpposite) {
		if (newCnnmodeleOpposite != cnnmodeleOpposite) {
			NotificationChain msgs = null;
			if (cnnmodeleOpposite != null)
				msgs = ((InternalEObject) cnnmodeleOpposite).eInverseRemove(this, ModlPackage.CNN_MODEL__CNNMODEL,
						CNNModel.class, msgs);
			if (newCnnmodeleOpposite != null)
				msgs = ((InternalEObject) newCnnmodeleOpposite).eInverseAdd(this, ModlPackage.CNN_MODEL__CNNMODEL,
						CNNModel.class, msgs);
			msgs = basicSetCnnmodeleOpposite(newCnnmodeleOpposite, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE,
					newCnnmodeleOpposite, newCnnmodeleOpposite));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Parameters> getParameters() {
		if (parameters == null) {
			parameters = new EObjectContainmentEList<Parameters>(Parameters.class, this,
					ModlPackage.CNN_MODEL__PARAMETERS);
		}
		return parameters;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<LayerOperations> getLayeroperations() {
		if (layeroperations == null) {
			layeroperations = new EObjectContainmentEList<LayerOperations>(LayerOperations.class, this,
					ModlPackage.CNN_MODEL__LAYEROPERATIONS);
		}
		return layeroperations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void compile_model() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void layers() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void params() {
		// TODO: implement this method
		// Ensure that you remove @generated or mark it @generated NOT
		throw new UnsupportedOperationException();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.CNN_MODEL__DATASET:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getDataset()).basicAdd(otherEnd, msgs);
		case ModlPackage.CNN_MODEL__CNNMODEL:
			if (cnnmodel != null)
				msgs = ((InternalEObject) cnnmodel).eInverseRemove(this, ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE,
						CNNModel.class, msgs);
			return basicSetCnnmodel((CNNModel) otherEnd, msgs);
		case ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE:
			if (cnnmodeleOpposite != null)
				msgs = ((InternalEObject) cnnmodeleOpposite).eInverseRemove(this, ModlPackage.CNN_MODEL__CNNMODEL,
						CNNModel.class, msgs);
			return basicSetCnnmodeleOpposite((CNNModel) otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.CNN_MODEL__DATASET:
			return ((InternalEList<?>) getDataset()).basicRemove(otherEnd, msgs);
		case ModlPackage.CNN_MODEL__LAYER:
			return ((InternalEList<?>) getLayer()).basicRemove(otherEnd, msgs);
		case ModlPackage.CNN_MODEL__CNNMODEL:
			return basicSetCnnmodel(null, msgs);
		case ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE:
			return basicSetCnnmodeleOpposite(null, msgs);
		case ModlPackage.CNN_MODEL__PARAMETERS:
			return ((InternalEList<?>) getParameters()).basicRemove(otherEnd, msgs);
		case ModlPackage.CNN_MODEL__LAYEROPERATIONS:
			return ((InternalEList<?>) getLayeroperations()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.CNN_MODEL__DATASET:
			return getDataset();
		case ModlPackage.CNN_MODEL__NAME:
			return getName();
		case ModlPackage.CNN_MODEL__LAYER:
			return getLayer();
		case ModlPackage.CNN_MODEL__CNNMODEL:
			if (resolve)
				return getCnnmodel();
			return basicGetCnnmodel();
		case ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE:
			if (resolve)
				return getCnnmodeleOpposite();
			return basicGetCnnmodeleOpposite();
		case ModlPackage.CNN_MODEL__PARAMETERS:
			return getParameters();
		case ModlPackage.CNN_MODEL__LAYEROPERATIONS:
			return getLayeroperations();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.CNN_MODEL__DATASET:
			getDataset().clear();
			getDataset().addAll((Collection<? extends Dataset>) newValue);
			return;
		case ModlPackage.CNN_MODEL__NAME:
			setName((String) newValue);
			return;
		case ModlPackage.CNN_MODEL__LAYER:
			getLayer().clear();
			getLayer().addAll((Collection<? extends Layer>) newValue);
			return;
		case ModlPackage.CNN_MODEL__CNNMODEL:
			setCnnmodel((CNNModel) newValue);
			return;
		case ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE:
			setCnnmodeleOpposite((CNNModel) newValue);
			return;
		case ModlPackage.CNN_MODEL__PARAMETERS:
			getParameters().clear();
			getParameters().addAll((Collection<? extends Parameters>) newValue);
			return;
		case ModlPackage.CNN_MODEL__LAYEROPERATIONS:
			getLayeroperations().clear();
			getLayeroperations().addAll((Collection<? extends LayerOperations>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.CNN_MODEL__DATASET:
			getDataset().clear();
			return;
		case ModlPackage.CNN_MODEL__NAME:
			setName(NAME_EDEFAULT);
			return;
		case ModlPackage.CNN_MODEL__LAYER:
			getLayer().clear();
			return;
		case ModlPackage.CNN_MODEL__CNNMODEL:
			setCnnmodel((CNNModel) null);
			return;
		case ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE:
			setCnnmodeleOpposite((CNNModel) null);
			return;
		case ModlPackage.CNN_MODEL__PARAMETERS:
			getParameters().clear();
			return;
		case ModlPackage.CNN_MODEL__LAYEROPERATIONS:
			getLayeroperations().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.CNN_MODEL__DATASET:
			return dataset != null && !dataset.isEmpty();
		case ModlPackage.CNN_MODEL__NAME:
			return NAME_EDEFAULT == null ? name != null : !NAME_EDEFAULT.equals(name);
		case ModlPackage.CNN_MODEL__LAYER:
			return layer != null && !layer.isEmpty();
		case ModlPackage.CNN_MODEL__CNNMODEL:
			return cnnmodel != null;
		case ModlPackage.CNN_MODEL__CNNMODELE_OPPOSITE:
			return cnnmodeleOpposite != null;
		case ModlPackage.CNN_MODEL__PARAMETERS:
			return parameters != null && !parameters.isEmpty();
		case ModlPackage.CNN_MODEL__LAYEROPERATIONS:
			return layeroperations != null && !layeroperations.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eInvoke(int operationID, EList<?> arguments) throws InvocationTargetException {
		switch (operationID) {
		case ModlPackage.CNN_MODEL___COMPILE_MODEL:
			compile_model();
			return null;
		case ModlPackage.CNN_MODEL___LAYERS:
			layers();
			return null;
		case ModlPackage.CNN_MODEL___PARAMS:
			params();
			return null;
		}
		return super.eInvoke(operationID, arguments);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (name: ");
		result.append(name);
		result.append(')');
		return result.toString();
	}

} //CNNModelImpl
