/**
 */
package modl.impl;

import java.util.Collection;

import modl.CNNModel;
import modl.Dataset;
import modl.Image;
import modl.Label;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dataset</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.DatasetImpl#getQual_path <em>Qual path</em>}</li>
 *   <li>{@link modl.impl.DatasetImpl#getImage <em>Image</em>}</li>
 *   <li>{@link modl.impl.DatasetImpl#getLabel <em>Label</em>}</li>
 *   <li>{@link modl.impl.DatasetImpl#getCnnmodel <em>Cnnmodel</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class DatasetImpl extends MinimalEObjectImpl.Container implements Dataset {
	/**
	 * The default value of the '{@link #getQual_path() <em>Qual path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQual_path()
	 * @generated
	 * @ordered
	 */
	protected static final String QUAL_PATH_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getQual_path() <em>Qual path</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQual_path()
	 * @generated
	 * @ordered
	 */
	protected String qual_path = QUAL_PATH_EDEFAULT;

	/**
	 * The cached value of the '{@link #getImage() <em>Image</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getImage()
	 * @generated
	 * @ordered
	 */
	protected EList<Image> image;

	/**
	 * The cached value of the '{@link #getLabel() <em>Label</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLabel()
	 * @generated
	 * @ordered
	 */
	protected EList<Label> label;

	/**
	 * The cached value of the '{@link #getCnnmodel() <em>Cnnmodel</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCnnmodel()
	 * @generated
	 * @ordered
	 */
	protected EList<CNNModel> cnnmodel;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DatasetImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.DATASET;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getQual_path() {
		return qual_path;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setQual_path(String newQual_path) {
		String oldQual_path = qual_path;
		qual_path = newQual_path;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.DATASET__QUAL_PATH, oldQual_path,
					qual_path));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Image> getImage() {
		if (image == null) {
			image = new EObjectContainmentEList<Image>(Image.class, this, ModlPackage.DATASET__IMAGE);
		}
		return image;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Label> getLabel() {
		if (label == null) {
			label = new EObjectContainmentEList<Label>(Label.class, this, ModlPackage.DATASET__LABEL);
		}
		return label;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CNNModel> getCnnmodel() {
		if (cnnmodel == null) {
			cnnmodel = new EObjectWithInverseResolvingEList.ManyInverse<CNNModel>(CNNModel.class, this,
					ModlPackage.DATASET__CNNMODEL, ModlPackage.CNN_MODEL__DATASET);
		}
		return cnnmodel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.DATASET__CNNMODEL:
			return ((InternalEList<InternalEObject>) (InternalEList<?>) getCnnmodel()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.DATASET__IMAGE:
			return ((InternalEList<?>) getImage()).basicRemove(otherEnd, msgs);
		case ModlPackage.DATASET__LABEL:
			return ((InternalEList<?>) getLabel()).basicRemove(otherEnd, msgs);
		case ModlPackage.DATASET__CNNMODEL:
			return ((InternalEList<?>) getCnnmodel()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.DATASET__QUAL_PATH:
			return getQual_path();
		case ModlPackage.DATASET__IMAGE:
			return getImage();
		case ModlPackage.DATASET__LABEL:
			return getLabel();
		case ModlPackage.DATASET__CNNMODEL:
			return getCnnmodel();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.DATASET__QUAL_PATH:
			setQual_path((String) newValue);
			return;
		case ModlPackage.DATASET__IMAGE:
			getImage().clear();
			getImage().addAll((Collection<? extends Image>) newValue);
			return;
		case ModlPackage.DATASET__LABEL:
			getLabel().clear();
			getLabel().addAll((Collection<? extends Label>) newValue);
			return;
		case ModlPackage.DATASET__CNNMODEL:
			getCnnmodel().clear();
			getCnnmodel().addAll((Collection<? extends CNNModel>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.DATASET__QUAL_PATH:
			setQual_path(QUAL_PATH_EDEFAULT);
			return;
		case ModlPackage.DATASET__IMAGE:
			getImage().clear();
			return;
		case ModlPackage.DATASET__LABEL:
			getLabel().clear();
			return;
		case ModlPackage.DATASET__CNNMODEL:
			getCnnmodel().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.DATASET__QUAL_PATH:
			return QUAL_PATH_EDEFAULT == null ? qual_path != null : !QUAL_PATH_EDEFAULT.equals(qual_path);
		case ModlPackage.DATASET__IMAGE:
			return image != null && !image.isEmpty();
		case ModlPackage.DATASET__LABEL:
			return label != null && !label.isEmpty();
		case ModlPackage.DATASET__CNNMODEL:
			return cnnmodel != null && !cnnmodel.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (qual_path: ");
		result.append(qual_path);
		result.append(')');
		return result.toString();
	}

} //DatasetImpl
