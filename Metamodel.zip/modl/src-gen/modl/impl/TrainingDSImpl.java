/**
 */
package modl.impl;

import modl.ModlPackage;
import modl.TrainingDS;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Training DS</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.TrainingDSImpl#getX_train <em>Xtrain</em>}</li>
 *   <li>{@link modl.impl.TrainingDSImpl#getY_train <em>Ytrain</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TrainingDSImpl extends DatasetImpl implements TrainingDS {
	/**
	 * The cached value of the '{@link #getX_train() <em>Xtrain</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getX_train()
	 * @generated
	 * @ordered
	 */
	protected Object x_train;

	/**
	 * The cached value of the '{@link #getY_train() <em>Ytrain</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getY_train()
	 * @generated
	 * @ordered
	 */
	protected Object y_train;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TrainingDSImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.TRAINING_DS;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getX_train() {
		return x_train;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setX_train(Object newX_train) {
		Object oldX_train = x_train;
		x_train = newX_train;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_DS__XTRAIN, oldX_train,
					x_train));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object getY_train() {
		return y_train;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void setY_train(Object newY_train) {
		Object oldY_train = y_train;
		y_train = newY_train;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ModlPackage.TRAINING_DS__YTRAIN, oldY_train,
					y_train));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.TRAINING_DS__XTRAIN:
			return getX_train();
		case ModlPackage.TRAINING_DS__YTRAIN:
			return getY_train();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.TRAINING_DS__XTRAIN:
			setX_train(newValue);
			return;
		case ModlPackage.TRAINING_DS__YTRAIN:
			setY_train(newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.TRAINING_DS__XTRAIN:
			setX_train((Object) null);
			return;
		case ModlPackage.TRAINING_DS__YTRAIN:
			setY_train((Object) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.TRAINING_DS__XTRAIN:
			return x_train != null;
		case ModlPackage.TRAINING_DS__YTRAIN:
			return y_train != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (x_train: ");
		result.append(x_train);
		result.append(", y_train: ");
		result.append(y_train);
		result.append(')');
		return result.toString();
	}

} //TrainingDSImpl
