/**
 */
package modl.impl;

import java.util.Collection;

import modl.BasicModel;
import modl.CNNModel;
import modl.DLF;
import modl.Dataset;
import modl.ModlPackage;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>DLF</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link modl.impl.DLFImpl#getDataset <em>Dataset</em>}</li>
 *   <li>{@link modl.impl.DLFImpl#getCnnmodel <em>Cnnmodel</em>}</li>
 *   <li>{@link modl.impl.DLFImpl#getBasicmodel <em>Basicmodel</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DLFImpl extends MinimalEObjectImpl.Container implements DLF {
	/**
	 * The cached value of the '{@link #getDataset() <em>Dataset</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDataset()
	 * @generated
	 * @ordered
	 */
	protected EList<Dataset> dataset;

	/**
	 * The cached value of the '{@link #getCnnmodel() <em>Cnnmodel</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCnnmodel()
	 * @generated
	 * @ordered
	 */
	protected EList<CNNModel> cnnmodel;

	/**
	 * The cached value of the '{@link #getBasicmodel() <em>Basicmodel</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBasicmodel()
	 * @generated
	 * @ordered
	 */
	protected EList<BasicModel> basicmodel;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DLFImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ModlPackage.Literals.DLF;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<Dataset> getDataset() {
		if (dataset == null) {
			dataset = new EObjectContainmentEList<Dataset>(Dataset.class, this, ModlPackage.DLF__DATASET);
		}
		return dataset;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<CNNModel> getCnnmodel() {
		if (cnnmodel == null) {
			cnnmodel = new EObjectContainmentEList<CNNModel>(CNNModel.class, this, ModlPackage.DLF__CNNMODEL);
		}
		return cnnmodel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public EList<BasicModel> getBasicmodel() {
		if (basicmodel == null) {
			basicmodel = new EObjectContainmentEList<BasicModel>(BasicModel.class, this, ModlPackage.DLF__BASICMODEL);
		}
		return basicmodel;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case ModlPackage.DLF__DATASET:
			return ((InternalEList<?>) getDataset()).basicRemove(otherEnd, msgs);
		case ModlPackage.DLF__CNNMODEL:
			return ((InternalEList<?>) getCnnmodel()).basicRemove(otherEnd, msgs);
		case ModlPackage.DLF__BASICMODEL:
			return ((InternalEList<?>) getBasicmodel()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ModlPackage.DLF__DATASET:
			return getDataset();
		case ModlPackage.DLF__CNNMODEL:
			return getCnnmodel();
		case ModlPackage.DLF__BASICMODEL:
			return getBasicmodel();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ModlPackage.DLF__DATASET:
			getDataset().clear();
			getDataset().addAll((Collection<? extends Dataset>) newValue);
			return;
		case ModlPackage.DLF__CNNMODEL:
			getCnnmodel().clear();
			getCnnmodel().addAll((Collection<? extends CNNModel>) newValue);
			return;
		case ModlPackage.DLF__BASICMODEL:
			getBasicmodel().clear();
			getBasicmodel().addAll((Collection<? extends BasicModel>) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ModlPackage.DLF__DATASET:
			getDataset().clear();
			return;
		case ModlPackage.DLF__CNNMODEL:
			getCnnmodel().clear();
			return;
		case ModlPackage.DLF__BASICMODEL:
			getBasicmodel().clear();
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ModlPackage.DLF__DATASET:
			return dataset != null && !dataset.isEmpty();
		case ModlPackage.DLF__CNNMODEL:
			return cnnmodel != null && !cnnmodel.isEmpty();
		case ModlPackage.DLF__BASICMODEL:
			return basicmodel != null && !basicmodel.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //DLFImpl
