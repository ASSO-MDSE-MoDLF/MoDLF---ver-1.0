/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Dense</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Dense#getOutput_features <em>Output features</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getDense()
 * @model
 * @generated
 */
public interface Dense extends LinearLayer {
	/**
	 * Returns the value of the '<em><b>Output features</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Output features</em>' attribute.
	 * @see #setOutput_features(int)
	 * @see modl.ModlPackage#getDense_Output_features()
	 * @model
	 * @generated
	 */
	int getOutput_features();

	/**
	 * Sets the value of the '{@link modl.Dense#getOutput_features <em>Output features</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Output features</em>' attribute.
	 * @see #getOutput_features()
	 * @generated
	 */
	void setOutput_features(int value);

} // Dense
