/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Basic Model</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.BasicModel#isTrainable <em>Trainable</em>}</li>
 *   <li>{@link modl.BasicModel#isInclude_top <em>Include top</em>}</li>
 *   <li>{@link modl.BasicModel#getWeights_trained_on <em>Weights trained on</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getBasicModel()
 * @model abstract="true"
 * @generated
 */
public interface BasicModel extends CNNModel {
	/**
	 * Returns the value of the '<em><b>Trainable</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Trainable</em>' attribute.
	 * @see #setTrainable(boolean)
	 * @see modl.ModlPackage#getBasicModel_Trainable()
	 * @model
	 * @generated
	 */
	boolean isTrainable();

	/**
	 * Sets the value of the '{@link modl.BasicModel#isTrainable <em>Trainable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Trainable</em>' attribute.
	 * @see #isTrainable()
	 * @generated
	 */
	void setTrainable(boolean value);

	/**
	 * Returns the value of the '<em><b>Include top</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Include top</em>' attribute.
	 * @see #setInclude_top(boolean)
	 * @see modl.ModlPackage#getBasicModel_Include_top()
	 * @model
	 * @generated
	 */
	boolean isInclude_top();

	/**
	 * Sets the value of the '{@link modl.BasicModel#isInclude_top <em>Include top</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Include top</em>' attribute.
	 * @see #isInclude_top()
	 * @generated
	 */
	void setInclude_top(boolean value);

	/**
	 * Returns the value of the '<em><b>Weights trained on</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Weights trained on</em>' attribute.
	 * @see #setWeights_trained_on(String)
	 * @see modl.ModlPackage#getBasicModel_Weights_trained_on()
	 * @model
	 * @generated
	 */
	String getWeights_trained_on();

	/**
	 * Sets the value of the '{@link modl.BasicModel#getWeights_trained_on <em>Weights trained on</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Weights trained on</em>' attribute.
	 * @see #getWeights_trained_on()
	 * @generated
	 */
	void setWeights_trained_on(String value);

} // BasicModel
