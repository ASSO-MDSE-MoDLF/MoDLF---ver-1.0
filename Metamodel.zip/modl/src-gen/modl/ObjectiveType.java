/**
 */
package modl;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Objective Type</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see modl.ModlPackage#getObjectiveType()
 * @model
 * @generated
 */
public enum ObjectiveType implements Enumerator {
	/**
	 * The '<em><b>Mse</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MSE_VALUE
	 * @generated
	 * @ordered
	 */
	MSE(0, "mse", "mse"),
	/**
	 * The '<em><b>Mae</b></em>' literal object.
	 * <!-- begin-user-doc -->
	* <!-- end-user-doc -->
	 * @see #MAE_VALUE
	 * @generated
	 * @ordered
	 */
	MAE(1, "mae", "mae"),
	/**
	 * The '<em><b>Binary crossentropy</b></em>' literal object.
	 * <!-- begin-user-doc -->
	* <!-- end-user-doc -->
	 * @see #BINARY_CROSSENTROPY_VALUE
	 * @generated
	 * @ordered
	 */
	BINARY_CROSSENTROPY(2, "binary_crossentropy", "binary_crossentropy"),
	/**
	 * The '<em><b>Categorical crossentropy</b></em>' literal object.
	 * <!-- begin-user-doc -->
	* <!-- end-user-doc -->
	 * @see #CATEGORICAL_CROSSENTROPY_VALUE
	 * @generated
	 * @ordered
	 */
	CATEGORICAL_CROSSENTROPY(3, "categorical_crossentropy", "categorical_crossentropy"),
	/**
	* The '<em><b>Cat cross entropy</b></em>' literal object.
	* <!-- begin-user-doc -->
	* <!-- end-user-doc -->
	* @see #CAT_CROSS_ENTROPY_VALUE
	* @generated
	* @ordered
	*/
	CAT_CROSS_ENTROPY(4, "Cat_cross_entropy", "Cat_cross_entropy");

	/**
	 * The '<em><b>Mse</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MSE
	 * @model name="mse"
	 * @generated
	 * @ordered
	 */
	public static final int MSE_VALUE = 0;

	/**
	 * The '<em><b>Mae</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MAE
	 * @model name="mae"
	 * @generated
	 * @ordered
	 */
	public static final int MAE_VALUE = 1;

	/**
	 * The '<em><b>Binary crossentropy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #BINARY_CROSSENTROPY
	 * @model name="binary_crossentropy"
	 * @generated
	 * @ordered
	 */
	public static final int BINARY_CROSSENTROPY_VALUE = 2;

	/**
	 * The '<em><b>Categorical crossentropy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CATEGORICAL_CROSSENTROPY
	 * @model name="categorical_crossentropy"
	 * @generated
	 * @ordered
	 */
	public static final int CATEGORICAL_CROSSENTROPY_VALUE = 3;

	/**
	 * The '<em><b>Cat cross entropy</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CAT_CROSS_ENTROPY
	 * @model name="Cat_cross_entropy"
	 * @generated
	 * @ordered
	 */
	public static final int CAT_CROSS_ENTROPY_VALUE = 4;

	/**
	 * An array of all the '<em><b>Objective Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final ObjectiveType[] VALUES_ARRAY = new ObjectiveType[] { MSE, MAE, BINARY_CROSSENTROPY,
			CATEGORICAL_CROSSENTROPY, CAT_CROSS_ENTROPY, };

	/**
	 * A public read-only list of all the '<em><b>Objective Type</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<ObjectiveType> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Objective Type</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ObjectiveType get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ObjectiveType result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Objective Type</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ObjectiveType getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			ObjectiveType result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Objective Type</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static ObjectiveType get(int value) {
		switch (value) {
		case MSE_VALUE:
			return MSE;
		case MAE_VALUE:
			return MAE;
		case BINARY_CROSSENTROPY_VALUE:
			return BINARY_CROSSENTROPY;
		case CATEGORICAL_CROSSENTROPY_VALUE:
			return CATEGORICAL_CROSSENTROPY;
		case CAT_CROSS_ENTROPY_VALUE:
			return CAT_CROSS_ENTROPY;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private ObjectiveType(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //ObjectiveType
