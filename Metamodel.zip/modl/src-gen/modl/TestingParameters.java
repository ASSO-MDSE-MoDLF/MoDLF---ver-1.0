/**
 */
package modl;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Testing Parameters</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.TestingParameters#getConfidence <em>Confidence</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getTestingParameters()
 * @model
 * @generated
 */
public interface TestingParameters extends Parameters {

	/**
	 * Returns the value of the '<em><b>Confidence</b></em>' attribute.
	 * The default value is <code>"0.5"</code>.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Confidence</em>' attribute.
	 * @see #setConfidence(float)
	 * @see modl.ModlPackage#getTestingParameters_Confidence()
	 * @model default="0.5"
	 * @generated
	 */
	float getConfidence();

	/**
	 * Sets the value of the '{@link modl.TestingParameters#getConfidence <em>Confidence</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Confidence</em>' attribute.
	 * @see #getConfidence()
	 * @generated
	 */
	void setConfidence(float value);
} // TestingParameters
