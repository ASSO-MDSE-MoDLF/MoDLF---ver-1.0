/**
 */
package modl;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Label</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link modl.Label#getImage <em>Image</em>}</li>
 * </ul>
 *
 * @see modl.ModlPackage#getLabel()
 * @model
 * @generated
 */
public interface Label extends EObject {
	/**
	 * Returns the value of the '<em><b>Image</b></em>' reference list.
	 * The list contents are of type {@link modl.Image}.
	 * It is bidirectional and its opposite is '{@link modl.Image#getLabel <em>Label</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Image</em>' reference list.
	 * @see modl.ModlPackage#getLabel_Image()
	 * @see modl.Image#getLabel
	 * @model opposite="label"
	 * @generated
	 */
	EList<Image> getImage();

} // Label
